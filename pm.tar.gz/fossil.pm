<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fossil
</isim>
<tanim>
Dağıtık yazılım ayarlama,sürüm takip yönetimi uygulaması
</tanim>
<ekran_resmi>
file:///tmp/fossil.png
</ekran_resmi>
<kurulacak_paketler>
fossil
</kurulacak_paketler>
<silinecek_paketler>
fossil
</silinecek_paketler>
</uygulama>
