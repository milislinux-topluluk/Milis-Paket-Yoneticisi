<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
fossil
</isim>
<tanim>
Dağıtık yazılım ayarlama,sürüm takip yönetimi uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/fossil.png
</ekran_resmi>
<kurulacak_paketler>
fossil
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.3
</surum>
<silinecek_paketler>
fossil
</silinecek_paketler>
</uygulama>
