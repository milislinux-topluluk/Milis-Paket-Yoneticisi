<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fossil
</isim>
<tanim>
Dağıtık yazılım ayarlama,sürüm takip yönetimi uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fossil.png
</ekran_resmi>
<kurulacak_paketler>
fossil
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
fossil
</silinecek_paketler>
</uygulama>
