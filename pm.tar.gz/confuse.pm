<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
confuse
</isim>
<tanim>
Ayar dosyalarını ayrıştıran C kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/confuse.png
</ekran_resmi>
<kurulacak_paketler>
confuse
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
confuse
</silinecek_paketler>
</uygulama>
