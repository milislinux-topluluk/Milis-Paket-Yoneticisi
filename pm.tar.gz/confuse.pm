<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
confuse
</isim>
<tanim>
Ayar dosyalarını ayrıştıran C kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/confuse.png
</ekran_resmi>
<kurulacak_paketler>
confuse
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.2.1
</surum>
<silinecek_paketler>
confuse
</silinecek_paketler>
</uygulama>
