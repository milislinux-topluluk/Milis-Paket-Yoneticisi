<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
zip
</isim>
<tanim>
Creates PKZIP-compatible .zip files
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/zip.png
</ekran_resmi>
<kurulacak_paketler>
zip
</kurulacak_paketler>
<silinecek_paketler>
zip
</silinecek_paketler>
</uygulama>
