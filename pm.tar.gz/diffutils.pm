<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
diffutils
</isim>
<tanim>
Programs that show the differences between files or directories.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/diffutils.png
</ekran_resmi>
<kurulacak_paketler>
diffutils
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
3.3
</surum>
<silinecek_paketler>
diffutils
</silinecek_paketler>
</uygulama>
