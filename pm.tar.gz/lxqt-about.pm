<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxqt-about
</isim>
<tanim>
Lxqt-about paketi bağımsız LXQt "Hakkında" iletişim kutusunu sağlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxqt-about.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-about
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.11.1
</surum>
<silinecek_paketler>
lxqt-about
</silinecek_paketler>
</uygulama>
