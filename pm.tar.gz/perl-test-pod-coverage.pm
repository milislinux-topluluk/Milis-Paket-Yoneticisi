<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
perl-test-pod-coverage
</isim>
<tanim>
CPAN Test
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-test-pod-coverage.png
</ekran_resmi>
<kurulacak_paketler>
perl-test-pod-coverage
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.08
</surum>
<silinecek_paketler>
perl-test-pod-coverage
</silinecek_paketler>
</uygulama>
