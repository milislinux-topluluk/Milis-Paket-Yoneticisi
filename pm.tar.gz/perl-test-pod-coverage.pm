<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
perl-test-pod-coverage
</isim>
<tanim>
CPAN Test
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-test-pod-coverage.png
</ekran_resmi>
<kurulacak_paketler>
perl-test-pod-coverage
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
perl-test-pod-coverage
</silinecek_paketler>
</uygulama>
