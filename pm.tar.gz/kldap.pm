<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kldap
</isim>
<tanim>
LDAP access API for KDE
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kldap.png
</ekran_resmi>
<kurulacak_paketler>
kldap
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kldap
</silinecek_paketler>
</uygulama>
