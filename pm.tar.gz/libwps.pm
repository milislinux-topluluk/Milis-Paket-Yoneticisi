<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libwps
</isim>
<tanim>
Microsoft Works dosya sözcük işlemci biçimi içe aktarma filtre kitaplığı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libwps.png
</ekran_resmi>
<kurulacak_paketler>
libwps
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.4.7
</surum>
<silinecek_paketler>
libwps
</silinecek_paketler>
</uygulama>
