<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libwps
</isim>
<tanim>
Microsoft Works dosya sözcük işlemci biçimi içe aktarma filtre kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libwps.png
</ekran_resmi>
<kurulacak_paketler>
libwps
</kurulacak_paketler>
<silinecek_paketler>
libwps
</silinecek_paketler>
</uygulama>
