<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wget
</isim>
<tanim>
Utility for non-interactive download of files using HTTP, HTTPS and FTP.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wget.png
</ekran_resmi>
<kurulacak_paketler>
wget
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.17.1
</surum>
<silinecek_paketler>
wget
</silinecek_paketler>
</uygulama>
