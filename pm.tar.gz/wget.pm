<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wget
</isim>
<tanim>
Utility for non-interactive download of files using HTTP, HTTPS and FTP.
</tanim>
<ekran_resmi>
file:///tmp/wget.png
</ekran_resmi>
<kurulacak_paketler>
wget
</kurulacak_paketler>
<silinecek_paketler>
wget
</silinecek_paketler>
</uygulama>
