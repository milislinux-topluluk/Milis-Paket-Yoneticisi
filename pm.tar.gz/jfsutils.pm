<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jfsutils
</isim>
<tanim>
Administration and debugging tools for the jfs file system.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jfsutils.png
</ekran_resmi>
<kurulacak_paketler>
jfsutils
</kurulacak_paketler>
<silinecek_paketler>
jfsutils
</silinecek_paketler>
</uygulama>
