<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jfsutils
</isim>
<tanim>
Administration and debugging tools for the jfs file system.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jfsutils.png
</ekran_resmi>
<kurulacak_paketler>
jfsutils
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
1.1.15
</surum>
<silinecek_paketler>
jfsutils
</silinecek_paketler>
</uygulama>
