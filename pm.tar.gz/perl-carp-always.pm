<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-carp-always
</isim>
<tanim>
Perl Carp modülü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-carp-always.png
</ekran_resmi>
<kurulacak_paketler>
perl-carp-always
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
perl-carp-always
</silinecek_paketler>
</uygulama>
