<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-carp-always
</isim>
<tanim>
Perl Carp modülü
</tanim>
<ekran_resmi>
file:///tmp/perl-carp-always.png
</ekran_resmi>
<kurulacak_paketler>
perl-carp-always
</kurulacak_paketler>
<silinecek_paketler>
perl-carp-always
</silinecek_paketler>
</uygulama>
