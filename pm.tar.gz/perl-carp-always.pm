<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-carp-always
</isim>
<tanim>
Perl Carp modülü
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-carp-always.png
</ekran_resmi>
<kurulacak_paketler>
perl-carp-always
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.13
</surum>
<silinecek_paketler>
perl-carp-always
</silinecek_paketler>
</uygulama>
