<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fcron
</isim>
<tanim>
Özellik açısından zengin cron uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fcron.png
</ekran_resmi>
<kurulacak_paketler>
fcron
</kurulacak_paketler>
<silinecek_paketler>
fcron
</silinecek_paketler>
</uygulama>
