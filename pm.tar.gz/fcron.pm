<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
fcron
</isim>
<tanim>
Özellik açısından zengin cron uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/fcron.png
</ekran_resmi>
<kurulacak_paketler>
fcron
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.3.0
</surum>
<silinecek_paketler>
fcron
</silinecek_paketler>
</uygulama>
