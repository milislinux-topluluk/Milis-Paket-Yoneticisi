<?xml version="1.0"?>
<uygulama>
<grup>
Medya
</grup>
<isim>
vokoscreen
</isim>
<tanim>
Kolay ekran çekim uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/vokoscreen.png
</ekran_resmi>
<kurulacak_paketler>
vokoscreen
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.5.7-beta
</surum>
<silinecek_paketler>
vokoscreen
</silinecek_paketler>
</uygulama>
