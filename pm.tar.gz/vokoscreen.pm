<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
vokoscreen
</isim>
<tanim>
Kolay ekran çekim uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/vokoscreen.png
</ekran_resmi>
<kurulacak_paketler>
vokoscreen
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.5.7.beta
</surum>
<silinecek_paketler>
vokoscreen
</silinecek_paketler>
</uygulama>
