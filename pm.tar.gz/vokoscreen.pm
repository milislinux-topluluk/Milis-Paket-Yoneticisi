<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
vokoscreen
</isim>
<tanim>
Kolay ekran çekim uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/vokoscreen.png
</ekran_resmi>
<kurulacak_paketler>
vokoscreen
</kurulacak_paketler>
<silinecek_paketler>
vokoscreen
</silinecek_paketler>
</uygulama>
