<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
findutils
</isim>
<tanim>
GNU utilities to locate files
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/findutils.png
</ekran_resmi>
<kurulacak_paketler>
findutils
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
4.6.0
</surum>
<silinecek_paketler>
findutils
</silinecek_paketler>
</uygulama>
