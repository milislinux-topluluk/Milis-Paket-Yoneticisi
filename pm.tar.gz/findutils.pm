<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
findutils
</isim>
<tanim>
GNU utilities to locate files
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/findutils.png
</ekran_resmi>
<kurulacak_paketler>
findutils
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
4.6.0
</surum>
<silinecek_paketler>
findutils
</silinecek_paketler>
</uygulama>
