<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
findutils
</isim>
<tanim>
GNU utilities to locate files
</tanim>
<ekran_resmi>
file:///tmp/findutils.png
</ekran_resmi>
<kurulacak_paketler>
findutils
</kurulacak_paketler>
<silinecek_paketler>
findutils
</silinecek_paketler>
</uygulama>
