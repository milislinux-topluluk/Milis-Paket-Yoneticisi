<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-color-manager
</isim>
<tanim>
GNOME masaüstü için renk profili yöneticisi
</tanim>
<ekran_resmi>
file:///tmp/gnome-color-manager.png
</ekran_resmi>
<kurulacak_paketler>
gnome-color-manager
</kurulacak_paketler>
<silinecek_paketler>
gnome-color-manager
</silinecek_paketler>
</uygulama>
