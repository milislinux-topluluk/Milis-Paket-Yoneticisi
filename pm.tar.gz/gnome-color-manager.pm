<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-color-manager
</isim>
<tanim>
GNOME masaüstü için renk profili yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-color-manager.png
</ekran_resmi>
<kurulacak_paketler>
gnome-color-manager
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.2
</surum>
<silinecek_paketler>
gnome-color-manager
</silinecek_paketler>
</uygulama>
