<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
c-ares
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///tmp/c-ares.png
</ekran_resmi>
<kurulacak_paketler>
c-ares
</kurulacak_paketler>
<silinecek_paketler>
c-ares
</silinecek_paketler>
</uygulama>
