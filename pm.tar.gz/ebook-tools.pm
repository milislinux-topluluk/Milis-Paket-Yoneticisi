<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ebook-tools
</isim>
<tanim>
Tools for accessing and converting various ebook file formats
</tanim>
<ekran_resmi>
file:///tmp/ebook-tools.png
</ekran_resmi>
<kurulacak_paketler>
ebook-tools
</kurulacak_paketler>
<silinecek_paketler>
ebook-tools
</silinecek_paketler>
</uygulama>
