<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ebook-tools
</isim>
<tanim>
Tools for accessing and converting various ebook file formats
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ebook-tools.png
</ekran_resmi>
<kurulacak_paketler>
ebook-tools
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
ebook-tools
</silinecek_paketler>
</uygulama>
