<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kontactinterface
</isim>
<tanim>
Provides the glue necessary for application parts to be embedded as a Kontact component
</tanim>
<ekran_resmi>
file:///tmp/kontactinterface.png
</ekran_resmi>
<kurulacak_paketler>
kontactinterface
</kurulacak_paketler>
<silinecek_paketler>
kontactinterface
</silinecek_paketler>
</uygulama>
