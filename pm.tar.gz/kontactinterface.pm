<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kontactinterface
</isim>
<tanim>
Provides the glue necessary for application parts to be embedded as a Kontact component
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kontactinterface.png
</ekran_resmi>
<kurulacak_paketler>
kontactinterface
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
kontactinterface
</silinecek_paketler>
</uygulama>
