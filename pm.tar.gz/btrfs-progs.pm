<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
btrfs-progs
</isim>
<tanim>
Btrfs filesystem utilities
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/btrfs-progs.png
</ekran_resmi>
<kurulacak_paketler>
btrfs-progs
</kurulacak_paketler>
<paketci>
alienus at nutyx dot org, tnut at nutyx dot org
</paketci>
<surum>
4.1
</surum>
<silinecek_paketler>
btrfs-progs
</silinecek_paketler>
</uygulama>
