<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
squid
</isim>
<tanim>
Fonksiyonel vekil sunucu yazılımı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/squid.png
</ekran_resmi>
<kurulacak_paketler>
squid
</kurulacak_paketler>
<silinecek_paketler>
squid
</silinecek_paketler>
</uygulama>
