<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
squid
</isim>
<tanim>
Fonksiyonel vekil sunucu yazılımı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/squid.png
</ekran_resmi>
<kurulacak_paketler>
squid
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.5.24
</surum>
<silinecek_paketler>
squid
</silinecek_paketler>
</uygulama>
