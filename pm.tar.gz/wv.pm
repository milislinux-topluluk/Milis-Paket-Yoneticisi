<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wv
</isim>
<tanim>
MSWord kitaplığı, Word 2000, 97, 95 ve 6 dosya formatlarını yükleyebilir ve ayrıştırabilir
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wv.png
</ekran_resmi>
<kurulacak_paketler>
wv
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
wv
</silinecek_paketler>
</uygulama>
