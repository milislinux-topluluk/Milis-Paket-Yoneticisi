<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wv
</isim>
<tanim>
MSWord library can load and parse Word 2000, 97, 95 and 6 file formats
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/wv.png
</ekran_resmi>
<kurulacak_paketler>
wv
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.2.9
</surum>
<silinecek_paketler>
wv
</silinecek_paketler>
</uygulama>
