<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdeclarative
</isim>
<tanim>
QML ve KDE Framework'lerin entegrasyonunu sağlar
</tanim>
<ekran_resmi>
file:///tmp/kf5-kdeclarative.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdeclarative
</kurulacak_paketler>
<silinecek_paketler>
kf5-kdeclarative
</silinecek_paketler>
</uygulama>
