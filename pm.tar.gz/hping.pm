<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
hping
</isim>
<tanim>
TCP/IP prokolu icin Ping
</tanim>
<ekran_resmi>
file:///tmp/hping.png
</ekran_resmi>
<kurulacak_paketler>
hping
</kurulacak_paketler>
<silinecek_paketler>
hping
</silinecek_paketler>
</uygulama>
