<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
hping
</isim>
<tanim>
TCP/IP prokolu icin Ping
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/hping.png
</ekran_resmi>
<kurulacak_paketler>
hping
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
git
</surum>
<silinecek_paketler>
hping
</silinecek_paketler>
</uygulama>
