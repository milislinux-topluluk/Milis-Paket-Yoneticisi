<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fet
</isim>
<tanim>
Bir okul, lise veya üniversitenin zaman çizelgesini otomatik olarak planlamak için bir yazılım.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fet.png
</ekran_resmi>
<kurulacak_paketler>
fet
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<silinecek_paketler>
fet
</silinecek_paketler>
</uygulama>
