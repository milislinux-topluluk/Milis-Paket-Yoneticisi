<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
fet
</isim>
<tanim>
Bir okul, lise veya üniversitenin zaman çizelgesini otomatik olarak planlamak için bir yazılım.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/fet.png
</ekran_resmi>
<kurulacak_paketler>
fet
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
5.33.1
</surum>
<silinecek_paketler>
fet
</silinecek_paketler>
</uygulama>
