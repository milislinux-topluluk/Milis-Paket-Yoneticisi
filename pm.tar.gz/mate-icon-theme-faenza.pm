<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-icon-theme-faenza
</isim>
<tanim>
MATE için Faenza simge teması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mate-icon-theme-faenza.png
</ekran_resmi>
<kurulacak_paketler>
mate-icon-theme-faenza
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.1
</surum>
<silinecek_paketler>
mate-icon-theme-faenza
</silinecek_paketler>
</uygulama>
