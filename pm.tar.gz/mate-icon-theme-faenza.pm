<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-icon-theme-faenza
</isim>
<tanim>
MATE için Faenza simge teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-icon-theme-faenza.png
</ekran_resmi>
<kurulacak_paketler>
mate-icon-theme-faenza
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
mate-icon-theme-faenza
</silinecek_paketler>
</uygulama>
