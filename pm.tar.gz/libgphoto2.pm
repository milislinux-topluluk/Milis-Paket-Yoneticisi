<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libgphoto2
</isim>
<tanim>
Core library of gphoto2, designed to allow access to digital camera by external programs.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libgphoto2.png
</ekran_resmi>
<kurulacak_paketler>
libgphoto2
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.5.10
</surum>
<silinecek_paketler>
libgphoto2
</silinecek_paketler>
</uygulama>
