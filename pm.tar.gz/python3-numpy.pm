<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-numpy
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-numpy.png
</ekran_resmi>
<kurulacak_paketler>
python3-numpy
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
python3-numpy
</silinecek_paketler>
</uygulama>
