<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-numpy
</isim>
<tanim>
python3 bilimsel araç kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python3-numpy.png
</ekran_resmi>
<kurulacak_paketler>
python3-numpy
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.11.2
</surum>
<silinecek_paketler>
python3-numpy
</silinecek_paketler>
</uygulama>
