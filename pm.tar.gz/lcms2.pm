<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lcms2
</isim>
<tanim>
Lightweight color management development library/engine
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lcms2.png
</ekran_resmi>
<kurulacak_paketler>
lcms2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.7
</surum>
<silinecek_paketler>
lcms2
</silinecek_paketler>
</uygulama>
