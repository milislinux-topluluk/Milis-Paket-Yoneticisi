<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lcms2
</isim>
<tanim>
Lightweight color management development library/engine
</tanim>
<ekran_resmi>
file:///tmp/lcms2.png
</ekran_resmi>
<kurulacak_paketler>
lcms2
</kurulacak_paketler>
<silinecek_paketler>
lcms2
</silinecek_paketler>
</uygulama>
