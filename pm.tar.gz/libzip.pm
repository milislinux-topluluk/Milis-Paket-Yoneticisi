<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libzip
</isim>
<tanim>
A C library for reading, creating, and modifying zip archives
</tanim>
<ekran_resmi>
file:///tmp/libzip.png
</ekran_resmi>
<kurulacak_paketler>
libzip
</kurulacak_paketler>
<silinecek_paketler>
libzip
</silinecek_paketler>
</uygulama>
