<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
openct
</isim>
<tanim>
Implements drivers for several smart card readers
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/openct.png
</ekran_resmi>
<kurulacak_paketler>
openct
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.6.20
</surum>
<silinecek_paketler>
openct
</silinecek_paketler>
</uygulama>
