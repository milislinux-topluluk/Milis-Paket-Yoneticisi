<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
openct
</isim>
<tanim>
Implements drivers for several smart card readers
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/openct.png
</ekran_resmi>
<kurulacak_paketler>
openct
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
openct
</silinecek_paketler>
</uygulama>
