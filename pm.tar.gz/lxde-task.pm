<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxde-task
</isim>
<tanim>
lxde surec yoneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxde-task.png
</ekran_resmi>
<kurulacak_paketler>
lxde-task
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
0.1.6
</surum>
<silinecek_paketler>
lxde-task
</silinecek_paketler>
</uygulama>
