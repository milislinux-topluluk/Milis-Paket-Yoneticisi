<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxde-task
</isim>
<tanim>
lxde surec yoneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxde-task.png
</ekran_resmi>
<kurulacak_paketler>
lxde-task
</kurulacak_paketler>
<silinecek_paketler>
lxde-task
</silinecek_paketler>
</uygulama>
