<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ettercap
</isim>
<tanim>
Ethernet LAN'lar için bir ağ algılayıcı/durdurucu/günlükleyici
</tanim>
<ekran_resmi>
file:///tmp/ettercap.png
</ekran_resmi>
<kurulacak_paketler>
ettercap
</kurulacak_paketler>
<silinecek_paketler>
ettercap
</silinecek_paketler>
</uygulama>
