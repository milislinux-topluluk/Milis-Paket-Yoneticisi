<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ettercap
</isim>
<tanim>
Ethernet LAN'lar için bir ağ algılayıcı/durdurucu/günlükleyici
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ettercap.png
</ekran_resmi>
<kurulacak_paketler>
ettercap
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
ettercap
</silinecek_paketler>
</uygulama>
