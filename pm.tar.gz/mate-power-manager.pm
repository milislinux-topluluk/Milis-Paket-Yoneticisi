<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-power-manager
</isim>
<tanim>
MATE masaüstü için güç yönetim aracı
</tanim>
<ekran_resmi>
file:///tmp/mate-power-manager.png
</ekran_resmi>
<kurulacak_paketler>
mate-power-manager
</kurulacak_paketler>
<silinecek_paketler>
mate-power-manager
</silinecek_paketler>
</uygulama>
