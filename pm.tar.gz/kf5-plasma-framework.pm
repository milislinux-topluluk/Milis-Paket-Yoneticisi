<?xml version="1.0"?>
<uygulama>
<grup>
Kde
</grup>
<isim>
kf5-plasma-framework
</isim>
<tanim>
KF5 ve Qt5'e dayanan plazma kitaplığı ve çalışma zamanı bileşenleri
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-plasma-framework.png
</ekran_resmi>
<kurulacak_paketler>
kf5-plasma-framework
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-plasma-framework
</silinecek_paketler>
</uygulama>
