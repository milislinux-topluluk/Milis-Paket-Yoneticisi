<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
grub-customizer
</isim>
<tanim>
Grafiksel grub2 ayar yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/grub-customizer.png
</ekran_resmi>
<kurulacak_paketler>
grub-customizer
</kurulacak_paketler>
<silinecek_paketler>
grub-customizer
</silinecek_paketler>
</uygulama>
