<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
grub-customizer
</isim>
<tanim>
Grafiksel grub2 ayar yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/grub-customizer.png
</ekran_resmi>
<kurulacak_paketler>
grub-customizer
</kurulacak_paketler>
<paketci>
yasarciv
</paketci>
<surum>
5.0.6
</surum>
<silinecek_paketler>
grub-customizer
</silinecek_paketler>
</uygulama>
