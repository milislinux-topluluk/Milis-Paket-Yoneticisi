<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
grub-customizer
</isim>
<tanim>
Grafiksel grub2 ayar yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/grub-customizer.png
</ekran_resmi>
<kurulacak_paketler>
grub-customizer
</kurulacak_paketler>
<paketci>
yasarciv
</paketci>
<surum>
5.0.6
</surum>
<silinecek_paketler>
grub-customizer
</silinecek_paketler>
</uygulama>
