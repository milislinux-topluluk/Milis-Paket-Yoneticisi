<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
innoextract
</isim>
<tanim>
Inno Setup tarafından oluşturulan yükleyicileri ayıklamak için kullanılan bir araç
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/innoextract.png
</ekran_resmi>
<kurulacak_paketler>
innoextract
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.6
</surum>
<silinecek_paketler>
innoextract
</silinecek_paketler>
</uygulama>
