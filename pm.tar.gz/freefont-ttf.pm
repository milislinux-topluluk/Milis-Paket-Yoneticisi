<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
freefont-ttf
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/freefont-ttf.png
</ekran_resmi>
<kurulacak_paketler>
freefont-ttf
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
20120503
</surum>
<silinecek_paketler>
freefont-ttf
</silinecek_paketler>
</uygulama>
