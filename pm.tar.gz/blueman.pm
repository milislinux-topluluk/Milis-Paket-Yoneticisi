<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
blueman
</isim>
<tanim>
A GTK+ Bluetooth Yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/blueman.png
</ekran_resmi>
<kurulacak_paketler>
blueman
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
blueman
</silinecek_paketler>
</uygulama>
