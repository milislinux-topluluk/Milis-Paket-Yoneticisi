<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
blueman
</isim>
<tanim>
A GTK+ Bluetooth Yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/blueman.png
</ekran_resmi>
<kurulacak_paketler>
blueman
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.0.5
</surum>
<silinecek_paketler>
blueman
</silinecek_paketler>
</uygulama>
