<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdbusaddons
</isim>
<tanim>
QtDBus'a eklentiler
</tanim>
<ekran_resmi>
file:///tmp/kf5-kdbusaddons.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdbusaddons
</kurulacak_paketler>
<silinecek_paketler>
kf5-kdbusaddons
</silinecek_paketler>
</uygulama>
