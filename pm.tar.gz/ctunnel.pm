<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ctunnel
</isim>
<tanim>
komut satırından kullanılan şifreli tünelleme uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ctunnel.png
</ekran_resmi>
<kurulacak_paketler>
ctunnel
</kurulacak_paketler>
<silinecek_paketler>
ctunnel
</silinecek_paketler>
</uygulama>
