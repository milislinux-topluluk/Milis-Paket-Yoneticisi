<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ctunnel
</isim>
<tanim>
komut satırından kullanılan şifreli tünelleme uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/ctunnel.png
</ekran_resmi>
<kurulacak_paketler>
ctunnel
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.7
</surum>
<silinecek_paketler>
ctunnel
</silinecek_paketler>
</uygulama>
