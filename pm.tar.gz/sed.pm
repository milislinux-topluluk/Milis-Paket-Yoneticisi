<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sed
</isim>
<tanim>
Takes text input, do some operation on it, and outputs the modified text.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sed.png
</ekran_resmi>
<kurulacak_paketler>
sed
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
4.2.2
</surum>
<silinecek_paketler>
sed
</silinecek_paketler>
</uygulama>
