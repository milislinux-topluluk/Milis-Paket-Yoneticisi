<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libksane
</isim>
<tanim>
An image scanning library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libksane.png
</ekran_resmi>
<kurulacak_paketler>
libksane
</kurulacak_paketler>
<silinecek_paketler>
libksane
</silinecek_paketler>
</uygulama>
