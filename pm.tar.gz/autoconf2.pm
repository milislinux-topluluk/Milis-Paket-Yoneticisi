<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
autoconf2
</isim>
<tanim>
A GNU tool for automatically configuring source code (Legacy 2.1x version)
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/autoconf2.png
</ekran_resmi>
<kurulacak_paketler>
autoconf2
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
2.13
</surum>
<silinecek_paketler>
autoconf2
</silinecek_paketler>
</uygulama>
