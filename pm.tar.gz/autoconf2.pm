<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
autoconf2
</isim>
<tanim>
A GNU tool for automatically configuring source code (Legacy 2.1x version)
</tanim>
<ekran_resmi>
file:///tmp/autoconf2.png
</ekran_resmi>
<kurulacak_paketler>
autoconf2
</kurulacak_paketler>
<silinecek_paketler>
autoconf2
</silinecek_paketler>
</uygulama>
