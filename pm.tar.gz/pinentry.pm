<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pinentry
</isim>
<tanim>
a collection of simple PIN or passphrase entry dialogs which utilize the Assuan protocol
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/pinentry.png
</ekran_resmi>
<kurulacak_paketler>
pinentry
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.9.7
</surum>
<silinecek_paketler>
pinentry
</silinecek_paketler>
</uygulama>
