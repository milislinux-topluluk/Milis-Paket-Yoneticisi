<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
cyrus-sasl
</isim>
<tanim>
Cyrus saslauthd SASL authentication daemon
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cyrus-sasl.png
</ekran_resmi>
<kurulacak_paketler>
cyrus-sasl
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.1.26
</surum>
<silinecek_paketler>
cyrus-sasl
</silinecek_paketler>
</uygulama>
