<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
zlib
</isim>
<tanim>
The Zlib package contains compression and decompression routines used by some programs.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/zlib.png
</ekran_resmi>
<kurulacak_paketler>
zlib
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.2.8
</surum>
<silinecek_paketler>
zlib
</silinecek_paketler>
</uygulama>
