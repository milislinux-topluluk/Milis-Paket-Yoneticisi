<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ricin
</isim>
<tanim>
Hafif vala tabanlı Tox istemcisi
</tanim>
<ekran_resmi>
file:///tmp/ricin.png
</ekran_resmi>
<kurulacak_paketler>
ricin
</kurulacak_paketler>
<silinecek_paketler>
ricin
</silinecek_paketler>
</uygulama>
