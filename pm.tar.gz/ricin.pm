<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ricin
</isim>
<tanim>
Hafif vala tabanlı Tox istemcisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/ricin.png
</ekran_resmi>
<kurulacak_paketler>
ricin
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.0.7
</surum>
<silinecek_paketler>
ricin
</silinecek_paketler>
</uygulama>
