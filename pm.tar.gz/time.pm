<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
time
</isim>
<tanim>
Measures many of the CPU resources, such as time and memory, that other programs use.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/time.png
</ekran_resmi>
<kurulacak_paketler>
time
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.7
</surum>
<silinecek_paketler>
time
</silinecek_paketler>
</uygulama>
