<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
time
</isim>
<tanim>
Measures many of the CPU resources, such as time and memory, that other programs use.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/time.png
</ekran_resmi>
<kurulacak_paketler>
time
</kurulacak_paketler>
<silinecek_paketler>
time
</silinecek_paketler>
</uygulama>
