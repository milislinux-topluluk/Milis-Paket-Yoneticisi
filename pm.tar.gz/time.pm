<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
time
</isim>
<tanim>
Diğer programların kullandığı CPU kaynaklarının (örneğin zaman ve bellek gibi) birçoğunu ölçer.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/time.png
</ekran_resmi>
<kurulacak_paketler>
time
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.7
</surum>
<silinecek_paketler>
time
</silinecek_paketler>
</uygulama>
