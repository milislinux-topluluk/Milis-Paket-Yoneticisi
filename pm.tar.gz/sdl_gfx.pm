<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sdl_gfx
</isim>
<tanim>
SDL grafik çizim ilkelleri ve diğer destek fonksiyonları.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sdl_gfx.png
</ekran_resmi>
<kurulacak_paketler>
sdl_gfx
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
sdl_gfx
</silinecek_paketler>
</uygulama>
