<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sdl_gfx
</isim>
<tanim>
SDL grafik çizim ilkelleri ve diğer destek fonksiyonları.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sdl_gfx.png
</ekran_resmi>
<kurulacak_paketler>
sdl_gfx
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.0.23
</surum>
<silinecek_paketler>
sdl_gfx
</silinecek_paketler>
</uygulama>
