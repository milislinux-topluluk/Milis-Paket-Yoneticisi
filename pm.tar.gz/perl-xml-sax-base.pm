<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-xml-sax-base
</isim>
<tanim>
Temel sınıf SAX Sürücüleri ve Filtreleri
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-xml-sax-base.png
</ekran_resmi>
<kurulacak_paketler>
perl-xml-sax-base
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.08
</surum>
<silinecek_paketler>
perl-xml-sax-base
</silinecek_paketler>
</uygulama>
