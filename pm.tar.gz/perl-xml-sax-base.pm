<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-xml-sax-base
</isim>
<tanim>
Temel sınıf SAX Sürücüleri ve Filtreleri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-xml-sax-base.png
</ekran_resmi>
<kurulacak_paketler>
perl-xml-sax-base
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.08
</surum>
<silinecek_paketler>
perl-xml-sax-base
</silinecek_paketler>
</uygulama>
