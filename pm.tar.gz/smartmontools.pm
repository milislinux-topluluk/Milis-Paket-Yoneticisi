<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
smartmontools
</isim>
<tanim>
S.M.A.R.T.'yi kontrol edin ve izleyin. Etkin ATA ve SCSI Sabit Diskler
</tanim>
<ekran_resmi>
file:///tmp/smartmontools.png
</ekran_resmi>
<kurulacak_paketler>
smartmontools
</kurulacak_paketler>
<silinecek_paketler>
smartmontools
</silinecek_paketler>
</uygulama>
