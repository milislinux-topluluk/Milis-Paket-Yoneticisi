<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk-update-icon-cache
</isim>
<tanim>
The GTK+ update icon cache tool
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtk-update-icon-cache.png
</ekran_resmi>
<kurulacak_paketler>
gtk-update-icon-cache
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
gtk-update-icon-cache
</silinecek_paketler>
</uygulama>
