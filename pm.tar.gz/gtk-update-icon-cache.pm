<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk-update-icon-cache
</isim>
<tanim>
The GTK+ update icon cache tool
</tanim>
<ekran_resmi>
file:///tmp/gtk-update-icon-cache.png
</ekran_resmi>
<kurulacak_paketler>
gtk-update-icon-cache
</kurulacak_paketler>
<silinecek_paketler>
gtk-update-icon-cache
</silinecek_paketler>
</uygulama>
