<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
icon-naming-utils
</isim>
<tanim>
Maps the new names of icons for Tango to the legacy names used by GNOME and KDE desktops
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/icon-naming-utils.png
</ekran_resmi>
<kurulacak_paketler>
icon-naming-utils
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.8.90
</surum>
<silinecek_paketler>
icon-naming-utils
</silinecek_paketler>
</uygulama>
