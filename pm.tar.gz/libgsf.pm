<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libgsf
</isim>
<tanim>
Provide an extensible input/output abstraction layer for structured file formats.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libgsf.png
</ekran_resmi>
<kurulacak_paketler>
libgsf
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.14.35
</surum>
<silinecek_paketler>
libgsf
</silinecek_paketler>
</uygulama>
