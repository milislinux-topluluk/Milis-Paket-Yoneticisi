<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libgsf
</isim>
<tanim>
Provide an extensible input/output abstraction layer for structured file formats.
</tanim>
<ekran_resmi>
file:///tmp/libgsf.png
</ekran_resmi>
<kurulacak_paketler>
libgsf
</kurulacak_paketler>
<silinecek_paketler>
libgsf
</silinecek_paketler>
</uygulama>
