<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
telepathy-kde-desktop-applets
</isim>
<tanim>
The KDE-Telepathy Plasma desktop applets
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/telepathy-kde-desktop-applets.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-desktop-applets
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
telepathy-kde-desktop-applets
</silinecek_paketler>
</uygulama>
