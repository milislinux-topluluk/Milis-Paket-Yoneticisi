<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telepathy-kde-desktop-applets
</isim>
<tanim>
KDE-Telepati Plasma masaüstü uygulamaları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telepathy-kde-desktop-applets.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-desktop-applets
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
telepathy-kde-desktop-applets
</silinecek_paketler>
</uygulama>
