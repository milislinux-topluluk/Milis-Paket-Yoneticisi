<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jsoncpp
</isim>
<tanim>
JSON C++ kütüphanesi
</tanim>
<ekran_resmi>
file:///tmp/jsoncpp.png
</ekran_resmi>
<kurulacak_paketler>
jsoncpp
</kurulacak_paketler>
<silinecek_paketler>
jsoncpp
</silinecek_paketler>
</uygulama>
