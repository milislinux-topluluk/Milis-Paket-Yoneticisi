<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
jsoncpp
</isim>
<tanim>
JSON C++ kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jsoncpp.png
</ekran_resmi>
<kurulacak_paketler>
jsoncpp
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.8.1
</surum>
<silinecek_paketler>
jsoncpp
</silinecek_paketler>
</uygulama>
