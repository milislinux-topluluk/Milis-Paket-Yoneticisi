<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gdl
</isim>
<tanim>
GNOME Tespit Kütüphaneleri.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gdl.png
</ekran_resmi>
<kurulacak_paketler>
gdl
</kurulacak_paketler>
<silinecek_paketler>
gdl
</silinecek_paketler>
</uygulama>
