<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-digest-hmac
</isim>
<tanim>
İleti Kimlik Doğrulaması için Anahtarlı-Hashing
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-digest-hmac.png
</ekran_resmi>
<kurulacak_paketler>
perl-digest-hmac
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.03
</surum>
<silinecek_paketler>
perl-digest-hmac
</silinecek_paketler>
</uygulama>
