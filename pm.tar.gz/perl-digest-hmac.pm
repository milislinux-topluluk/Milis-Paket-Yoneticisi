<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-digest-hmac
</isim>
<tanim>
İleti Kimlik Doğrulaması için Anahtarlı-Hashing
</tanim>
<ekran_resmi>
file:///tmp/perl-digest-hmac.png
</ekran_resmi>
<kurulacak_paketler>
perl-digest-hmac
</kurulacak_paketler>
<silinecek_paketler>
perl-digest-hmac
</silinecek_paketler>
</uygulama>
