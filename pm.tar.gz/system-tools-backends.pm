<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
system-tools-backends
</isim>
<tanim>
Sistem Araçları Arka Uçları, Linux ve diğer Unix sistemleri için bir dizi çapraz platform komut dosyasıdır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/system-tools-backends.png
</ekran_resmi>
<kurulacak_paketler>
system-tools-backends
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
system-tools-backends
</silinecek_paketler>
</uygulama>
