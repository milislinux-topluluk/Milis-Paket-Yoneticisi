<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
net-tools
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/net-tools.png
</ekran_resmi>
<kurulacak_paketler>
net-tools
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
20101030
</surum>
<silinecek_paketler>
net-tools
</silinecek_paketler>
</uygulama>
