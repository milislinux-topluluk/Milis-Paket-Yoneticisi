<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dmitry
</isim>
<tanim>
Derinlemesine bilgi toplama aracı. Bilgisayarlar hakkında bilgi toplar. Olası alt alan adları, e-posta adresleri, çalışma süresi bilgilerini toplayabilir, tcp port taramaları, whois aramaları ve daha fazlasını çalıştırabilir.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/dmitry.png
</ekran_resmi>
<kurulacak_paketler>
dmitry
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
1.3a
</surum>
<silinecek_paketler>
dmitry
</silinecek_paketler>
</uygulama>
