<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dmitry
</isim>
<tanim>
Derinlemesine bilgi toplama aracı. Bilgisayarlar hakkında bilgi toplar. Olası alt alan adları, e-posta adresleri, çalışma süresi bilgilerini toplayabilir, tcp port taramaları, whois aramaları ve daha fazlasını çalıştırabilir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dmitry.png
</ekran_resmi>
<kurulacak_paketler>
dmitry
</kurulacak_paketler>
<silinecek_paketler>
dmitry
</silinecek_paketler>
</uygulama>
