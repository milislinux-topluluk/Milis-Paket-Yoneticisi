<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-lxml
</isim>
<tanim>
Libxml2 ve libxslt kitaplıkları için Python3 bağlaması.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-lxml.png
</ekran_resmi>
<kurulacak_paketler>
python3-lxml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
python3-lxml
</silinecek_paketler>
</uygulama>
