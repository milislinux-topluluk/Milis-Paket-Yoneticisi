<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-lxml
</isim>
<tanim>
Libxml2 ve libxslt kitaplıkları için Python3 bağlaması.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python3-lxml.png
</ekran_resmi>
<kurulacak_paketler>
python3-lxml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.8.0
</surum>
<silinecek_paketler>
python3-lxml
</silinecek_paketler>
</uygulama>
