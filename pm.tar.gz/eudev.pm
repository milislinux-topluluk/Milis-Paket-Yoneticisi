<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
eudev
</isim>
<tanim>
The Eudev package contains programs for dynamic creation of device nodes.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/eudev.png
</ekran_resmi>
<kurulacak_paketler>
eudev
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
eudev
</silinecek_paketler>
</uygulama>
