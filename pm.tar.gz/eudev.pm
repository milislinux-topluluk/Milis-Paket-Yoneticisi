<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
eudev
</isim>
<tanim>
The Eudev package contains programs for dynamic creation of device nodes.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/eudev.png
</ekran_resmi>
<kurulacak_paketler>
eudev
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.1.5
</surum>
<silinecek_paketler>
eudev
</silinecek_paketler>
</uygulama>
