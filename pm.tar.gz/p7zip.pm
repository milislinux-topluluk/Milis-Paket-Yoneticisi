<?xml version="1.0"?>
<uygulama>
<grup>
Ağ
</grup>
<isim>
p7zip
</isim>
<tanim>
7zip sıkıştırılmış dosya arşivinin konsol uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/p7zip.png
</ekran_resmi>
<kurulacak_paketler>
p7zip
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
16.02
</surum>
<silinecek_paketler>
p7zip
</silinecek_paketler>
</uygulama>
