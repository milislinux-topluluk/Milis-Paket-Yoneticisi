<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
nim
</isim>
<tanim>
Imperative, multi-paradigm, compiled programming language
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/nim.png
</ekran_resmi>
<kurulacak_paketler>
nim
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.17.2
</surum>
<silinecek_paketler>
nim
</silinecek_paketler>
</uygulama>
