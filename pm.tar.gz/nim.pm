<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nim
</isim>
<tanim>
Imperative, multi-paradigm, compiled programming language
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nim.png
</ekran_resmi>
<kurulacak_paketler>
nim
</kurulacak_paketler>
<silinecek_paketler>
nim
</silinecek_paketler>
</uygulama>
