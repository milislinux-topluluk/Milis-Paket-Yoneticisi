<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
luarocks-53
</isim>
<tanim>
Lua kütüphane yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/luarocks-53.png
</ekran_resmi>
<kurulacak_paketler>
luarocks-53
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
luarocks-53
</silinecek_paketler>
</uygulama>
