<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
luarocks-53
</isim>
<tanim>
Lua kütüphane yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/luarocks-53.png
</ekran_resmi>
<kurulacak_paketler>
luarocks-53
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4.3
</surum>
<silinecek_paketler>
luarocks-53
</silinecek_paketler>
</uygulama>
