<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
luarocks-53
</isim>
<tanim>
Lua kütüphane yöneticisi
</tanim>
<ekran_resmi>
file:///tmp/luarocks-53.png
</ekran_resmi>
<kurulacak_paketler>
luarocks-53
</kurulacak_paketler>
<silinecek_paketler>
luarocks-53
</silinecek_paketler>
</uygulama>
