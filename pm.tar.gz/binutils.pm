<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
binutils
</isim>
<tanim>
Linker, assembler, and other tools for handling object files.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/binutils.png
</ekran_resmi>
<kurulacak_paketler>
binutils
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.26
</surum>
<silinecek_paketler>
binutils
</silinecek_paketler>
</uygulama>
