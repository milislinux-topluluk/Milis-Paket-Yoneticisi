<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
netbeans
</isim>
<tanim>
Java, HTML5, PHP, Groovy, C ve C++ için geliştirme ortamı.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/netbeans.png
</ekran_resmi>
<kurulacak_paketler>
netbeans
</kurulacak_paketler>
<paketci>
halityilmaz1982
</paketci>
<surum>
8.2
</surum>
<silinecek_paketler>
netbeans
</silinecek_paketler>
</uygulama>
