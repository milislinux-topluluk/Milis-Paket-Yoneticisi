<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
netbeans
</isim>
<tanim>
Java, HTML5, PHP, Groovy, C ve C++ için geliştirme ortamı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/netbeans.png
</ekran_resmi>
<kurulacak_paketler>
netbeans
</kurulacak_paketler>
<silinecek_paketler>
netbeans
</silinecek_paketler>
</uygulama>
