<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
urho3d
</isim>
<tanim>
c++ kullanan hafif 2D ve 3D oyun makinesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/urho3d.png
</ekran_resmi>
<kurulacak_paketler>
urho3d
</kurulacak_paketler>
<silinecek_paketler>
urho3d
</silinecek_paketler>
</uygulama>
