<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
urho3d
</isim>
<tanim>
c++ kullanan hafif 2D ve 3D oyun makinesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/urho3d.png
</ekran_resmi>
<kurulacak_paketler>
urho3d
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.6
</surum>
<silinecek_paketler>
urho3d
</silinecek_paketler>
</uygulama>
