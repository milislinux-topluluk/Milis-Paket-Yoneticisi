<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
qpdf
</isim>
<tanim>
Qpdf paketi, PDF dosyaları üzerinde yapısal, içerik koruma dönüştürmeleri yapan komut satırı programları ve kitaplığı içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qpdf.png
</ekran_resmi>
<kurulacak_paketler>
qpdf
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
20170726
</surum>
<silinecek_paketler>
qpdf
</silinecek_paketler>
</uygulama>
