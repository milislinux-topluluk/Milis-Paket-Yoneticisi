<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
qpdf
</isim>
<tanim>
Qpdf paketi, PDF dosyaları üzerinde yapısal, içerik koruma dönüştürmeleri yapan komut satırı programları ve kitaplığı içerir.
</tanim>
<ekran_resmi>
file:///tmp/qpdf.png
</ekran_resmi>
<kurulacak_paketler>
qpdf
</kurulacak_paketler>
<silinecek_paketler>
qpdf
</silinecek_paketler>
</uygulama>
