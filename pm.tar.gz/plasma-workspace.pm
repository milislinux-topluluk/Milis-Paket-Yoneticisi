<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-workspace
</isim>
<tanim>
KDE Plasma Workspace
</tanim>
<ekran_resmi>
file:///tmp/plasma-workspace.png
</ekran_resmi>
<kurulacak_paketler>
plasma-workspace
</kurulacak_paketler>
<silinecek_paketler>
plasma-workspace
</silinecek_paketler>
</uygulama>
