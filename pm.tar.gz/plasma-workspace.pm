<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-workspace
</isim>
<tanim>
KDE Plasma Workspace
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-workspace.png
</ekran_resmi>
<kurulacak_paketler>
plasma-workspace
</kurulacak_paketler>
<paketci>
alihan-ozturk@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-workspace
</silinecek_paketler>
</uygulama>
