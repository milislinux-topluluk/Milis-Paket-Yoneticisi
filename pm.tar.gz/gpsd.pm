<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
gpsd
</isim>
<tanim>
USB / seri GPS cihazlarını desteklemek için GPS daemon ve kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gpsd.png
</ekran_resmi>
<kurulacak_paketler>
gpsd
</kurulacak_paketler>
<paketci>
Cihan_Alkan
</paketci>
<surum>
3.17
</surum>
<silinecek_paketler>
gpsd
</silinecek_paketler>
</uygulama>
