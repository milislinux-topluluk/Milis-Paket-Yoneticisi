<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telegram-bin
</isim>
<tanim>
Güvenli IM platformu olan Telegram uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telegram-bin.png
</ekran_resmi>
<kurulacak_paketler>
telegram-bin
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
telegram-bin
</silinecek_paketler>
</uygulama>
