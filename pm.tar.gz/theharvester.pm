<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
theharvester
</isim>
<tanim>
Farklı açık kaynaklarından (arama motorları, pgp anahtar sunucuları) e-posta hesapları ve alt alan adı toplamak için kullanılan araç.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/theharvester.png
</ekran_resmi>
<kurulacak_paketler>
theharvester
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
theharvester
</silinecek_paketler>
</uygulama>
