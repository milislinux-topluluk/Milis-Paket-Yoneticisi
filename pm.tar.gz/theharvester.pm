<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
theharvester
</isim>
<tanim>
Farklı açık kaynaklarından (arama motorları, pgp anahtar sunucuları) e-posta hesapları ve alt alan adı toplamak için kullanılan araç.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/theharvester.png
</ekran_resmi>
<kurulacak_paketler>
theharvester
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
56.eb08d32
</surum>
<silinecek_paketler>
theharvester
</silinecek_paketler>
</uygulama>
