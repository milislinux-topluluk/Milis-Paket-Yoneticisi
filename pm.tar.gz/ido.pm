<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ido
</isim>
<tanim>
Göstergeler için kullanılan pencere öğeleri ve diğer nesneler
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/ido.png
</ekran_resmi>
<kurulacak_paketler>
ido
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
12.10.2
</surum>
<silinecek_paketler>
ido
</silinecek_paketler>
</uygulama>
