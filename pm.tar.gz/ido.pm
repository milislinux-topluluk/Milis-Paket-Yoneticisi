<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ido
</isim>
<tanim>
Göstergeler için kullanılan pencere öğeleri ve diğer nesneler
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ido.png
</ekran_resmi>
<kurulacak_paketler>
ido
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
ido
</silinecek_paketler>
</uygulama>
