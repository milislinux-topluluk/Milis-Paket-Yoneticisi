<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mpfr
</isim>
<tanim>
The MPFR package contains functions for multiple precision math
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mpfr.png
</ekran_resmi>
<kurulacak_paketler>
mpfr
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
3.1.3
</surum>
<silinecek_paketler>
mpfr
</silinecek_paketler>
</uygulama>
