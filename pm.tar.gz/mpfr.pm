<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mpfr
</isim>
<tanim>
The MPFR package contains functions for multiple precision math
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mpfr.png
</ekran_resmi>
<kurulacak_paketler>
mpfr
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
3.1.3
</surum>
<silinecek_paketler>
mpfr
</silinecek_paketler>
</uygulama>
