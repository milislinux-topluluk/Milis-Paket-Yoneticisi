<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gtksourceview3
</isim>
<tanim>
GtkSourceView, standart GTK+ metin widget'ını genişleten bir metin widgettır
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gtksourceview3.png
</ekran_resmi>
<kurulacak_paketler>
gtksourceview3
</kurulacak_paketler>
<paketci>
milisarge yasarciv67@gmail.com
</paketci>
<surum>
3.24.2
</surum>
<silinecek_paketler>
gtksourceview3
</silinecek_paketler>
</uygulama>
