<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtksourceview3
</isim>
<tanim>
GtkSourceView, standart GTK+ metin widget'ını genişleten bir metin widgettır
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtksourceview3.png
</ekran_resmi>
<kurulacak_paketler>
gtksourceview3
</kurulacak_paketler>
<silinecek_paketler>
gtksourceview3
</silinecek_paketler>
</uygulama>
