<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
glew
</isim>
<tanim>
OpenGL Extension Wrangler Library (GLEW), çapraz platform açık kaynak C / C ++ uzantısı yükleme kitaplığıdır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/glew.png
</ekran_resmi>
<kurulacak_paketler>
glew
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
glew
</silinecek_paketler>
</uygulama>
