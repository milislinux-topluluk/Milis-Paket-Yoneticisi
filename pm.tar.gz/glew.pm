<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
glew
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/glew.png
</ekran_resmi>
<kurulacak_paketler>
glew
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.0.0
</surum>
<silinecek_paketler>
glew
</silinecek_paketler>
</uygulama>
