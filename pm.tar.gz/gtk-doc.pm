<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk-doc
</isim>
<tanim>
GTK-Doc, C koduna eklenen yorumlardan API dokümantasyonu üretmeye başlayan bir projedir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtk-doc.png
</ekran_resmi>
<kurulacak_paketler>
gtk-doc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.25
</surum>
<silinecek_paketler>
gtk-doc
</silinecek_paketler>
</uygulama>
