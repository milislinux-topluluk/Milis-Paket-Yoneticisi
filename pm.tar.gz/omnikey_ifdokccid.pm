<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
omnikey_ifdokccid
</isim>
<tanim>
HID Global OMNIKEY CardMan Akıllı Kart okuyucu serisi için CCID sürücüsü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/omnikey_ifdokccid.png
</ekran_resmi>
<kurulacak_paketler>
omnikey_ifdokccid
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
omnikey_ifdokccid
</silinecek_paketler>
</uygulama>
