<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
omnikey_ifdokccid
</isim>
<tanim>
HID Global OMNIKEY CardMan Akıllı Kart okuyucu serisi için CCID sürücüsü
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/omnikey_ifdokccid.png
</ekran_resmi>
<kurulacak_paketler>
omnikey_ifdokccid
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
4.2.8
</surum>
<silinecek_paketler>
omnikey_ifdokccid
</silinecek_paketler>
</uygulama>
