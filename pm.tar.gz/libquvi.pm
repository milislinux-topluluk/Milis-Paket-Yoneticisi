<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libquvi
</isim>
<tanim>
video linklerini ayrıştıran kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libquvi.png
</ekran_resmi>
<kurulacak_paketler>
libquvi
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.4.1
</surum>
<silinecek_paketler>
libquvi
</silinecek_paketler>
</uygulama>
