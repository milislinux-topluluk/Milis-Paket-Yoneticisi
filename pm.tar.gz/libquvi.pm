<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libquvi
</isim>
<tanim>
video linklerini ayrıştıran kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libquvi.png
</ekran_resmi>
<kurulacak_paketler>
libquvi
</kurulacak_paketler>
<silinecek_paketler>
libquvi
</silinecek_paketler>
</uygulama>
