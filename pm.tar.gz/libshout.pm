<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libshout
</isim>
<tanim>
Shoutcast / icecast sunucusuna erişmek için kullanılan kitaplık
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libshout.png
</ekran_resmi>
<kurulacak_paketler>
libshout
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4.1
</surum>
<silinecek_paketler>
libshout
</silinecek_paketler>
</uygulama>
