<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libshout
</isim>
<tanim>
Shoutcast / icecast sunucusuna erişmek için kullanılan kitaplık
</tanim>
<ekran_resmi>
file:///tmp/libshout.png
</ekran_resmi>
<kurulacak_paketler>
libshout
</kurulacak_paketler>
<silinecek_paketler>
libshout
</silinecek_paketler>
</uygulama>
