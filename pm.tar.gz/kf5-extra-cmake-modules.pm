<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-extra-cmake-modules
</isim>
<tanim>
Tüm KDE Framework'ler tarafından kullanılan ekstra CMake modülleri 5 paketi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-extra-cmake-modules.png
</ekran_resmi>
<kurulacak_paketler>
kf5-extra-cmake-modules
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-extra-cmake-modules
</silinecek_paketler>
</uygulama>
