<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
miniupnpc
</isim>
<tanim>
Internet Ağ Geçidi Aygıtlarına erişmek için küçük bir UPnP istemci kitaplığı/aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/miniupnpc.png
</ekran_resmi>
<kurulacak_paketler>
miniupnpc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
miniupnpc
</silinecek_paketler>
</uygulama>
