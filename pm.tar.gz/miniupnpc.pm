<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
miniupnpc
</isim>
<tanim>
A small UPnP client library/tool to access Internet Gateway Devices
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/miniupnpc.png
</ekran_resmi>
<kurulacak_paketler>
miniupnpc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.9
</surum>
<silinecek_paketler>
miniupnpc
</silinecek_paketler>
</uygulama>
