<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxdm
</isim>
<tanim>
hafif linux giriş yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lxdm.png
</ekran_resmi>
<kurulacak_paketler>
lxdm
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.5.3
</surum>
<silinecek_paketler>
lxdm
</silinecek_paketler>
</uygulama>
