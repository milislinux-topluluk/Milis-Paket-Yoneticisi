<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxdm
</isim>
<tanim>
hafif linux giriş yöneticisi
</tanim>
<ekran_resmi>
file:///tmp/lxdm.png
</ekran_resmi>
<kurulacak_paketler>
lxdm
</kurulacak_paketler>
<silinecek_paketler>
lxdm
</silinecek_paketler>
</uygulama>
