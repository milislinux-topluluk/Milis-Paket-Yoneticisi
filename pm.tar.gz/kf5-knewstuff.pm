<?xml version="1.0"?>
<uygulama>
<grup>
Kde
</grup>
<isim>
kf5-knewstuff
</isim>
<tanim>
Uygulama varlıklarını ağdan indirmeye destek
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-knewstuff.png
</ekran_resmi>
<kurulacak_paketler>
kf5-knewstuff
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-knewstuff
</silinecek_paketler>
</uygulama>
