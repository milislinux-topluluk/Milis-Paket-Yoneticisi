<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
indicator-sound
</isim>
<tanim>
Birleştirilmiş ses menü göstergesi.
</tanim>
<ekran_resmi>
file:///tmp/indicator-sound.png
</ekran_resmi>
<kurulacak_paketler>
indicator-sound
</kurulacak_paketler>
<silinecek_paketler>
indicator-sound
</silinecek_paketler>
</uygulama>
