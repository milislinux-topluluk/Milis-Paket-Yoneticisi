<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
indicator-sound
</isim>
<tanim>
Birleştirilmiş ses menü göstergesi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/indicator-sound.png
</ekran_resmi>
<kurulacak_paketler>
indicator-sound
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
indicator-sound
</silinecek_paketler>
</uygulama>
