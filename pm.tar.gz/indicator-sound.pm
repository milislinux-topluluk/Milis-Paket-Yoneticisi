<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
indicator-sound
</isim>
<tanim>
Birleştirilmiş ses menü göstergesi.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/indicator-sound.png
</ekran_resmi>
<kurulacak_paketler>
indicator-sound
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
12.10.1
</surum>
<silinecek_paketler>
indicator-sound
</silinecek_paketler>
</uygulama>
