<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-xdg
</isim>
<tanim>
FreeDesktop standartlarına erişmek için kullanılan Python3 kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-xdg.png
</ekran_resmi>
<kurulacak_paketler>
python3-xdg
</kurulacak_paketler>
<silinecek_paketler>
python3-xdg
</silinecek_paketler>
</uygulama>
