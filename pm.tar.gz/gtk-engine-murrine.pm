<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk-engine-murrine
</isim>
<tanim>
Cairo based GTK engine.
</tanim>
<ekran_resmi>
file:///tmp/gtk-engine-murrine.png
</ekran_resmi>
<kurulacak_paketler>
gtk-engine-murrine
</kurulacak_paketler>
<silinecek_paketler>
gtk-engine-murrine
</silinecek_paketler>
</uygulama>
