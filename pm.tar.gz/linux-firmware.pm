<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
linux-firmware
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/linux-firmware.png
</ekran_resmi>
<kurulacak_paketler>
linux-firmware
</kurulacak_paketler>
<silinecek_paketler>
linux-firmware
</silinecek_paketler>
</uygulama>
