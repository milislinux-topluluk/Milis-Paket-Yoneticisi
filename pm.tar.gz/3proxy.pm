<?xml version="1.0"?>
<uygulama>
<grup>
Ağ
</grup>
<isim>
3proxy
</isim>
<tanim>
Her ortam için hafif vekil sunucu
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/3proxy.png
</ekran_resmi>
<kurulacak_paketler>
3proxy
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.8.6
</surum>
<silinecek_paketler>
3proxy
</silinecek_paketler>
</uygulama>
