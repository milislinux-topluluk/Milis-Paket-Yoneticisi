<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-tk
</isim>
<tanim>
Perl için bir grafik kullanıcı arabirimi araç takımı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-tk.png
</ekran_resmi>
<kurulacak_paketler>
perl-tk
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
perl-tk
</silinecek_paketler>
</uygulama>
