<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-ki18n
</isim>
<tanim>
Gelişmiş uluslararasılaşma çerçevesi
</tanim>
<ekran_resmi>
file:///tmp/kf5-ki18n.png
</ekran_resmi>
<kurulacak_paketler>
kf5-ki18n
</kurulacak_paketler>
<silinecek_paketler>
kf5-ki18n
</silinecek_paketler>
</uygulama>
