<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-ki18n
</isim>
<tanim>
Gelişmiş uluslararasılaşma çerçevesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-ki18n.png
</ekran_resmi>
<kurulacak_paketler>
kf5-ki18n
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
kf5-ki18n
</silinecek_paketler>
</uygulama>
