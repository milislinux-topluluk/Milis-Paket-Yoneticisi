<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
menu-cache
</isim>
<tanim>
Freedesktop.org uyumlu menüler için önbellekleme mekanizması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/menu-cache.png
</ekran_resmi>
<kurulacak_paketler>
menu-cache
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.0.1
</surum>
<silinecek_paketler>
menu-cache
</silinecek_paketler>
</uygulama>
