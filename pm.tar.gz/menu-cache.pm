<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
menu-cache
</isim>
<tanim>
Freedesktop.org uyumlu menüler için önbellekleme mekanizması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/menu-cache.png
</ekran_resmi>
<kurulacak_paketler>
menu-cache
</kurulacak_paketler>
<silinecek_paketler>
menu-cache
</silinecek_paketler>
</uygulama>
