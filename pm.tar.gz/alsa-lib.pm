<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
alsa-lib
</isim>
<tanim>
An alternative implementation of Linux sound support
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/alsa-lib.png
</ekran_resmi>
<kurulacak_paketler>
alsa-lib
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
alsa-lib
</silinecek_paketler>
</uygulama>
