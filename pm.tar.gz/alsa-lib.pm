<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
alsa-lib
</isim>
<tanim>
An alternative implementation of Linux sound support
</tanim>
<ekran_resmi>
file:///tmp/alsa-lib.png
</ekran_resmi>
<kurulacak_paketler>
alsa-lib
</kurulacak_paketler>
<silinecek_paketler>
alsa-lib
</silinecek_paketler>
</uygulama>
