<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jwm
</isim>
<tanim>
Joe'nun pencere yöneticisi yalnızca Xlib'yi en az kullanır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jwm.png
</ekran_resmi>
<kurulacak_paketler>
jwm
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
jwm
</silinecek_paketler>
</uygulama>
