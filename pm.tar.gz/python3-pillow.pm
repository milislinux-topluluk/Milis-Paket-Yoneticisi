<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-pillow
</isim>
<tanim>
Python Görüntüleme Kitaplığı (PIL) çatalı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-pillow.png
</ekran_resmi>
<kurulacak_paketler>
python3-pillow
</kurulacak_paketler>
<silinecek_paketler>
python3-pillow
</silinecek_paketler>
</uygulama>
