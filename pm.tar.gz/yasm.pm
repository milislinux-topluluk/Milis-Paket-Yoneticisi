<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
yasm
</isim>
<tanim>
A rewrite of NASM to allow for multiple syntax supported (NASM, TASM, GAS, etc.)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/yasm.png
</ekran_resmi>
<kurulacak_paketler>
yasm
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
yasm
</silinecek_paketler>
</uygulama>
