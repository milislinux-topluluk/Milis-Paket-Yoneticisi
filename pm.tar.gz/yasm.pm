<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
yasm
</isim>
<tanim>
A rewrite of NASM to allow for multiple syntax supported (NASM, TASM, GAS, etc.)
</tanim>
<ekran_resmi>
file:///tmp/yasm.png
</ekran_resmi>
<kurulacak_paketler>
yasm
</kurulacak_paketler>
<silinecek_paketler>
yasm
</silinecek_paketler>
</uygulama>
