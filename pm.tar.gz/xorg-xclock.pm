<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xorg-xclock
</isim>
<tanim>
clock analog for X mainly pout tester all X
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-xclock.png
</ekran_resmi>
<kurulacak_paketler>
xorg-xclock
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.0.7
</surum>
<silinecek_paketler>
xorg-xclock
</silinecek_paketler>
</uygulama>
