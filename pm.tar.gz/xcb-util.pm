<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xcb-util
</isim>
<tanim>
XCB utilities library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xcb-util.png
</ekran_resmi>
<kurulacak_paketler>
xcb-util
</kurulacak_paketler>
<silinecek_paketler>
xcb-util
</silinecek_paketler>
</uygulama>
