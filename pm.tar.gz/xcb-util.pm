<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xcb-util
</isim>
<tanim>
XCB utilities library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xcb-util.png
</ekran_resmi>
<kurulacak_paketler>
xcb-util
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.4.0
</surum>
<silinecek_paketler>
xcb-util
</silinecek_paketler>
</uygulama>
