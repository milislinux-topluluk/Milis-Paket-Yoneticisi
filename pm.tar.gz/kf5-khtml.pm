<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-khtml
</isim>
<tanim>
KHTML API'leri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-khtml.png
</ekran_resmi>
<kurulacak_paketler>
kf5-khtml
</kurulacak_paketler>
<silinecek_paketler>
kf5-khtml
</silinecek_paketler>
</uygulama>
