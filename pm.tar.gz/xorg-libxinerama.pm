<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxinerama
</isim>
<tanim>
libXinerama, library X Xinerama client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxinerama.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxinerama
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
xorg-libxinerama
</silinecek_paketler>
</uygulama>
