<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wxgtk28
</isim>
<tanim>
GTK+ implementation of wxWidgets API for GUI
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/wxgtk28.png
</ekran_resmi>
<kurulacak_paketler>
wxgtk28
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.8.12.1
</surum>
<silinecek_paketler>
wxgtk28
</silinecek_paketler>
</uygulama>
