<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wxgtk28
</isim>
<tanim>
GTK+ implementation of wxWidgets API for GUI
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wxgtk28.png
</ekran_resmi>
<kurulacak_paketler>
wxgtk28
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.8.12.1
</surum>
<silinecek_paketler>
wxgtk28
</silinecek_paketler>
</uygulama>
