<?xml version="1.0"?>
<uygulama>
<grup>
Ağ
</grup>
<isim>
cjdns
</isim>
<tanim>
Güvenlik, ölçeklenebilirlik, hız ve kullanım kolaylığı için tasarlanmış bir yönlendirme motoru
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cjdns.png
</ekran_resmi>
<kurulacak_paketler>
cjdns
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
19.1
</surum>
<silinecek_paketler>
cjdns
</silinecek_paketler>
</uygulama>
