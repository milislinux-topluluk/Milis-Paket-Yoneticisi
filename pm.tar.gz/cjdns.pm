<?xml version="1.0"?>
<uygulama>
<grup>
ağ
</grup>
<isim>
cjdns
</isim>
<tanim>
Güvenlik, ölçeklenebilirlik, hız ve kullanım kolaylığı için tasarlanmış bir yönlendirme motoru
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/cjdns.png
</ekran_resmi>
<kurulacak_paketler>
cjdns
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
cjdns
</silinecek_paketler>
</uygulama>
