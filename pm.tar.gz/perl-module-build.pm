<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-module-build
</isim>
<tanim>
perl module building
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-module-build.png
</ekran_resmi>
<kurulacak_paketler>
perl-module-build
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.4216
</surum>
<silinecek_paketler>
perl-module-build
</silinecek_paketler>
</uygulama>
