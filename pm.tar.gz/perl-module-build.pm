<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-module-build
</isim>
<tanim>
Perl modülü binası
</tanim>
<ekran_resmi>
file:///tmp/perl-module-build.png
</ekran_resmi>
<kurulacak_paketler>
perl-module-build
</kurulacak_paketler>
<silinecek_paketler>
perl-module-build
</silinecek_paketler>
</uygulama>
