<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
openjpeg
</isim>
<tanim>
OpenJPEG is an open-source implementation of the JPEG-2000 standard.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/openjpeg.png
</ekran_resmi>
<kurulacak_paketler>
openjpeg
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
openjpeg
</silinecek_paketler>
</uygulama>
