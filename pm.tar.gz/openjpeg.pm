<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
openjpeg
</isim>
<tanim>
OpenJPEG is an open-source implementation of the JPEG-2000 standard.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/openjpeg.png
</ekran_resmi>
<kurulacak_paketler>
openjpeg
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.5.2
</surum>
<silinecek_paketler>
openjpeg
</silinecek_paketler>
</uygulama>
