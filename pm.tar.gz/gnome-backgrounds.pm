<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-backgrounds
</isim>
<tanim>
GNOME için arkaplan resim ve verileri
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-backgrounds.png
</ekran_resmi>
<kurulacak_paketler>
gnome-backgrounds
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.1
</surum>
<silinecek_paketler>
gnome-backgrounds
</silinecek_paketler>
</uygulama>
