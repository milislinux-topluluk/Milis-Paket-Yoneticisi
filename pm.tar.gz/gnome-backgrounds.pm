<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-backgrounds
</isim>
<tanim>
GNOME için arkaplan resim ve verileri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-backgrounds.png
</ekran_resmi>
<kurulacak_paketler>
gnome-backgrounds
</kurulacak_paketler>
<silinecek_paketler>
gnome-backgrounds
</silinecek_paketler>
</uygulama>
