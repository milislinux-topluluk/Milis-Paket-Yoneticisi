<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pamsshagentauth
</isim>
<tanim>
ssh-agent ile pam modülünün yetkilendirilmesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/pamsshagentauth.png
</ekran_resmi>
<kurulacak_paketler>
pamsshagentauth
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.10.3
</surum>
<silinecek_paketler>
pamsshagentauth
</silinecek_paketler>
</uygulama>
