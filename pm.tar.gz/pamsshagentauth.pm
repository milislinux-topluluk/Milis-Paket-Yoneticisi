<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pamsshagentauth
</isim>
<tanim>
ssh-agent ile pam modülünün yetkilendirilmesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pamsshagentauth.png
</ekran_resmi>
<kurulacak_paketler>
pamsshagentauth
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.10.3
</surum>
<silinecek_paketler>
pamsshagentauth
</silinecek_paketler>
</uygulama>
