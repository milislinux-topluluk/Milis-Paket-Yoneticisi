<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nvidia
</isim>
<tanim>
nVIDIA Linux Display Driver
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nvidia.png
</ekran_resmi>
<kurulacak_paketler>
nvidia
</kurulacak_paketler>
<silinecek_paketler>
nvidia
</silinecek_paketler>
</uygulama>
