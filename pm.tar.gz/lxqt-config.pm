<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxqt-config
</isim>
<tanim>
Lxqt-config paketi LXQt sistem ayarlar merkezi sağlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxqt-config.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-config
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
lxqt-config
</silinecek_paketler>
</uygulama>
