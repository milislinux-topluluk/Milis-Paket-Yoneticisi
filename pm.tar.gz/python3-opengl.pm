<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-opengl
</isim>
<tanim>
The cross platform Python binding to OpenGL and related APIs.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python3-opengl.png
</ekran_resmi>
<kurulacak_paketler>
python3-opengl
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
3.1.0
</surum>
<silinecek_paketler>
python3-opengl
</silinecek_paketler>
</uygulama>
