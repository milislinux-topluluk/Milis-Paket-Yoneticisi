<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-opengl
</isim>
<tanim>
The cross platform Python binding to OpenGL and related APIs.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-opengl.png
</ekran_resmi>
<kurulacak_paketler>
python3-opengl
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
3.1.0
</surum>
<silinecek_paketler>
python3-opengl
</silinecek_paketler>
</uygulama>
