<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-opengl
</isim>
<tanim>
The cross platform Python binding to OpenGL and related APIs.
</tanim>
<ekran_resmi>
file:///tmp/python3-opengl.png
</ekran_resmi>
<kurulacak_paketler>
python3-opengl
</kurulacak_paketler>
<silinecek_paketler>
python3-opengl
</silinecek_paketler>
</uygulama>
