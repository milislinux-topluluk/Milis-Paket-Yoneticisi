<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xorg-imake
</isim>
<tanim>
imake derleme sistemi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-imake.png
</ekran_resmi>
<kurulacak_paketler>
xorg-imake
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.0.7
</surum>
<silinecek_paketler>
xorg-imake
</silinecek_paketler>
</uygulama>
