<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kcodecs
</isim>
<tanim>
Çeşitli kodlamaları kullanarak dizeleri işlemek için bir yöntem koleksiyonu sağlayın
</tanim>
<ekran_resmi>
file:///tmp/kf5-kcodecs.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kcodecs
</kurulacak_paketler>
<silinecek_paketler>
kf5-kcodecs
</silinecek_paketler>
</uygulama>
