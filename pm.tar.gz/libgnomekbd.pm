<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libgnomekbd
</isim>
<tanim>
GNOME klavye kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libgnomekbd.png
</ekran_resmi>
<kurulacak_paketler>
libgnomekbd
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.0.1
</surum>
<silinecek_paketler>
libgnomekbd
</silinecek_paketler>
</uygulama>
