<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libgnomekbd
</isim>
<tanim>
GNOME klavye kitaplığı
</tanim>
<ekran_resmi>
file:///tmp/libgnomekbd.png
</ekran_resmi>
<kurulacak_paketler>
libgnomekbd
</kurulacak_paketler>
<silinecek_paketler>
libgnomekbd
</silinecek_paketler>
</uygulama>
