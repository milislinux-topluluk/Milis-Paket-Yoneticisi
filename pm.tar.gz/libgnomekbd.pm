<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libgnomekbd
</isim>
<tanim>
GNOME klavye kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libgnomekbd.png
</ekran_resmi>
<kurulacak_paketler>
libgnomekbd
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
libgnomekbd
</silinecek_paketler>
</uygulama>
