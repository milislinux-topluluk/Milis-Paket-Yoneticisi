<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
thunar-vcs-plugin
</isim>
<tanim>
Thunar için SVN ve GIT entegrasyonu.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/thunar-vcs-plugin.png
</ekran_resmi>
<kurulacak_paketler>
thunar-vcs-plugin
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.1.5
</surum>
<silinecek_paketler>
thunar-vcs-plugin
</silinecek_paketler>
</uygulama>
