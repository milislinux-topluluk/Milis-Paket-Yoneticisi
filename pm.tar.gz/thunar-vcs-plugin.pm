<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
thunar-vcs-plugin
</isim>
<tanim>
Thunar için SVN ve GIT entegrasyonu.
</tanim>
<ekran_resmi>
file:///tmp/thunar-vcs-plugin.png
</ekran_resmi>
<kurulacak_paketler>
thunar-vcs-plugin
</kurulacak_paketler>
<silinecek_paketler>
thunar-vcs-plugin
</silinecek_paketler>
</uygulama>
