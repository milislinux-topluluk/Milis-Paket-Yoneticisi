<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kde5-l10n
</isim>
<tanim>
Many Localization for KDE5
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kde5-l10n.png
</ekran_resmi>
<kurulacak_paketler>
kde5-l10n
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kde5-l10n
</silinecek_paketler>
</uygulama>
