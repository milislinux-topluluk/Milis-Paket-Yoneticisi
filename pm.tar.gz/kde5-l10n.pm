<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kde5-l10n
</isim>
<tanim>
Many Localization for KDE5
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kde5-l10n.png
</ekran_resmi>
<kurulacak_paketler>
kde5-l10n
</kurulacak_paketler>
<silinecek_paketler>
kde5-l10n
</silinecek_paketler>
</uygulama>
