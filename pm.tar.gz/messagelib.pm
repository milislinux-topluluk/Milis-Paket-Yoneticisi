<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
messagelib
</isim>
<tanim>
KDE PIM messaging library
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/messagelib.png
</ekran_resmi>
<kurulacak_paketler>
messagelib
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
messagelib
</silinecek_paketler>
</uygulama>
