<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
messagelib
</isim>
<tanim>
KDE PIM mesajlaşma kütüphanesi
</tanim>
<ekran_resmi>
file:///tmp/messagelib.png
</ekran_resmi>
<kurulacak_paketler>
messagelib
</kurulacak_paketler>
<silinecek_paketler>
messagelib
</silinecek_paketler>
</uygulama>
