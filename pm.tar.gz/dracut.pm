<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dracut
</isim>
<tanim>
önyükleme için gereken her şeyi içeren özel bir initramfs görüntüsü oluşturma aracı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/dracut.png
</ekran_resmi>
<kurulacak_paketler>
dracut
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
045
</surum>
<silinecek_paketler>
dracut
</silinecek_paketler>
</uygulama>
