<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dracut
</isim>
<tanim>
önyükleme için gereken her şeyi içeren özel bir initramfs görüntüsü oluşturma aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dracut.png
</ekran_resmi>
<kurulacak_paketler>
dracut
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
045
</surum>
<silinecek_paketler>
dracut
</silinecek_paketler>
</uygulama>
