<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
moka-icon-theme
</isim>
<tanim>
Moka, net, basit ve tutarlı olacak şekilde tasarlanmış, stil sahibi bir Linux masaüstü simge setidir. Moka Icon Teması (simge varlıkları ve kaynakları) bir Creative Commons Attribution-ShareAlike 4.0 lisansı altındadır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/moka-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
moka-icon-theme
</kurulacak_paketler>
<silinecek_paketler>
moka-icon-theme
</silinecek_paketler>
</uygulama>
