<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
moka-icon-theme
</isim>
<tanim>
Moka, net, basit ve tutarlı olacak şekilde tasarlanmış, stil sahibi bir Linux masaüstü simge setidir. Moka Icon Teması (simge varlıkları ve kaynakları) bir Creative Commons Attribution-ShareAlike 4.0 lisansı altındadır.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/moka-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
moka-icon-theme
</kurulacak_paketler>
<paketci>
yasarciv
</paketci>
<surum>
5.3.5
</surum>
<silinecek_paketler>
moka-icon-theme
</silinecek_paketler>
</uygulama>
