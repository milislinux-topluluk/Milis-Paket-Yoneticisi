<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libxml2
</isim>
<tanim>
XML dosyalarını ayrıştırmak için kullanılan kitaplıklar ve yardımcı programlar.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libxml2.png
</ekran_resmi>
<kurulacak_paketler>
libxml2
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.9.5
</surum>
<silinecek_paketler>
libxml2
</silinecek_paketler>
</uygulama>
