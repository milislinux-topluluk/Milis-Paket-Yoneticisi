<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libxml2
</isim>
<tanim>
XML dosyalarını ayrıştırmak için kullanılan kitaplıklar ve yardımcı programlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libxml2.png
</ekran_resmi>
<kurulacak_paketler>
libxml2
</kurulacak_paketler>
<silinecek_paketler>
libxml2
</silinecek_paketler>
</uygulama>
