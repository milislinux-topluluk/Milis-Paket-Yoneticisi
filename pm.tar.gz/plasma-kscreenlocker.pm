<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-kscreenlocker
</isim>
<tanim>
Library and components for secure lock screen architecture
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-kscreenlocker.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kscreenlocker
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-kscreenlocker
</silinecek_paketler>
</uygulama>
