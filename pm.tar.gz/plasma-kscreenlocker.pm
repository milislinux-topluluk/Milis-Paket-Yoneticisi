<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-kscreenlocker
</isim>
<tanim>
Library and components for secure lock screen architecture
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-kscreenlocker.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kscreenlocker
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
plasma-kscreenlocker
</silinecek_paketler>
</uygulama>
