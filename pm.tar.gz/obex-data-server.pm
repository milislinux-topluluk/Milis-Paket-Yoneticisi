<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
obex-data-server
</isim>
<tanim>
OBEX Veri Sunucusu paketi, üst düzey OBEX istemci ve sunucu tarafında işlevsellik sağlayan D-Bus servisini içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/obex-data-server.png
</ekran_resmi>
<kurulacak_paketler>
obex-data-server
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.4.6
</surum>
<silinecek_paketler>
obex-data-server
</silinecek_paketler>
</uygulama>
