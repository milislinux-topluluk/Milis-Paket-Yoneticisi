<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
connman
</isim>
<tanim>
Kablosuz LAN ağı programı (git çıkışı)
</tanim>
<ekran_resmi>
file:///tmp/connman.png
</ekran_resmi>
<kurulacak_paketler>
connman
</kurulacak_paketler>
<silinecek_paketler>
connman
</silinecek_paketler>
</uygulama>
