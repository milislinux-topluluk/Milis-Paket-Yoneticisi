<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
connman
</isim>
<tanim>
Kablosuz LAN ağı programı (git çıkışı)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/connman.png
</ekran_resmi>
<kurulacak_paketler>
connman
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
connman
</silinecek_paketler>
</uygulama>
