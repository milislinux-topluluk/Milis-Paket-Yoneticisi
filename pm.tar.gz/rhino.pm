<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
rhino
</isim>
<tanim>
JavaScript in java gerçeklemesi
</tanim>
<ekran_resmi>
file:///tmp/rhino.png
</ekran_resmi>
<kurulacak_paketler>
rhino
</kurulacak_paketler>
<silinecek_paketler>
rhino
</silinecek_paketler>
</uygulama>
