<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
rhino
</isim>
<tanim>
JavaScript in java gerçeklemesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/rhino.png
</ekran_resmi>
<kurulacak_paketler>
rhino
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
rhino
</silinecek_paketler>
</uygulama>
