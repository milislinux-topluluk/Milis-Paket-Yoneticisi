<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
rhino
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/rhino.png
</ekran_resmi>
<kurulacak_paketler>
rhino
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.7.7.1
</surum>
<silinecek_paketler>
rhino
</silinecek_paketler>
</uygulama>
