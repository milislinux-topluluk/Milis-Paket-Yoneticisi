<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
simple-scan
</isim>
<tanim>
Basit tarama arayüzü programı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/simple-scan.png
</ekran_resmi>
<kurulacak_paketler>
simple-scan
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.12.2
</surum>
<silinecek_paketler>
simple-scan
</silinecek_paketler>
</uygulama>
