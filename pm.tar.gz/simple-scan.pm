<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
simple-scan
</isim>
<tanim>
Basit tarama arayüzü programı
</tanim>
<ekran_resmi>
file:///tmp/simple-scan.png
</ekran_resmi>
<kurulacak_paketler>
simple-scan
</kurulacak_paketler>
<silinecek_paketler>
simple-scan
</silinecek_paketler>
</uygulama>
