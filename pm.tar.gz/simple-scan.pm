<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
simple-scan
</isim>
<tanim>
Basit tarama arayüzü programı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/simple-scan.png
</ekran_resmi>
<kurulacak_paketler>
simple-scan
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
simple-scan
</silinecek_paketler>
</uygulama>
