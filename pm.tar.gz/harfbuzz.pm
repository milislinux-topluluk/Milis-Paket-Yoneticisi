<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
harfbuzz
</isim>
<tanim>
OpenType metin şekillendirme motoru
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/harfbuzz.png
</ekran_resmi>
<kurulacak_paketler>
harfbuzz
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.5.1
</surum>
<silinecek_paketler>
harfbuzz
</silinecek_paketler>
</uygulama>
