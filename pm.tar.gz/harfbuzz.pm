<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
harfbuzz
</isim>
<tanim>
OpenType metin şekillendirme motoru
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/harfbuzz.png
</ekran_resmi>
<kurulacak_paketler>
harfbuzz
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<silinecek_paketler>
harfbuzz
</silinecek_paketler>
</uygulama>
