<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
flac
</isim>
<tanim>
Free Lossless Audio Codec
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/flac.png
</ekran_resmi>
<kurulacak_paketler>
flac
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.3.1
</surum>
<silinecek_paketler>
flac
</silinecek_paketler>
</uygulama>
