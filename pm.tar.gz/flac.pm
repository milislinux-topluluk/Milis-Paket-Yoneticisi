<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
flac
</isim>
<tanim>
Free Lossless Audio Codec
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/flac.png
</ekran_resmi>
<kurulacak_paketler>
flac
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.3.1
</surum>
<silinecek_paketler>
flac
</silinecek_paketler>
</uygulama>
