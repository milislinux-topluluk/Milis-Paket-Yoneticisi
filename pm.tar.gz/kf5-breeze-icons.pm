<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kf5-breeze-icons
</isim>
<tanim>
Kf5 için Breeze Icon Teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-breeze-icons.png
</ekran_resmi>
<kurulacak_paketler>
kf5-breeze-icons
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-breeze-icons
</silinecek_paketler>
</uygulama>
