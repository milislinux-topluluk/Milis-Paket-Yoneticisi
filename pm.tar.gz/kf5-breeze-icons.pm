<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-breeze-icons
</isim>
<tanim>
Kf5 için Breeze Icon Teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-breeze-icons.png
</ekran_resmi>
<kurulacak_paketler>
kf5-breeze-icons
</kurulacak_paketler>
<silinecek_paketler>
kf5-breeze-icons
</silinecek_paketler>
</uygulama>
