<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libvlc
</isim>
<tanim>
Library from vlc
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libvlc.png
</ekran_resmi>
<kurulacak_paketler>
libvlc
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
3.0.0
</surum>
<silinecek_paketler>
libvlc
</silinecek_paketler>
</uygulama>
