<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libvlc
</isim>
<tanim>
Vlc'den kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libvlc.png
</ekran_resmi>
<kurulacak_paketler>
libvlc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.0.0
</surum>
<silinecek_paketler>
libvlc
</silinecek_paketler>
</uygulama>
