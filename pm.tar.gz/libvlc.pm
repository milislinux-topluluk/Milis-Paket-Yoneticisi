<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libvlc
</isim>
<tanim>
Vlc'den kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libvlc.png
</ekran_resmi>
<kurulacak_paketler>
libvlc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libvlc
</silinecek_paketler>
</uygulama>
