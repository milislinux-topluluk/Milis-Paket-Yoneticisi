<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gawk
</isim>
<tanim>
The Gawk package contains programs for manipulating text files.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gawk.png
</ekran_resmi>
<kurulacak_paketler>
gawk
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
4.1.3
</surum>
<silinecek_paketler>
gawk
</silinecek_paketler>
</uygulama>
