<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gawk
</isim>
<tanim>
The Gawk package contains programs for manipulating text files.
</tanim>
<ekran_resmi>
file:///tmp/gawk.png
</ekran_resmi>
<kurulacak_paketler>
gawk
</kurulacak_paketler>
<silinecek_paketler>
gawk
</silinecek_paketler>
</uygulama>
