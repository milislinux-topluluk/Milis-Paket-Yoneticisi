<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gawk
</isim>
<tanim>
The Gawk package contains programs for manipulating text files.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gawk.png
</ekran_resmi>
<kurulacak_paketler>
gawk
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
4.1.3
</surum>
<silinecek_paketler>
gawk
</silinecek_paketler>
</uygulama>
