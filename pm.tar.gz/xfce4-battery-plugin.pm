<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xfce4-battery-plugin
</isim>
<tanim>
A battery monitor plugin for the Xfce panel
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xfce4-battery-plugin.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-battery-plugin
</kurulacak_paketler>
<paketci>
tyrry at nutyx dot org
</paketci>
<surum>
1.0.5
</surum>
<silinecek_paketler>
xfce4-battery-plugin
</silinecek_paketler>
</uygulama>
