<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
the_silver_searcher
</isim>
<tanim>
Hızlı kod arama aracı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/the_silver_searcher.png
</ekran_resmi>
<kurulacak_paketler>
the_silver_searcher
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.1.0
</surum>
<silinecek_paketler>
the_silver_searcher
</silinecek_paketler>
</uygulama>
