<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
the_silver_searcher
</isim>
<tanim>
Hızlı kod arama aracı
</tanim>
<ekran_resmi>
file:///tmp/the_silver_searcher.png
</ekran_resmi>
<kurulacak_paketler>
the_silver_searcher
</kurulacak_paketler>
<silinecek_paketler>
the_silver_searcher
</silinecek_paketler>
</uygulama>
