<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
movit
</isim>
<tanim>
The modern video toolkit
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/movit.png
</ekran_resmi>
<kurulacak_paketler>
movit
</kurulacak_paketler>
<silinecek_paketler>
movit
</silinecek_paketler>
</uygulama>
