<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
movit
</isim>
<tanim>
Modern video araç seti
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/movit.png
</ekran_resmi>
<kurulacak_paketler>
movit
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.3.2
</surum>
<silinecek_paketler>
movit
</silinecek_paketler>
</uygulama>
