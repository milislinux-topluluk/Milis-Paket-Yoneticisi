<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
giblib
</isim>
<tanim>
A library that feh uses as a wrapper to imlib2
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/giblib.png
</ekran_resmi>
<kurulacak_paketler>
giblib
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.2.4
</surum>
<silinecek_paketler>
giblib
</silinecek_paketler>
</uygulama>
