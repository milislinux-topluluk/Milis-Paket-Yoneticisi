<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
giblib
</isim>
<tanim>
A library that feh uses as a wrapper to imlib2
</tanim>
<ekran_resmi>
file:///tmp/giblib.png
</ekran_resmi>
<kurulacak_paketler>
giblib
</kurulacak_paketler>
<silinecek_paketler>
giblib
</silinecek_paketler>
</uygulama>
