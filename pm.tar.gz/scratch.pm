<?xml version="1.0"?>
<uygulama>
<grup>
Geliştirme
</grup>
<isim>
scratch
</isim>
<tanim>
Kendi etkileşimli hikayelerinizi, oyunlarınızı, müzik ve sanatınızı oluşturun ve paylaşın
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/scratch.png
</ekran_resmi>
<kurulacak_paketler>
scratch
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.4.0.7
</surum>
<silinecek_paketler>
scratch
</silinecek_paketler>
</uygulama>
