<?xml version="1.0"?>
<uygulama>
<grup>
geliştirme
</grup>
<isim>
scratch
</isim>
<tanim>
Kendi etkileşimli hikayelerinizi, oyunlarınızı, müzik ve sanatınızı oluşturun ve paylaşın
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/scratch.png
</ekran_resmi>
<kurulacak_paketler>
scratch
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
scratch
</silinecek_paketler>
</uygulama>
