<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
php
</isim>
<tanim>
Dinamik web sitelerinde kullanılan programlama kodunun HTML biçimlendirmesine doğrudan gömülmesini sağlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/php.png
</ekran_resmi>
<kurulacak_paketler>
php
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
php
</silinecek_paketler>
</uygulama>
