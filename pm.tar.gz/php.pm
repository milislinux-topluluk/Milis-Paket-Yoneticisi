<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
php
</isim>
<tanim>
Dinamik web sitelerinde kullanılan programlama kodunun HTML biçimlendirmesine doğrudan gömülmesini sağlar.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/php.png
</ekran_resmi>
<kurulacak_paketler>
php
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.6.31
</surum>
<silinecek_paketler>
php
</silinecek_paketler>
</uygulama>
