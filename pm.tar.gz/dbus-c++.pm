<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dbus-c++
</isim>
<tanim>
A C++ API for D-BUS
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dbus-c++.png
</ekran_resmi>
<kurulacak_paketler>
dbus-c++
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
dbus-c++
</silinecek_paketler>
</uygulama>
