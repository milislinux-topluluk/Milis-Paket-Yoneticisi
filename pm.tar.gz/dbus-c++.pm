<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dbus-c++
</isim>
<tanim>
A C++ API for D-BUS
</tanim>
<ekran_resmi>
file:///tmp/dbus-c++.png
</ekran_resmi>
<kurulacak_paketler>
dbus-c++
</kurulacak_paketler>
<silinecek_paketler>
dbus-c++
</silinecek_paketler>
</uygulama>
