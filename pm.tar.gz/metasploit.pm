<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
metasploit
</isim>
<tanim>
ileri düzey exploit kullanarak geliştirme ve test etme çatı uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/metasploit.png
</ekran_resmi>
<kurulacak_paketler>
metasploit
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
metasploit
</silinecek_paketler>
</uygulama>
