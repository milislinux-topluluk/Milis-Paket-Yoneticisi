<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
metasploit
</isim>
<tanim>
ileri düzey exploit kullanarak geliştirme ve test etme çatı uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/metasploit.png
</ekran_resmi>
<kurulacak_paketler>
metasploit
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.14.24
</surum>
<silinecek_paketler>
metasploit
</silinecek_paketler>
</uygulama>
