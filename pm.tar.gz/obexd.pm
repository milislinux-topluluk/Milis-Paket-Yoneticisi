<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
obexd
</isim>
<tanim>
Obexd paketi OBEX istemci ve sunucu işlevselliğini sağlayan D-Bus hizmetlerini içerir.
</tanim>
<ekran_resmi>
file:///tmp/obexd.png
</ekran_resmi>
<kurulacak_paketler>
obexd
</kurulacak_paketler>
<silinecek_paketler>
obexd
</silinecek_paketler>
</uygulama>
