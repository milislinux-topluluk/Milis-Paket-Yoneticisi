<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
obexd
</isim>
<tanim>
Obexd paketi OBEX istemci ve sunucu işlevselliğini sağlayan D-Bus hizmetlerini içerir.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/obexd.png
</ekran_resmi>
<kurulacak_paketler>
obexd
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.48
</surum>
<silinecek_paketler>
obexd
</silinecek_paketler>
</uygulama>
