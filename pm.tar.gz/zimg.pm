<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
zimg
</isim>
<tanim>
Scaling, colorspace conversion, and dithering library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/zimg.png
</ekran_resmi>
<kurulacak_paketler>
zimg
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
zimg
</silinecek_paketler>
</uygulama>
