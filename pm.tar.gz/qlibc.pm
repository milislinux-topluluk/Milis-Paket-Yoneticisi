<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
qlibc
</isim>
<tanim>
Hızlı ve sade C kütüphaneleri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qlibc.png
</ekran_resmi>
<kurulacak_paketler>
qlibc
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4.2
</surum>
<silinecek_paketler>
qlibc
</silinecek_paketler>
</uygulama>
