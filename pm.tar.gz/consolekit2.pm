<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
consolekit2
</isim>
<tanim>
framework for defining and tracking users, login sessions, and seats
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/consolekit2.png
</ekran_resmi>
<kurulacak_paketler>
consolekit2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.0.0
</surum>
<silinecek_paketler>
consolekit2
</silinecek_paketler>
</uygulama>
