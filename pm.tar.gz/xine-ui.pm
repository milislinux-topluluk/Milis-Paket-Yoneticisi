<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xine-ui
</isim>
<tanim>
Unix için ücretsiz video oynatıcı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xine-ui.png
</ekran_resmi>
<kurulacak_paketler>
xine-ui
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
xine-ui
</silinecek_paketler>
</uygulama>
