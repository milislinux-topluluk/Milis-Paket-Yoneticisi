<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
vte
</isim>
<tanim>
Vte is a library (libvte) implementing a terminal emulator widget for GTK+ 2
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/vte.png
</ekran_resmi>
<kurulacak_paketler>
vte
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.28.2
</surum>
<silinecek_paketler>
vte
</silinecek_paketler>
</uygulama>
