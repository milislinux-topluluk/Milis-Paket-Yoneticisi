<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gstreamer-plugins-ffmpeg
</isim>
<tanim>
GStreamer multimedya çerçevesi ffmpeg eklentileri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gstreamer-plugins-ffmpeg.png
</ekran_resmi>
<kurulacak_paketler>
gstreamer-plugins-ffmpeg
</kurulacak_paketler>
<silinecek_paketler>
gstreamer-plugins-ffmpeg
</silinecek_paketler>
</uygulama>
