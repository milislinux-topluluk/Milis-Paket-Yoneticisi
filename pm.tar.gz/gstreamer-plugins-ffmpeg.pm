<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gstreamer-plugins-ffmpeg
</isim>
<tanim>
GStreamer Multimedia Framework ffmpeg Plugins
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gstreamer-plugins-ffmpeg.png
</ekran_resmi>
<kurulacak_paketler>
gstreamer-plugins-ffmpeg
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.10.13
</surum>
<silinecek_paketler>
gstreamer-plugins-ffmpeg
</silinecek_paketler>
</uygulama>
