<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libmad
</isim>
<tanim>
Yüksek kaliteli bir MPEG ses dekoderi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libmad.png
</ekran_resmi>
<kurulacak_paketler>
libmad
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libmad
</silinecek_paketler>
</uygulama>
