<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-netbook
</isim>
<tanim>
Basit bir pencere yönetim aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-netbook.png
</ekran_resmi>
<kurulacak_paketler>
mate-netbook
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mate-netbook
</silinecek_paketler>
</uygulama>
