<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-netbook
</isim>
<tanim>
Basit bir pencere yönetim aracı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mate-netbook.png
</ekran_resmi>
<kurulacak_paketler>
mate-netbook
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mate-netbook
</silinecek_paketler>
</uygulama>
