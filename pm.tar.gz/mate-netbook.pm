<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-netbook
</isim>
<tanim>
Basit bir pencere yönetim aracı
</tanim>
<ekran_resmi>
file:///tmp/mate-netbook.png
</ekran_resmi>
<kurulacak_paketler>
mate-netbook
</kurulacak_paketler>
<silinecek_paketler>
mate-netbook
</silinecek_paketler>
</uygulama>
