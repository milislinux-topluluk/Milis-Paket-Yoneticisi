<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nikto
</isim>
<tanim>
Web sunucu zafiyet tarayıcı aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nikto.png
</ekran_resmi>
<kurulacak_paketler>
nikto
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<silinecek_paketler>
nikto
</silinecek_paketler>
</uygulama>
