<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nikto
</isim>
<tanim>
Web sunucu zafiyet tarayıcı aracı
</tanim>
<ekran_resmi>
file:///tmp/nikto.png
</ekran_resmi>
<kurulacak_paketler>
nikto
</kurulacak_paketler>
<silinecek_paketler>
nikto
</silinecek_paketler>
</uygulama>
