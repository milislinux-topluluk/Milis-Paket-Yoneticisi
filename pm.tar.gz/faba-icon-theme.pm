<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
faba-icon-theme
</isim>
<tanim>
Faba, Tango etkileri ile seksi ve modern bir simge teması. Faba için tüm varyasyonlar ve ek temalar, bu temel temayı gerektirir. Faba Icon Teması, GNU LGPL-3.0 + veya CC-BY-SA-4.0 şartları kapsamında dağıtılır
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/faba-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
faba-icon-theme
</kurulacak_paketler>
<paketci>
yasarciv
</paketci>
<surum>
4.1.2
</surum>
<silinecek_paketler>
faba-icon-theme
</silinecek_paketler>
</uygulama>
