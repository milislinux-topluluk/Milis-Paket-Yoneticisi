<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libmng
</isim>
<tanim>
Used by programs wanting to read and write of files Multiple-image Network Graphics (MNG)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libmng.png
</ekran_resmi>
<kurulacak_paketler>
libmng
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<silinecek_paketler>
libmng
</silinecek_paketler>
</uygulama>
