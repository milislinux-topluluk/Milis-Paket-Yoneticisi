<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxtst
</isim>
<tanim>
libXtst, library Xorg
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxtst.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxtst
</kurulacak_paketler>
<silinecek_paketler>
xorg-libxtst
</silinecek_paketler>
</uygulama>
