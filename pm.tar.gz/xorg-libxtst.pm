<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxtst
</isim>
<tanim>
libXtst, library Xorg
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxtst.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxtst
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.2.2
</surum>
<silinecek_paketler>
xorg-libxtst
</silinecek_paketler>
</uygulama>
