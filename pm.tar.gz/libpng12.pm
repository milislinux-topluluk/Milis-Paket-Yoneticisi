<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libpng12
</isim>
<tanim>
PNG formatlı grafik dosyalarını oluşturmak için kullanılan bir dizi rutin
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libpng12.png
</ekran_resmi>
<kurulacak_paketler>
libpng12
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.2.57
</surum>
<silinecek_paketler>
libpng12
</silinecek_paketler>
</uygulama>
