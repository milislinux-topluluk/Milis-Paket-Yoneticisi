<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libe-book
</isim>
<tanim>
e-kitap formatları için kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libe-book.png
</ekran_resmi>
<kurulacak_paketler>
libe-book
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libe-book
</silinecek_paketler>
</uygulama>
