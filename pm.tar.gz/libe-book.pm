<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libe-book
</isim>
<tanim>
e-kitap formatları için kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libe-book.png
</ekran_resmi>
<kurulacak_paketler>
libe-book
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.1.2
</surum>
<silinecek_paketler>
libe-book
</silinecek_paketler>
</uygulama>
