<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wps-office
</isim>
<tanim>
WPS Office Türkçe
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wps-office.png
</ekran_resmi>
<kurulacak_paketler>
wps-office
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
2
</surum>
<silinecek_paketler>
wps-office
</silinecek_paketler>
</uygulama>
