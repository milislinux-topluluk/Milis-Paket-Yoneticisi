<?xml version="1.0"?>
<uygulama>
<grup>
Geliştirme
</grup>
<isim>
squeak-vm
</isim>
<tanim>
Smalltalk programlama dili ve ortamının tam özellikli uygulanması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/squeak-vm.png
</ekran_resmi>
<kurulacak_paketler>
squeak-vm
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
4.10.2.2614
</surum>
<silinecek_paketler>
squeak-vm
</silinecek_paketler>
</uygulama>
