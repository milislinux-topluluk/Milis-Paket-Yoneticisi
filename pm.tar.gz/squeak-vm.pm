<?xml version="1.0"?>
<uygulama>
<grup>
geliştirme
</grup>
<isim>
squeak-vm
</isim>
<tanim>
Smalltalk programlama dili ve ortamının tam özellikli uygulanması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/squeak-vm.png
</ekran_resmi>
<kurulacak_paketler>
squeak-vm
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<silinecek_paketler>
squeak-vm
</silinecek_paketler>
</uygulama>
