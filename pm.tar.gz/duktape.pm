<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
duktape
</isim>
<tanim>
Gömülü Javascript makinası
</tanim>
<ekran_resmi>
file:///tmp/duktape.png
</ekran_resmi>
<kurulacak_paketler>
duktape
</kurulacak_paketler>
<silinecek_paketler>
duktape
</silinecek_paketler>
</uygulama>
