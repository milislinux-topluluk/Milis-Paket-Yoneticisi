<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
tcl
</isim>
<tanim>
The Tcl scripting language
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/tcl.png
</ekran_resmi>
<kurulacak_paketler>
tcl
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
8.6.4
</surum>
<silinecek_paketler>
tcl
</silinecek_paketler>
</uygulama>
