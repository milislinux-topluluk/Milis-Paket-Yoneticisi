<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
tcl
</isim>
<tanim>
Tcl betik dili
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/tcl.png
</ekran_resmi>
<kurulacak_paketler>
tcl
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
8.6.4
</surum>
<silinecek_paketler>
tcl
</silinecek_paketler>
</uygulama>
