<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gstreamer1-plugins-good
</isim>
<tanim>
GStreamer Multimedia Framework good Plugins
</tanim>
<ekran_resmi>
file:///tmp/gstreamer1-plugins-good.png
</ekran_resmi>
<kurulacak_paketler>
gstreamer1-plugins-good
</kurulacak_paketler>
<silinecek_paketler>
gstreamer1-plugins-good
</silinecek_paketler>
</uygulama>
