<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-screensaver
</isim>
<tanim>
MATE için ekran koruyucu ve kilitleyici
</tanim>
<ekran_resmi>
file:///tmp/mate-screensaver.png
</ekran_resmi>
<kurulacak_paketler>
mate-screensaver
</kurulacak_paketler>
<silinecek_paketler>
mate-screensaver
</silinecek_paketler>
</uygulama>
