<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-screensaver
</isim>
<tanim>
MATE için ekran koruyucu ve kilitleyici
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-screensaver.png
</ekran_resmi>
<kurulacak_paketler>
mate-screensaver
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.1
</surum>
<silinecek_paketler>
mate-screensaver
</silinecek_paketler>
</uygulama>
