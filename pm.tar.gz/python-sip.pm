<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-sip
</isim>
<tanim>
C ve C ++ kitaplıkları için Python bağlamaları oluşturmayı kolaylaştıran bir araç
</tanim>
<ekran_resmi>
file:///tmp/python-sip.png
</ekran_resmi>
<kurulacak_paketler>
python-sip
</kurulacak_paketler>
<silinecek_paketler>
python-sip
</silinecek_paketler>
</uygulama>
