<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xfce4-diskperf-plugin
</isim>
<tanim>
Bu eklenti anlık disk / bölüm performansını görüntüler (saniyede bayt aktarılır).
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-diskperf-plugin.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-diskperf-plugin
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.5.5
</surum>
<silinecek_paketler>
xfce4-diskperf-plugin
</silinecek_paketler>
</uygulama>
