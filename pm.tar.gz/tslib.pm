<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
tslib
</isim>
<tanim>
Dokunmatik Ekran Erişim Kitaplığı.
</tanim>
<ekran_resmi>
file:///tmp/tslib.png
</ekran_resmi>
<kurulacak_paketler>
tslib
</kurulacak_paketler>
<silinecek_paketler>
tslib
</silinecek_paketler>
</uygulama>
