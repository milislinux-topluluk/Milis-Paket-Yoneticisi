<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
tslib
</isim>
<tanim>
Dokunmatik Ekran Erişim Kitaplığı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/tslib.png
</ekran_resmi>
<kurulacak_paketler>
tslib
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
tslib
</silinecek_paketler>
</uygulama>
