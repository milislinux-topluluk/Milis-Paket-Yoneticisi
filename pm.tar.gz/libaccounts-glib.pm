<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libaccounts-glib
</isim>
<tanim>
Glib-based client library for accessing the online accounts database
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libaccounts-glib.png
</ekran_resmi>
<kurulacak_paketler>
libaccounts-glib
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.21
</surum>
<silinecek_paketler>
libaccounts-glib
</silinecek_paketler>
</uygulama>
