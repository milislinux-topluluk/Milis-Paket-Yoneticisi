<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libaccounts-glib
</isim>
<tanim>
Glib-based client library for accessing the online accounts database
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libaccounts-glib.png
</ekran_resmi>
<kurulacak_paketler>
libaccounts-glib
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
libaccounts-glib
</silinecek_paketler>
</uygulama>
