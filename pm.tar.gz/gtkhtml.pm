<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtkhtml
</isim>
<tanim>
GtkHTML paketi hafif bir HTML oluşturma / yazdırma / düzenleme motoru içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtkhtml.png
</ekran_resmi>
<kurulacak_paketler>
gtkhtml
</kurulacak_paketler>
<silinecek_paketler>
gtkhtml
</silinecek_paketler>
</uygulama>
