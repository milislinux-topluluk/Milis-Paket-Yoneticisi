<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
polyml
</isim>
<tanim>
standart ML derleyicisinin güncel gerçeklemesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/polyml.png
</ekran_resmi>
<kurulacak_paketler>
polyml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.7
</surum>
<silinecek_paketler>
polyml
</silinecek_paketler>
</uygulama>
