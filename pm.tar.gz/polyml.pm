<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
polyml
</isim>
<tanim>
standart ML derleyicisinin güncel gerçeklemesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/polyml.png
</ekran_resmi>
<kurulacak_paketler>
polyml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
polyml
</silinecek_paketler>
</uygulama>
