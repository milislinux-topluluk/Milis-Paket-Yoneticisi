<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-places-plugin
</isim>
<tanim>
Xfce paneli için Yerler Menüsü eklentisi
</tanim>
<ekran_resmi>
file:///tmp/xfce4-places-plugin.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-places-plugin
</kurulacak_paketler>
<silinecek_paketler>
xfce4-places-plugin
</silinecek_paketler>
</uygulama>
