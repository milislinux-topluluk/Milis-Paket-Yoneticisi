<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sg3-utils
</isim>
<tanim>
Generic SCSI utilities
</tanim>
<ekran_resmi>
file:///tmp/sg3-utils.png
</ekran_resmi>
<kurulacak_paketler>
sg3-utils
</kurulacak_paketler>
<silinecek_paketler>
sg3-utils
</silinecek_paketler>
</uygulama>
