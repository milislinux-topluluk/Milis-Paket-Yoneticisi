<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sg3-utils
</isim>
<tanim>
Generic SCSI utilities
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sg3-utils.png
</ekran_resmi>
<kurulacak_paketler>
sg3-utils
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
sg3-utils
</silinecek_paketler>
</uygulama>
