<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xorg-xinit
</isim>
<tanim>
The xinit package contains a usable script to start the xserver.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xorg-xinit.png
</ekran_resmi>
<kurulacak_paketler>
xorg-xinit
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
1.3.4
</surum>
<silinecek_paketler>
xorg-xinit
</silinecek_paketler>
</uygulama>
