<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-cairo
</isim>
<tanim>
connector Python2 for the library cairo
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-cairo.png
</ekran_resmi>
<kurulacak_paketler>
python-cairo
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.10.0
</surum>
<silinecek_paketler>
python-cairo
</silinecek_paketler>
</uygulama>
