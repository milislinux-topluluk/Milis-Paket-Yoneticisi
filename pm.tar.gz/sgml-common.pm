<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sgml-common
</isim>
<tanim>
Tools for maintaining centralized SGML catalogs.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sgml-common.png
</ekran_resmi>
<kurulacak_paketler>
sgml-common
</kurulacak_paketler>
<silinecek_paketler>
sgml-common
</silinecek_paketler>
</uygulama>
