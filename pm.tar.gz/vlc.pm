<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
vlc
</isim>
<tanim>
VLC, özgür ve açık kaynak kodlu, platformlar arası, bir ortam oynatıcı ve çatıdır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/vlc.png
</ekran_resmi>
<kurulacak_paketler>
vlc
</kurulacak_paketler>
<silinecek_paketler>
vlc
</silinecek_paketler>
</uygulama>
