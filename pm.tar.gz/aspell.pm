<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
aspell
</isim>
<tanim>
An interactive spell checking program and the Aspell libraries.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/aspell.png
</ekran_resmi>
<kurulacak_paketler>
aspell
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
0.60.6.1
</surum>
<silinecek_paketler>
aspell
</silinecek_paketler>
</uygulama>
