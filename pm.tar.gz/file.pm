<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
file
</isim>
<tanim>
Utility for determining the type of a given file or files.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/file.png
</ekran_resmi>
<kurulacak_paketler>
file
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
5.25
</surum>
<silinecek_paketler>
file
</silinecek_paketler>
</uygulama>
