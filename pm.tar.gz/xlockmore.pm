<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xlockmore
</isim>
<tanim>
X Window System Lock Screen
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xlockmore.png
</ekran_resmi>
<kurulacak_paketler>
xlockmore
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.49
</surum>
<silinecek_paketler>
xlockmore
</silinecek_paketler>
</uygulama>
