<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sqlcipher
</isim>
<tanim>
sqlite veritabanları için 256bit şifreleme eklentisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sqlcipher.png
</ekran_resmi>
<kurulacak_paketler>
sqlcipher
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.4.1
</surum>
<silinecek_paketler>
sqlcipher
</silinecek_paketler>
</uygulama>
