<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sqlcipher
</isim>
<tanim>
sqlite veritabanları için 256bit şifreleme eklentisi
</tanim>
<ekran_resmi>
file:///tmp/sqlcipher.png
</ekran_resmi>
<kurulacak_paketler>
sqlcipher
</kurulacak_paketler>
<silinecek_paketler>
sqlcipher
</silinecek_paketler>
</uygulama>
