<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-tweak-tool
</isim>
<tanim>
Gelişmiş GNOME3 seçeneklerini özelleştiren bir araç.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-tweak-tool.png
</ekran_resmi>
<kurulacak_paketler>
gnome-tweak-tool
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.0
</surum>
<silinecek_paketler>
gnome-tweak-tool
</silinecek_paketler>
</uygulama>
