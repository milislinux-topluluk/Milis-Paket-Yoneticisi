<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-tweak-tool
</isim>
<tanim>
Gelişmiş GNOME3 seçeneklerini özelleştiren bir araç.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-tweak-tool.png
</ekran_resmi>
<kurulacak_paketler>
gnome-tweak-tool
</kurulacak_paketler>
<silinecek_paketler>
gnome-tweak-tool
</silinecek_paketler>
</uygulama>
