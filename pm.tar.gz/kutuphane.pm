<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kutuphane
</isim>
<tanim>
Javada yazılmış bir kütüphane uygulaması - Ebubekir Bastama
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kutuphane.png
</ekran_resmi>
<kurulacak_paketler>
kutuphane
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.0
</surum>
<silinecek_paketler>
kutuphane
</silinecek_paketler>
</uygulama>
