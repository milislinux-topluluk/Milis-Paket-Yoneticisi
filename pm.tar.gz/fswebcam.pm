<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fswebcam
</isim>
<tanim>
hafif çapta programcılar için webcam uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fswebcam.png
</ekran_resmi>
<kurulacak_paketler>
fswebcam
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
fswebcam
</silinecek_paketler>
</uygulama>
