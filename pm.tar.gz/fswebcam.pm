<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
fswebcam
</isim>
<tanim>
hafif çapta programcılar için webcam uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/fswebcam.png
</ekran_resmi>
<kurulacak_paketler>
fswebcam
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
20140113
</surum>
<silinecek_paketler>
fswebcam
</silinecek_paketler>
</uygulama>
