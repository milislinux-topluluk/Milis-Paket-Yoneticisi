<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kio-extras
</isim>
<tanim>
KIO'nun işlevselliğini artırmak için ek bileşenler
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kio-extras.png
</ekran_resmi>
<kurulacak_paketler>
kio-extras
</kurulacak_paketler>
<paketci>
cihanAlkan
</paketci>
<surum>
17.12.0
</surum>
<silinecek_paketler>
kio-extras
</silinecek_paketler>
</uygulama>
