<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
cifs-utils
</isim>
<tanim>
CIFS dosya sistemi kullanıcı alanı araçları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cifs-utils.png
</ekran_resmi>
<kurulacak_paketler>
cifs-utils
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
6.5
</surum>
<silinecek_paketler>
cifs-utils
</silinecek_paketler>
</uygulama>
