<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libcmis
</isim>
<tanim>
CMIS protokolü için bir C / C ++ istemci kitaplığı
</tanim>
<ekran_resmi>
file:///tmp/libcmis.png
</ekran_resmi>
<kurulacak_paketler>
libcmis
</kurulacak_paketler>
<silinecek_paketler>
libcmis
</silinecek_paketler>
</uygulama>
