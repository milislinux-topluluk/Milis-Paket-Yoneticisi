<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libcmis
</isim>
<tanim>
CMIS protokolü için bir C / C ++ istemci kitaplığı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libcmis.png
</ekran_resmi>
<kurulacak_paketler>
libcmis
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.5.1
</surum>
<silinecek_paketler>
libcmis
</silinecek_paketler>
</uygulama>
