<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
icecat
</isim>
<tanim>
Firefox Web Tarayıcısının GNU çatallaması
</tanim>
<ekran_resmi>
file:///tmp/icecat.png
</ekran_resmi>
<kurulacak_paketler>
icecat
</kurulacak_paketler>
<silinecek_paketler>
icecat
</silinecek_paketler>
</uygulama>
