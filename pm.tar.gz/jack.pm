<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jack
</isim>
<tanim>
A low-latency audio server
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jack.png
</ekran_resmi>
<kurulacak_paketler>
jack
</kurulacak_paketler>
<silinecek_paketler>
jack
</silinecek_paketler>
</uygulama>
