<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
csfml
</isim>
<tanim>
sfml C kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/csfml.png
</ekran_resmi>
<kurulacak_paketler>
csfml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4
</surum>
<silinecek_paketler>
csfml
</silinecek_paketler>
</uygulama>
