<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wfuzz
</isim>
<tanim>
Web uygulamalarındaki link verilmeyen kaynakları deneme/yanılma (fuzzer) yolu ile bulan araç.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wfuzz.png
</ekran_resmi>
<kurulacak_paketler>
wfuzz
</kurulacak_paketler>
<paketci>
ayakar
</paketci>
<surum>
2.1.5
</surum>
<silinecek_paketler>
wfuzz
</silinecek_paketler>
</uygulama>
