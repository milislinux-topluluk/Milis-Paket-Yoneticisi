<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
phonon-qt5
</isim>
<tanim>
API multimedia of KDE. the replaces the old aRts, which is more supported by KDE.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/phonon-qt5.png
</ekran_resmi>
<kurulacak_paketler>
phonon-qt5
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
4.9.0
</surum>
<silinecek_paketler>
phonon-qt5
</silinecek_paketler>
</uygulama>
