<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-icon-theme
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///tmp/gnome-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
gnome-icon-theme
</kurulacak_paketler>
<silinecek_paketler>
gnome-icon-theme
</silinecek_paketler>
</uygulama>
