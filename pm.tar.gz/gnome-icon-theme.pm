<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-icon-theme
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
gnome-icon-theme
</kurulacak_paketler>
<paketci>
thierryn1 at hispeed dot ch
</paketci>
<surum>
3.12.0
</surum>
<silinecek_paketler>
gnome-icon-theme
</silinecek_paketler>
</uygulama>
