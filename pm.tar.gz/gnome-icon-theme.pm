<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-icon-theme
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
gnome-icon-theme
</kurulacak_paketler>
<paketci>
thierryn1 at hispeed dot ch
</paketci>
<surum>
3.12.0
</surum>
<silinecek_paketler>
gnome-icon-theme
</silinecek_paketler>
</uygulama>
