<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kcmutils
</isim>
<tanim>
KCModules ile etkileşim kurmak için kullanılan yardımcı programlar
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kcmutils.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kcmutils
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kcmutils
</silinecek_paketler>
</uygulama>
