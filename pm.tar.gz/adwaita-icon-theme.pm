<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
adwaita-icon-theme
</isim>
<tanim>
Adwaita ikon teması.
</tanim>
<ekran_resmi>
file:///tmp/adwaita-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
adwaita-icon-theme
</kurulacak_paketler>
<silinecek_paketler>
adwaita-icon-theme
</silinecek_paketler>
</uygulama>
