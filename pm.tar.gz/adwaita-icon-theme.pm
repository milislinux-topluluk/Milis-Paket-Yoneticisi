<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
adwaita-icon-theme
</isim>
<tanim>
Adwaita ikon teması.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/adwaita-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
adwaita-icon-theme
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.24.0
</surum>
<silinecek_paketler>
adwaita-icon-theme
</silinecek_paketler>
</uygulama>
