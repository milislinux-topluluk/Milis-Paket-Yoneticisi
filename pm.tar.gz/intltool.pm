<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
intltool
</isim>
<tanim>
The internationalization tool collection
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/intltool.png
</ekran_resmi>
<kurulacak_paketler>
intltool
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
0.51.0
</surum>
<silinecek_paketler>
intltool
</silinecek_paketler>
</uygulama>
