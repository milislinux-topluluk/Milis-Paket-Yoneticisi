<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
intltool
</isim>
<tanim>
The internationalization tool collection
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/intltool.png
</ekran_resmi>
<kurulacak_paketler>
intltool
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<silinecek_paketler>
intltool
</silinecek_paketler>
</uygulama>
