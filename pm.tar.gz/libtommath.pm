<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libtommath
</isim>
<tanim>
Tamsayılı temelli sayısal teorik uygulamalar için yüksek seviyede optimize edilmiş ve taşınabilir rutinler
</tanim>
<ekran_resmi>
file:///tmp/libtommath.png
</ekran_resmi>
<kurulacak_paketler>
libtommath
</kurulacak_paketler>
<silinecek_paketler>
libtommath
</silinecek_paketler>
</uygulama>
