<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libtommath
</isim>
<tanim>
Tamsayılı temelli sayısal teorik uygulamalar için yüksek seviyede optimize edilmiş ve taşınabilir rutinler
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libtommath.png
</ekran_resmi>
<kurulacak_paketler>
libtommath
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.0.1
</surum>
<silinecek_paketler>
libtommath
</silinecek_paketler>
</uygulama>
