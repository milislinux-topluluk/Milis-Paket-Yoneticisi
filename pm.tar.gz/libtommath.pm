<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libtommath
</isim>
<tanim>
Tamsayılı temelli sayısal teorik uygulamalar için yüksek seviyede optimize edilmiş ve taşınabilir rutinler
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libtommath.png
</ekran_resmi>
<kurulacak_paketler>
libtommath
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<silinecek_paketler>
libtommath
</silinecek_paketler>
</uygulama>
