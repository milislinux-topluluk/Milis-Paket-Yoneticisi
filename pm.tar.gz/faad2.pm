<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
faad2
</isim>
<tanim>
ISO AAC audio decoder
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/faad2.png
</ekran_resmi>
<kurulacak_paketler>
faad2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.7
</surum>
<silinecek_paketler>
faad2
</silinecek_paketler>
</uygulama>
