<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
faad2
</isim>
<tanim>
ISO AAC audio decoder
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/faad2.png
</ekran_resmi>
<kurulacak_paketler>
faad2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
faad2
</silinecek_paketler>
</uygulama>
