<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
faad2
</isim>
<tanim>
ISO AAC audio decoder
</tanim>
<ekran_resmi>
file:///tmp/faad2.png
</ekran_resmi>
<kurulacak_paketler>
faad2
</kurulacak_paketler>
<silinecek_paketler>
faad2
</silinecek_paketler>
</uygulama>
