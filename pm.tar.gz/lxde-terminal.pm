<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxde-terminal
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxde-terminal.png
</ekran_resmi>
<kurulacak_paketler>
lxde-terminal
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
0.2.0
</surum>
<silinecek_paketler>
lxde-terminal
</silinecek_paketler>
</uygulama>
