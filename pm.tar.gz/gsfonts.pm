<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gsfonts
</isim>
<tanim>
Standard Ghostscript Type1 fonts from URW
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gsfonts.png
</ekran_resmi>
<kurulacak_paketler>
gsfonts
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
gsfonts
</silinecek_paketler>
</uygulama>
