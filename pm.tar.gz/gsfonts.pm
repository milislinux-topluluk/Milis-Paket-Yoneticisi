<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gsfonts
</isim>
<tanim>
Standard Ghostscript Type1 fonts from URW
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gsfonts.png
</ekran_resmi>
<kurulacak_paketler>
gsfonts
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
8.11
</surum>
<silinecek_paketler>
gsfonts
</silinecek_paketler>
</uygulama>
