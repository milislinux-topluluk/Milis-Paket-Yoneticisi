<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-photos
</isim>
<tanim>
GNOME'da fotoğraflarınıza erişin, bunları organize edin ve paylaşın.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-photos.png
</ekran_resmi>
<kurulacak_paketler>
gnome-photos
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.2
</surum>
<silinecek_paketler>
gnome-photos
</silinecek_paketler>
</uygulama>
