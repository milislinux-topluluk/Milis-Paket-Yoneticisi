<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-photos
</isim>
<tanim>
GNOME'da fotoğraflarınıza erişin, bunları organize edin ve paylaşın.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-photos.png
</ekran_resmi>
<kurulacak_paketler>
gnome-photos
</kurulacak_paketler>
<silinecek_paketler>
gnome-photos
</silinecek_paketler>
</uygulama>
