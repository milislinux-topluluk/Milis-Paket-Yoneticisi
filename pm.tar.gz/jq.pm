<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
jq
</isim>
<tanim>
komut satirinda json parcalayici
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/jq.png
</ekran_resmi>
<kurulacak_paketler>
jq
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.5
</surum>
<silinecek_paketler>
jq
</silinecek_paketler>
</uygulama>
