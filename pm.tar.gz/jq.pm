<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jq
</isim>
<tanim>
komut satirinda json parcalayici
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jq.png
</ekran_resmi>
<kurulacak_paketler>
jq
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
jq
</silinecek_paketler>
</uygulama>
