<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fastd
</isim>
<tanim>
hızlı ve güvenli tünelleme uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fastd.png
</ekran_resmi>
<kurulacak_paketler>
fastd
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
fastd
</silinecek_paketler>
</uygulama>
