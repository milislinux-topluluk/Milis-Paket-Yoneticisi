<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mutter
</isim>
<tanim>
GNOME için bir pencere yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mutter.png
</ekran_resmi>
<kurulacak_paketler>
mutter
</kurulacak_paketler>
<silinecek_paketler>
mutter
</silinecek_paketler>
</uygulama>
