<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mutter
</isim>
<tanim>
GNOME için bir pencere yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mutter.png
</ekran_resmi>
<kurulacak_paketler>
mutter
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.2
</surum>
<silinecek_paketler>
mutter
</silinecek_paketler>
</uygulama>
