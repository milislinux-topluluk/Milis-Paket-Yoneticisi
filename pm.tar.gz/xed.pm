<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
xed
</isim>
<tanim>
Küçük ve hafif metin düzenleyici
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xed.png
</ekran_resmi>
<kurulacak_paketler>
xed
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.6.3
</surum>
<silinecek_paketler>
xed
</silinecek_paketler>
</uygulama>
