<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
qupzilla
</isim>
<tanim>
Çapraz platform QtWebKit tarayıcı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qupzilla.png
</ekran_resmi>
<kurulacak_paketler>
qupzilla
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.1.2
</surum>
<silinecek_paketler>
qupzilla
</silinecek_paketler>
</uygulama>
