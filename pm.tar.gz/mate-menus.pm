<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-menus
</isim>
<tanim>
Freedesktop.org'dan Masaüstü Menüsü Teknik Özelliklerini uygulayan bir kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-menus.png
</ekran_resmi>
<kurulacak_paketler>
mate-menus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
mate-menus
</silinecek_paketler>
</uygulama>
