<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-menus
</isim>
<tanim>
Freedesktop.org'dan Masaüstü Menüsü Teknik Özelliklerini uygulayan bir kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-menus.png
</ekran_resmi>
<kurulacak_paketler>
mate-menus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mate-menus
</silinecek_paketler>
</uygulama>
