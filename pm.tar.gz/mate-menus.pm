<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-menus
</isim>
<tanim>
Freedesktop.org'dan Masaüstü Menüsü Teknik Özelliklerini uygulayan bir kütüphane
</tanim>
<ekran_resmi>
file:///tmp/mate-menus.png
</ekran_resmi>
<kurulacak_paketler>
mate-menus
</kurulacak_paketler>
<silinecek_paketler>
mate-menus
</silinecek_paketler>
</uygulama>
