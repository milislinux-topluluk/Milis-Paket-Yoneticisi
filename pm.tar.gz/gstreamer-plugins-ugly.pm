<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gstreamer-plugins-ugly
</isim>
<tanim>
GStreamer Çirkin Eklentileri, kaliteli ve doğru işlevsellikleri olan bir takım eklentilerdir ancak bunları dağıtmak sorun yaratabilir.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gstreamer-plugins-ugly.png
</ekran_resmi>
<kurulacak_paketler>
gstreamer-plugins-ugly
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.10.19
</surum>
<silinecek_paketler>
gstreamer-plugins-ugly
</silinecek_paketler>
</uygulama>
