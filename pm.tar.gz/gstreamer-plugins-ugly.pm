<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gstreamer-plugins-ugly
</isim>
<tanim>
GStreamer Çirkin Eklentileri, kaliteli ve doğru işlevsellikleri olan bir takım eklentilerdir ancak bunları dağıtmak sorun yaratabilir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gstreamer-plugins-ugly.png
</ekran_resmi>
<kurulacak_paketler>
gstreamer-plugins-ugly
</kurulacak_paketler>
<silinecek_paketler>
gstreamer-plugins-ugly
</silinecek_paketler>
</uygulama>
