<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
john
</isim>
<tanim>
John the Ripper hızlı bir şifre kırma yazılımıdır
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/john.png
</ekran_resmi>
<kurulacak_paketler>
john
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.8.0-jumbo-1
</surum>
<silinecek_paketler>
john
</silinecek_paketler>
</uygulama>
