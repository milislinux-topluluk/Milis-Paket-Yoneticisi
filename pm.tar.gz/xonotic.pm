<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xonotic
</isim>
<tanim>
Xonotic, net hareket ve geniş bir silah yelpazesine sahip, bağımlılık yaratan, arena tarzı bir birinci şahıs nişancılık oyunudur.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xonotic.png
</ekran_resmi>
<kurulacak_paketler>
xonotic
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.8.2
</surum>
<silinecek_paketler>
xonotic
</silinecek_paketler>
</uygulama>
