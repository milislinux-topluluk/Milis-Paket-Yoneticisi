<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-polkit-kde-agent
</isim>
<tanim>
Program, KDE için bir polkit kimlik doğrulama arayüzü sağlar.
</tanim>
<ekran_resmi>
file:///tmp/plasma-polkit-kde-agent.png
</ekran_resmi>
<kurulacak_paketler>
plasma-polkit-kde-agent
</kurulacak_paketler>
<silinecek_paketler>
plasma-polkit-kde-agent
</silinecek_paketler>
</uygulama>
