<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-polkit-kde-agent
</isim>
<tanim>
emon providing a polkit authentication UI for KDE
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-polkit-kde-agent.png
</ekran_resmi>
<kurulacak_paketler>
plasma-polkit-kde-agent
</kurulacak_paketler>
<paketci>
alihan-ozturk@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-polkit-kde-agent
</silinecek_paketler>
</uygulama>
