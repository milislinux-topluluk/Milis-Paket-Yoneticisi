<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-knotifications
</isim>
<tanim>
Sistem bildirimleri için soyutlama
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-knotifications.png
</ekran_resmi>
<kurulacak_paketler>
kf5-knotifications
</kurulacak_paketler>
<silinecek_paketler>
kf5-knotifications
</silinecek_paketler>
</uygulama>
