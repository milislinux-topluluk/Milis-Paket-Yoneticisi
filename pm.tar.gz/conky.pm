<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
conky
</isim>
<tanim>
X Pencere Sistemi icin hafif bir sistem monitoru
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/conky.png
</ekran_resmi>
<kurulacak_paketler>
conky
</kurulacak_paketler>
<silinecek_paketler>
conky
</silinecek_paketler>
</uygulama>
