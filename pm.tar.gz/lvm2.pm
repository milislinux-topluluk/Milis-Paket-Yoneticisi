<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lvm2
</isim>
<tanim>
Allows spanning of file systems across multiple physical disks and partitions.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lvm2.png
</ekran_resmi>
<kurulacak_paketler>
lvm2
</kurulacak_paketler>
<silinecek_paketler>
lvm2
</silinecek_paketler>
</uygulama>
