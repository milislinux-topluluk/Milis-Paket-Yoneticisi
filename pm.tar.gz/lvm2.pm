<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lvm2
</isim>
<tanim>
Allows spanning of file systems across multiple physical disks and partitions.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lvm2.png
</ekran_resmi>
<kurulacak_paketler>
lvm2
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.02.141
</surum>
<silinecek_paketler>
lvm2
</silinecek_paketler>
</uygulama>
