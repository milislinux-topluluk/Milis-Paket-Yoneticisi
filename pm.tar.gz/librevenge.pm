<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
librevenge
</isim>
<tanim>
Librevenge, belge içe aktarma filtreleri yazmak için kullanılan bir temel kitaplıktır.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/librevenge.png
</ekran_resmi>
<kurulacak_paketler>
librevenge
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.0.4
</surum>
<silinecek_paketler>
librevenge
</silinecek_paketler>
</uygulama>
