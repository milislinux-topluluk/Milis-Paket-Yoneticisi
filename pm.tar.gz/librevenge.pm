<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
librevenge
</isim>
<tanim>
Librevenge, belge içe aktarma filtreleri yazmak için kullanılan bir temel kitaplıktır.
</tanim>
<ekran_resmi>
file:///tmp/librevenge.png
</ekran_resmi>
<kurulacak_paketler>
librevenge
</kurulacak_paketler>
<silinecek_paketler>
librevenge
</silinecek_paketler>
</uygulama>
