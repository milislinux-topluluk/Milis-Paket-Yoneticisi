<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
firefox
</isim>
<tanim>
Mozilla.org'dan Bağımsız Web Tarayıcısı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/firefox.png
</ekran_resmi>
<kurulacak_paketler>
firefox
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
55.0.3
</surum>
<silinecek_paketler>
firefox
</silinecek_paketler>
</uygulama>
