<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python-chardet
</isim>
<tanim>
Karakter kodlaması otomatik algılama için Python modülü.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python-chardet.png
</ekran_resmi>
<kurulacak_paketler>
python-chardet
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.3.0
</surum>
<silinecek_paketler>
python-chardet
</silinecek_paketler>
</uygulama>
