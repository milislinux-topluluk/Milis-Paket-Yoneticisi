<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-chardet
</isim>
<tanim>
Karakter kodlaması otomatik algılama için Python modülü.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-chardet.png
</ekran_resmi>
<kurulacak_paketler>
python-chardet
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
python-chardet
</silinecek_paketler>
</uygulama>
