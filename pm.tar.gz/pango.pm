<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
pango
</isim>
<tanim>
A library for layout and rendering of text
</tanim>
<ekran_resmi>
file:///tmp/pango.png
</ekran_resmi>
<kurulacak_paketler>
pango
</kurulacak_paketler>
<silinecek_paketler>
pango
</silinecek_paketler>
</uygulama>
