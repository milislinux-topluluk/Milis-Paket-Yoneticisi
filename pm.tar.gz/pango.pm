<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pango
</isim>
<tanim>
A library for layout and rendering of text
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pango.png
</ekran_resmi>
<kurulacak_paketler>
pango
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.38.1
</surum>
<silinecek_paketler>
pango
</silinecek_paketler>
</uygulama>
