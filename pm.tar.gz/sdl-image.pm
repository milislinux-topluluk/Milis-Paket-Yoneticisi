<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sdl-image
</isim>
<tanim>
SDL_image is a simple library to load images of various formats as SDL surfaces.
</tanim>
<ekran_resmi>
file:///tmp/sdl-image.png
</ekran_resmi>
<kurulacak_paketler>
sdl-image
</kurulacak_paketler>
<silinecek_paketler>
sdl-image
</silinecek_paketler>
</uygulama>
