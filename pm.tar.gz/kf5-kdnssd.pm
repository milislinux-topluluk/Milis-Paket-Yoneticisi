<?xml version="1.0"?>
<uygulama>
<grup>
Kde
</grup>
<isim>
kf5-kdnssd
</isim>
<tanim>
Sistem DNSSD özelliklerinin soyutlanması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-kdnssd.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdnssd
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kdnssd
</silinecek_paketler>
</uygulama>
