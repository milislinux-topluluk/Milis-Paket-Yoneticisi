<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdnssd
</isim>
<tanim>
Sistem DNSSD özelliklerinin soyutlanması
</tanim>
<ekran_resmi>
file:///tmp/kf5-kdnssd.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdnssd
</kurulacak_paketler>
<silinecek_paketler>
kf5-kdnssd
</silinecek_paketler>
</uygulama>
