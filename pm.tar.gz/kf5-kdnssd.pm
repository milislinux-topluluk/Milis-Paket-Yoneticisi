<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdnssd
</isim>
<tanim>
Sistem DNSSD özelliklerinin soyutlanması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kdnssd.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdnssd
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
kf5-kdnssd
</silinecek_paketler>
</uygulama>
