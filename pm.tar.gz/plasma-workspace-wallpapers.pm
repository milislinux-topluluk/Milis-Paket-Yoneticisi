<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-workspace-wallpapers
</isim>
<tanim>
Plazma Çalışma Alanı için ilave duvar kağıtları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-workspace-wallpapers.png
</ekran_resmi>
<kurulacak_paketler>
plasma-workspace-wallpapers
</kurulacak_paketler>
<paketci>
alihan-oztruk@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-workspace-wallpapers
</silinecek_paketler>
</uygulama>
