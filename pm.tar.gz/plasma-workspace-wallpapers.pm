<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-workspace-wallpapers
</isim>
<tanim>
Additional wallpapers for the Plasma Workspace
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-workspace-wallpapers.png
</ekran_resmi>
<kurulacak_paketler>
plasma-workspace-wallpapers
</kurulacak_paketler>
<paketci>
alihan-oztruk@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-workspace-wallpapers
</silinecek_paketler>
</uygulama>
