<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libgcrypt
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libgcrypt.png
</ekran_resmi>
<kurulacak_paketler>
libgcrypt
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.7.6
</surum>
<silinecek_paketler>
libgcrypt
</silinecek_paketler>
</uygulama>
