<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-glib
</isim>
<tanim>
Perl connector for glib
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-glib.png
</ekran_resmi>
<kurulacak_paketler>
perl-glib
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
perl-glib
</silinecek_paketler>
</uygulama>
