<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ntfs-3g
</isim>
<tanim>
The Ntfs-3g package contains a stable, read-write open source driver for NTFS partitions.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ntfs-3g.png
</ekran_resmi>
<kurulacak_paketler>
ntfs-3g
</kurulacak_paketler>
<silinecek_paketler>
ntfs-3g
</silinecek_paketler>
</uygulama>
