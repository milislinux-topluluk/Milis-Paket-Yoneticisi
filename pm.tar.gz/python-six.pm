<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-six
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-six.png
</ekran_resmi>
<kurulacak_paketler>
python-six
</kurulacak_paketler>
<silinecek_paketler>
python-six
</silinecek_paketler>
</uygulama>
