<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python-six
</isim>
<tanim>
Python 2 ve 3 uyumluluk programları.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python-six.png
</ekran_resmi>
<kurulacak_paketler>
python-six
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.7.3
</surum>
<silinecek_paketler>
python-six
</silinecek_paketler>
</uygulama>
