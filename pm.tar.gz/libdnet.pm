<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libdnet
</isim>
<tanim>
ARP arkaplan çalıştırma ve araçlar
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libdnet.png
</ekran_resmi>
<kurulacak_paketler>
libdnet
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.11
</surum>
<silinecek_paketler>
libdnet
</silinecek_paketler>
</uygulama>
