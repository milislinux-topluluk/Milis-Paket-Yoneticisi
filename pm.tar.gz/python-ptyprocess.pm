<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-ptyprocess
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-ptyprocess.png
</ekran_resmi>
<kurulacak_paketler>
python-ptyprocess
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.5.1
</surum>
<silinecek_paketler>
python-ptyprocess
</silinecek_paketler>
</uygulama>
