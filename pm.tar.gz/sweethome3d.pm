<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
sweethome3d
</isim>
<tanim>
Evinizin planını 3D ortamda çizmek için bir iç mekan tasarımı uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sweethome3d.png
</ekran_resmi>
<kurulacak_paketler>
sweethome3d
</kurulacak_paketler>
<silinecek_paketler>
sweethome3d
</silinecek_paketler>
</uygulama>
