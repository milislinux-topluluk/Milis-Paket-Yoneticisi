<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dolphin
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dolphin.png
</ekran_resmi>
<kurulacak_paketler>
dolphin
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
dolphin
</silinecek_paketler>
</uygulama>
