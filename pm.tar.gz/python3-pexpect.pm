<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-pexpect
</isim>
<tanim>
Diğer programların otomasyon ve kontrolu için kullanılan python3 kütüphanesi.
</tanim>
<ekran_resmi>
file:///tmp/python3-pexpect.png
</ekran_resmi>
<kurulacak_paketler>
python3-pexpect
</kurulacak_paketler>
<silinecek_paketler>
python3-pexpect
</silinecek_paketler>
</uygulama>
