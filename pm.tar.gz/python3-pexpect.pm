<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-pexpect
</isim>
<tanim>
Diğer programların otomasyon ve kontrolu için kullanılan python3 kütüphanesi.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python3-pexpect.png
</ekran_resmi>
<kurulacak_paketler>
python3-pexpect
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.2.1
</surum>
<silinecek_paketler>
python3-pexpect
</silinecek_paketler>
</uygulama>
