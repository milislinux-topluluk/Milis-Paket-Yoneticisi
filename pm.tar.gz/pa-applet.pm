<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pa-applet
</isim>
<tanim>
PulseAudio kontrol uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/pa-applet.png
</ekran_resmi>
<kurulacak_paketler>
pa-applet
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
2017.09
</surum>
<silinecek_paketler>
pa-applet
</silinecek_paketler>
</uygulama>
