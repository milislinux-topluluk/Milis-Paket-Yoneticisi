<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
pa-applet
</isim>
<tanim>
PulseAudio kontrol uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pa-applet.png
</ekran_resmi>
<kurulacak_paketler>
pa-applet
</kurulacak_paketler>
<silinecek_paketler>
pa-applet
</silinecek_paketler>
</uygulama>
