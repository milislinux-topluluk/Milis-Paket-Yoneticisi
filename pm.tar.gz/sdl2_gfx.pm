<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sdl2_gfx
</isim>
<tanim>
SDL graphics drawing primitives and other support functions (Version 2)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sdl2_gfx.png
</ekran_resmi>
<kurulacak_paketler>
sdl2_gfx
</kurulacak_paketler>
<silinecek_paketler>
sdl2_gfx
</silinecek_paketler>
</uygulama>
