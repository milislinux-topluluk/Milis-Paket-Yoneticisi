<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sdl2_gfx
</isim>
<tanim>
SDL graphics drawing primitives and other support functions (Version 2)
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sdl2_gfx.png
</ekran_resmi>
<kurulacak_paketler>
sdl2_gfx
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.0.3
</surum>
<silinecek_paketler>
sdl2_gfx
</silinecek_paketler>
</uygulama>
