<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
moc
</isim>
<tanim>
Konsol müzik çalar.
</tanim>
<ekran_resmi>
file:///tmp/moc.png
</ekran_resmi>
<kurulacak_paketler>
moc
</kurulacak_paketler>
<silinecek_paketler>
moc
</silinecek_paketler>
</uygulama>
