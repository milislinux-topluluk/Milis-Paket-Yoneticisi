<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
catfish
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/catfish.png
</ekran_resmi>
<kurulacak_paketler>
catfish
</kurulacak_paketler>
<paketci>
milisarge yasarciv
</paketci>
<surum>
1.4.2
</surum>
<silinecek_paketler>
catfish
</silinecek_paketler>
</uygulama>
