<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libatasmart
</isim>
<tanim>
A disk reporting library. It only supports a subset of the ATA S.M.A.R.T. functionality.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libatasmart.png
</ekran_resmi>
<kurulacak_paketler>
libatasmart
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.19
</surum>
<silinecek_paketler>
libatasmart
</silinecek_paketler>
</uygulama>
