<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libatasmart
</isim>
<tanim>
A disk reporting library. It only supports a subset of the ATA S.M.A.R.T. functionality.
</tanim>
<ekran_resmi>
file:///tmp/libatasmart.png
</ekran_resmi>
<kurulacak_paketler>
libatasmart
</kurulacak_paketler>
<silinecek_paketler>
libatasmart
</silinecek_paketler>
</uygulama>
