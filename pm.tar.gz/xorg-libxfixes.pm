<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxfixes
</isim>
<tanim>
libXfixes, library Fixes extension client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxfixes.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxfixes
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
xorg-libxfixes
</silinecek_paketler>
</uygulama>
