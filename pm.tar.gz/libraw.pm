<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libraw
</isim>
<tanim>
For reading RAW files obtained from digital photo cameras (CRW/CR2, NEF, RAF, DNG, etc)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libraw.png
</ekran_resmi>
<kurulacak_paketler>
libraw
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
libraw
</silinecek_paketler>
</uygulama>
