<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
midori
</isim>
<tanim>
WebKitGTK+ kullanan hafif tarayıcı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/midori.png
</ekran_resmi>
<kurulacak_paketler>
midori
</kurulacak_paketler>
<silinecek_paketler>
midori
</silinecek_paketler>
</uygulama>
