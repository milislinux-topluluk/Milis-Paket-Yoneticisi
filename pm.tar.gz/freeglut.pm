<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
freeglut
</isim>
<tanim>
Provides functionality for small OpenGL programs
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/freeglut.png
</ekran_resmi>
<kurulacak_paketler>
freeglut
</kurulacak_paketler>
<paketci>
fanch at nutyx dot org
</paketci>
<silinecek_paketler>
freeglut
</silinecek_paketler>
</uygulama>
