<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wayland
</isim>
<tanim>
Bir bilgisayar görüntüleme sunucusu protokolü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wayland.png
</ekran_resmi>
<kurulacak_paketler>
wayland
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.14.0
</surum>
<silinecek_paketler>
wayland
</silinecek_paketler>
</uygulama>
