<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wayland
</isim>
<tanim>
Bir bilgisayar görüntüleme sunucusu protokolü
</tanim>
<ekran_resmi>
file:///tmp/wayland.png
</ekran_resmi>
<kurulacak_paketler>
wayland
</kurulacak_paketler>
<silinecek_paketler>
wayland
</silinecek_paketler>
</uygulama>
