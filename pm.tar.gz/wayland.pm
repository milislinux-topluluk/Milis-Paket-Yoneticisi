<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
wayland
</isim>
<tanim>
Bir bilgisayar görüntüleme sunucusu protokolü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wayland.png
</ekran_resmi>
<kurulacak_paketler>
wayland
</kurulacak_paketler>
<silinecek_paketler>
wayland
</silinecek_paketler>
</uygulama>
