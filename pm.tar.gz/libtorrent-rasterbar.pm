<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libtorrent-rasterbar
</isim>
<tanim>
Bir C ++ bittorrent kitaplığı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libtorrent-rasterbar.png
</ekran_resmi>
<kurulacak_paketler>
libtorrent-rasterbar
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libtorrent-rasterbar
</silinecek_paketler>
</uygulama>
