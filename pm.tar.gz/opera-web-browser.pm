<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
opera-web-browser
</isim>
<tanim>
Hızlı ve güvenli bir web tarayıcısı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/opera-web-browser.png
</ekran_resmi>
<kurulacak_paketler>
opera-web-browser
</kurulacak_paketler>
<paketci>
yasarciv67
</paketci>
<silinecek_paketler>
opera-web-browser
</silinecek_paketler>
</uygulama>
