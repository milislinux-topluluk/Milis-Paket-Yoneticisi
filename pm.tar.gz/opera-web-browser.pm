<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
opera-web-browser
</isim>
<tanim>
Hızlı ve güvenli bir web tarayıcısı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/opera-web-browser.png
</ekran_resmi>
<kurulacak_paketler>
opera-web-browser
</kurulacak_paketler>
<paketci>
yasarciv67 Cihan_Alkan
</paketci>
<surum>
50.0.2762.45
</surum>
<silinecek_paketler>
opera-web-browser
</silinecek_paketler>
</uygulama>
