<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
js38
</isim>
<tanim>
JavaScript tercüman ve kütüphaneleri - Sürüm 38
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/js38.png
</ekran_resmi>
<kurulacak_paketler>
js38
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
38.8.0
</surum>
<silinecek_paketler>
js38
</silinecek_paketler>
</uygulama>
