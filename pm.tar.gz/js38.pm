<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
js38
</isim>
<tanim>
JavaScript tercüman ve kütüphaneleri - Sürüm 38
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/js38.png
</ekran_resmi>
<kurulacak_paketler>
js38
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
38.8.0
</surum>
<silinecek_paketler>
js38
</silinecek_paketler>
</uygulama>
