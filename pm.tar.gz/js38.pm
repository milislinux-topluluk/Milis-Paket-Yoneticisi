<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
js38
</isim>
<tanim>
JavaScript tercüman ve kütüphaneleri - Sürüm 38
</tanim>
<ekran_resmi>
file:///tmp/js38.png
</ekran_resmi>
<kurulacak_paketler>
js38
</kurulacak_paketler>
<silinecek_paketler>
js38
</silinecek_paketler>
</uygulama>
