<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
smplayer
</isim>
<tanim>
SMPlayer kurulu kodekleriyle tüm ses ve video türlerini oynatabilen Linux için ücretsiz bir medya oynatıcısıdır.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/smplayer.png
</ekran_resmi>
<kurulacak_paketler>
smplayer
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
16.4.0
</surum>
<silinecek_paketler>
smplayer
</silinecek_paketler>
</uygulama>
