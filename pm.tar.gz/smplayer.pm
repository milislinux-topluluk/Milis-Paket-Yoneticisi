<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
smplayer
</isim>
<tanim>
SMPlayer kurulu kodekleriyle tüm ses ve video türlerini oynatabilen Linux için ücretsiz bir medya oynatıcısıdır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/smplayer.png
</ekran_resmi>
<kurulacak_paketler>
smplayer
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
smplayer
</silinecek_paketler>
</uygulama>
