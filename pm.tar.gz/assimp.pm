<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
assimp
</isim>
<tanim>
Portatif Açık Kaynak kütüphanesi, çeşitli tanınmış 3D model formatlarını tek tip bir şekilde içe aktarır
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/assimp.png
</ekran_resmi>
<kurulacak_paketler>
assimp
</kurulacak_paketler>
<paketci>
Cihan_Alkan
</paketci>
<surum>
4.0.1
</surum>
<silinecek_paketler>
assimp
</silinecek_paketler>
</uygulama>
