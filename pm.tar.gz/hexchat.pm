<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
hexchat
</isim>
<tanim>
HexChat bir IRC sohbet programıdır. Aynı anda birden fazla IRC kanalına (sohbet odaları) katılmanızı, herkese açık olarak konuşmanızı, özel birebir konuşmalar yapmanızı, vb. olanak sağlar. Dosya aktarımları da mümkündür.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/hexchat.png
</ekran_resmi>
<kurulacak_paketler>
hexchat
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.12.3
</surum>
<silinecek_paketler>
hexchat
</silinecek_paketler>
</uygulama>
