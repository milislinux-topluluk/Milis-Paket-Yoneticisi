<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libunique
</isim>
<tanim>
GTK3 için tekli örnek uygulamaları yazan kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libunique.png
</ekran_resmi>
<kurulacak_paketler>
libunique
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.0.2
</surum>
<silinecek_paketler>
libunique
</silinecek_paketler>
</uygulama>
