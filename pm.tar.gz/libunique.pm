<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libunique
</isim>
<tanim>
GTK3 için tekli örnek uygulamaları yazan kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libunique.png
</ekran_resmi>
<kurulacak_paketler>
libunique
</kurulacak_paketler>
<silinecek_paketler>
libunique
</silinecek_paketler>
</uygulama>
