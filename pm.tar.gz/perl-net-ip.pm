<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-net-ip
</isim>
<tanim>
Perl Modülü
</tanim>
<ekran_resmi>
file:///tmp/perl-net-ip.png
</ekran_resmi>
<kurulacak_paketler>
perl-net-ip
</kurulacak_paketler>
<silinecek_paketler>
perl-net-ip
</silinecek_paketler>
</uygulama>
