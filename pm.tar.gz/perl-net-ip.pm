<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-net-ip
</isim>
<tanim>
Perl Modülü
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-net-ip.png
</ekran_resmi>
<kurulacak_paketler>
perl-net-ip
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.26
</surum>
<silinecek_paketler>
perl-net-ip
</silinecek_paketler>
</uygulama>
