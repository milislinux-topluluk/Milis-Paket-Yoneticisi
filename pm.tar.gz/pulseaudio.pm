<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
pulseaudio
</isim>
<tanim>
Özellikli, genel amaçlı bir ses sunucusu
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pulseaudio.png
</ekran_resmi>
<kurulacak_paketler>
pulseaudio
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
11.1
</surum>
<silinecek_paketler>
pulseaudio
</silinecek_paketler>
</uygulama>
