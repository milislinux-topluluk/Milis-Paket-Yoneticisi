<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
pulseaudio
</isim>
<tanim>
Özellikli, genel amaçlı bir ses sunucusu
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pulseaudio.png
</ekran_resmi>
<kurulacak_paketler>
pulseaudio
</kurulacak_paketler>
<silinecek_paketler>
pulseaudio
</silinecek_paketler>
</uygulama>
