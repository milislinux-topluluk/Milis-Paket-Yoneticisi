<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xfce4-notifyd
</isim>
<tanim>
Freedesktop masaüstü bildirimleri belirtiminin "sunucu tarafı" kısmı.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xfce4-notifyd.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-notifyd
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.3.6
</surum>
<silinecek_paketler>
xfce4-notifyd
</silinecek_paketler>
</uygulama>
