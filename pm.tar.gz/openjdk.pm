<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
openjdk
</isim>
<tanim>
A set of programs called a Java Development Kit (JDK).
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/openjdk.png
</ekran_resmi>
<kurulacak_paketler>
openjdk
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<silinecek_paketler>
openjdk
</silinecek_paketler>
</uygulama>
