<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libbluray
</isim>
<tanim>
Blu-Ray access library.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libbluray.png
</ekran_resmi>
<kurulacak_paketler>
libbluray
</kurulacak_paketler>
<paketci>
Danny Rawlins, crux at romster dot me
</paketci>
<surum>
0.6.2
</surum>
<silinecek_paketler>
libbluray
</silinecek_paketler>
</uygulama>
