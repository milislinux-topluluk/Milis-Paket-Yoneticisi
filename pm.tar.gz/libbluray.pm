<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libbluray
</isim>
<tanim>
Blu-Ray access library.
</tanim>
<ekran_resmi>
file:///tmp/libbluray.png
</ekran_resmi>
<kurulacak_paketler>
libbluray
</kurulacak_paketler>
<silinecek_paketler>
libbluray
</silinecek_paketler>
</uygulama>
