<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iw
</isim>
<tanim>
Kablosuz aygıtlar için nl80211 tabanlı CLI ayarlama aracı
</tanim>
<ekran_resmi>
file:///tmp/iw.png
</ekran_resmi>
<kurulacak_paketler>
iw
</kurulacak_paketler>
<silinecek_paketler>
iw
</silinecek_paketler>
</uygulama>
