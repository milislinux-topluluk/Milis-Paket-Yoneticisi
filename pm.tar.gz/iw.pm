<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
iw
</isim>
<tanim>
Kablosuz aygıtlar için nl80211 tabanlı CLI ayarlama aracı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/iw.png
</ekran_resmi>
<kurulacak_paketler>
iw
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
4.9
</surum>
<silinecek_paketler>
iw
</silinecek_paketler>
</uygulama>
