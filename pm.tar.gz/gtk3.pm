<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk3
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtk3.png
</ekran_resmi>
<kurulacak_paketler>
gtk3
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.22.15
</surum>
<silinecek_paketler>
gtk3
</silinecek_paketler>
</uygulama>
