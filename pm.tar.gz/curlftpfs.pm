<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
curlftpfs
</isim>
<tanim>
A FTP dosya sistemi.curl ve fuse tabanlı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/curlftpfs.png
</ekran_resmi>
<kurulacak_paketler>
curlftpfs
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
curlftpfs
</silinecek_paketler>
</uygulama>
