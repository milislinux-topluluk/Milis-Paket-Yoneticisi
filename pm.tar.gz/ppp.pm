<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ppp
</isim>
<tanim>
dialup ağ yapılandırması için noktadan noktaya arkaplan çalışanı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ppp.png
</ekran_resmi>
<kurulacak_paketler>
ppp
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
ppp
</silinecek_paketler>
</uygulama>
