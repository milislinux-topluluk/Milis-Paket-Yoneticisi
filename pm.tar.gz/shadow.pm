<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
shadow
</isim>
<tanim>
The Shadow package contains programs for handling passwords in a secure way.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/shadow.png
</ekran_resmi>
<kurulacak_paketler>
shadow
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
4.2.1
</surum>
<silinecek_paketler>
shadow
</silinecek_paketler>
</uygulama>
