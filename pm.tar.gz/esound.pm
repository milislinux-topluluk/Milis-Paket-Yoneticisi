<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
esound
</isim>
<tanim>
Aydınlanmış Ses Daemonu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/esound.png
</ekran_resmi>
<kurulacak_paketler>
esound
</kurulacak_paketler>
<paketci>
Cihan_Alkan
</paketci>
<surum>
0.2.41
</surum>
<silinecek_paketler>
esound
</silinecek_paketler>
</uygulama>
