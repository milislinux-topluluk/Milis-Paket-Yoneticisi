<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
zenity
</isim>
<tanim>
Display graphical dialog boxes from shell scripts.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/zenity.png
</ekran_resmi>
<kurulacak_paketler>
zenity
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
3.16.3
</surum>
<silinecek_paketler>
zenity
</silinecek_paketler>
</uygulama>
