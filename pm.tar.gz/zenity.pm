<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
zenity
</isim>
<tanim>
Display graphical dialog boxes from shell scripts.
</tanim>
<ekran_resmi>
file:///tmp/zenity.png
</ekran_resmi>
<kurulacak_paketler>
zenity
</kurulacak_paketler>
<silinecek_paketler>
zenity
</silinecek_paketler>
</uygulama>
