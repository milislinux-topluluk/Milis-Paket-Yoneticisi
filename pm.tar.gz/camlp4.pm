<?xml version="1.0"?>
<uygulama>
<grup>
geliştirme
</grup>
<isim>
camlp4
</isim>
<tanim>
Camlp4 tool
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/camlp4.png
</ekran_resmi>
<kurulacak_paketler>
camlp4
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
camlp4
</silinecek_paketler>
</uygulama>
