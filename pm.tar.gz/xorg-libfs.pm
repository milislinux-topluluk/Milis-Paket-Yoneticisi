<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libfs
</isim>
<tanim>
libFS, library X Font Service client
</tanim>
<ekran_resmi>
file:///tmp/xorg-libfs.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libfs
</kurulacak_paketler>
<silinecek_paketler>
xorg-libfs
</silinecek_paketler>
</uygulama>
