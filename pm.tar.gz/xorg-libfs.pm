<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xorg-libfs
</isim>
<tanim>
libFS, library X Font Service client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libfs.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libfs
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.0.7
</surum>
<silinecek_paketler>
xorg-libfs
</silinecek_paketler>
</uygulama>
