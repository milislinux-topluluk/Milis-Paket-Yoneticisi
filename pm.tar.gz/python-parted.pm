<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python-parted
</isim>
<tanim>
Libparted'e Python bağları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-parted.png
</ekran_resmi>
<kurulacak_paketler>
python-parted
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
3.10.0
</surum>
<silinecek_paketler>
python-parted
</silinecek_paketler>
</uygulama>
