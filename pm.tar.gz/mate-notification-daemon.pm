<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-notification-daemon
</isim>
<tanim>
MATE için bildirim uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-notification-daemon.png
</ekran_resmi>
<kurulacak_paketler>
mate-notification-daemon
</kurulacak_paketler>
<silinecek_paketler>
mate-notification-daemon
</silinecek_paketler>
</uygulama>
