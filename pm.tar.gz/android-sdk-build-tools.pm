<?xml version="1.0"?>
<uygulama>
<grup>
Geliştirme
</grup>
<isim>
android-sdk-build-tools
</isim>
<tanim>
Google Android SDK için araçlar oluşturun (aapt, aidl, dexdump, dx, llvm-rs-cc)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/android-sdk-build-tools.png
</ekran_resmi>
<kurulacak_paketler>
android-sdk-build-tools
</kurulacak_paketler>
<paketci>
CihanAlkan
</paketci>
<surum>
r26
</surum>
<silinecek_paketler>
android-sdk-build-tools
</silinecek_paketler>
</uygulama>
