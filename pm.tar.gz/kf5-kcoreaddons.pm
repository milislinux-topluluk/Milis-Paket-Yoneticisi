<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kf5-kcoreaddons
</isim>
<tanim>
QtCore'a Eklentiler
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kcoreaddons.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kcoreaddons
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kcoreaddons
</silinecek_paketler>
</uygulama>
