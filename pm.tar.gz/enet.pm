<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
enet
</isim>
<tanim>
UDP'nin üstünde nispeten ince, basit ve sağlam bir ağ iletişimi katmanı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/enet.png
</ekran_resmi>
<kurulacak_paketler>
enet
</kurulacak_paketler>
<paketci>
Cihan_Alkan
</paketci>
<surum>
1.3.13
</surum>
<silinecek_paketler>
enet
</silinecek_paketler>
</uygulama>
