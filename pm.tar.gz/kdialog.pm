<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kdialog
</isim>
<tanim>
Kabuk komut dosyalarından diyalog kutuları görüntülemek için bir yardımcı program
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kdialog.png
</ekran_resmi>
<kurulacak_paketler>
kdialog
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
17.04.2
</surum>
<silinecek_paketler>
kdialog
</silinecek_paketler>
</uygulama>
