<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kdialog
</isim>
<tanim>
Kabuk komut dosyalarından diyalog kutuları görüntülemek için bir yardımcı program
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kdialog.png
</ekran_resmi>
<kurulacak_paketler>
kdialog
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
17.12.0
</surum>
<silinecek_paketler>
kdialog
</silinecek_paketler>
</uygulama>
