<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libringclient
</isim>
<tanim>
Client communication library for ring.cx (formerly known as SFLphone)
</tanim>
<ekran_resmi>
file:///tmp/libringclient.png
</ekran_resmi>
<kurulacak_paketler>
libringclient
</kurulacak_paketler>
<silinecek_paketler>
libringclient
</silinecek_paketler>
</uygulama>
