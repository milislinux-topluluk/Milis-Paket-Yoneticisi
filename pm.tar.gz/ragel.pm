<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ragel
</isim>
<tanim>
Sonlu durum makinelerini düzenli dillerden çalıştırılabilir C, C ++, Objective-C veya D koduna derler.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/ragel.png
</ekran_resmi>
<kurulacak_paketler>
ragel
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
6.10
</surum>
<silinecek_paketler>
ragel
</silinecek_paketler>
</uygulama>
