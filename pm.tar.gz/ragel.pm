<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ragel
</isim>
<tanim>
Sonlu durum makinelerini düzenli dillerden çalıştırılabilir C, C ++, Objective-C veya D koduna derler.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ragel.png
</ekran_resmi>
<kurulacak_paketler>
ragel
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
6.10
</surum>
<silinecek_paketler>
ragel
</silinecek_paketler>
</uygulama>
