<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ragel
</isim>
<tanim>
Sonlu durum makinelerini düzenli dillerden çalıştırılabilir C, C ++, Objective-C veya D koduna derler.
</tanim>
<ekran_resmi>
file:///tmp/ragel.png
</ekran_resmi>
<kurulacak_paketler>
ragel
</kurulacak_paketler>
<silinecek_paketler>
ragel
</silinecek_paketler>
</uygulama>
