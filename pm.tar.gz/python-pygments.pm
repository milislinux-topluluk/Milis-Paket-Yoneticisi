<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-pygments
</isim>
<tanim>
Python sözdizimi vurgulayıcı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-pygments.png
</ekran_resmi>
<kurulacak_paketler>
python-pygments
</kurulacak_paketler>
<silinecek_paketler>
python-pygments
</silinecek_paketler>
</uygulama>
