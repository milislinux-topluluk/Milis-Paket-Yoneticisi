<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
python-pyxml
</isim>
<tanim>
Python XML, selinux-refpolicy için gereklilik
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-pyxml.png
</ekran_resmi>
<kurulacak_paketler>
python-pyxml
</kurulacak_paketler>
<paketci>
Oltulu
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
python-pyxml
</silinecek_paketler>
</uygulama>
