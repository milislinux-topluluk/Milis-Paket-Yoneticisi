<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
python-pyxml
</isim>
<tanim>
Python XML, selinux-refpolicy için gereklilik
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-pyxml.png
</ekran_resmi>
<kurulacak_paketler>
python-pyxml
</kurulacak_paketler>
<paketci>
Oltulu
</paketci>
<surum>
0.8.4
</surum>
<silinecek_paketler>
python-pyxml
</silinecek_paketler>
</uygulama>
