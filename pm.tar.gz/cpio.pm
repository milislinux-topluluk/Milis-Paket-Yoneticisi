<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
cpio
</isim>
<tanim>
Copies files into or out of a cpio or tar archive.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cpio.png
</ekran_resmi>
<kurulacak_paketler>
cpio
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.11
</surum>
<silinecek_paketler>
cpio
</silinecek_paketler>
</uygulama>
