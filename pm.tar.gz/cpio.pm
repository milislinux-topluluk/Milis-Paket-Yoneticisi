<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
cpio
</isim>
<tanim>
Copies files into or out of a cpio or tar archive.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/cpio.png
</ekran_resmi>
<kurulacak_paketler>
cpio
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.11
</surum>
<silinecek_paketler>
cpio
</silinecek_paketler>
</uygulama>
