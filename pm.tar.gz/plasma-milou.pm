<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-milou
</isim>
<tanim>
Baloo'nun üzerine kurulmuş özel bir arama uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-milou.png
</ekran_resmi>
<kurulacak_paketler>
plasma-milou
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-milou
</silinecek_paketler>
</uygulama>
