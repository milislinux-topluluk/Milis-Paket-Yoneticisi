<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-milou
</isim>
<tanim>
Baloo'nun üzerine kurulmuş özel bir arama uygulaması
</tanim>
<ekran_resmi>
file:///tmp/plasma-milou.png
</ekran_resmi>
<kurulacak_paketler>
plasma-milou
</kurulacak_paketler>
<silinecek_paketler>
plasma-milou
</silinecek_paketler>
</uygulama>
