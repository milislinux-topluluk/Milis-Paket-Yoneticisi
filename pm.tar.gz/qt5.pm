<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
qt5
</isim>
<tanim>
Qt ücretsiz sürümü, sürüm 5.x
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qt5.png
</ekran_resmi>
<kurulacak_paketler>
qt5
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.9.1
</surum>
<silinecek_paketler>
qt5
</silinecek_paketler>
</uygulama>
