<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
bzip2
</isim>
<tanim>
Programs for compressing and decompressing files.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/bzip2.png
</ekran_resmi>
<kurulacak_paketler>
bzip2
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.0.6
</surum>
<silinecek_paketler>
bzip2
</silinecek_paketler>
</uygulama>
