<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
bzip2
</isim>
<tanim>
Programs for compressing and decompressing files.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bzip2.png
</ekran_resmi>
<kurulacak_paketler>
bzip2
</kurulacak_paketler>
<silinecek_paketler>
bzip2
</silinecek_paketler>
</uygulama>
