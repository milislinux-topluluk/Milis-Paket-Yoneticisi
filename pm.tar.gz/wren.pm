<?xml version="1.0"?>
<uygulama>
<grup>
Geliştirme
</grup>
<isim>
wren
</isim>
<tanim>
Küçük,hızlı ve sınıf bazlı script dili
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wren.png
</ekran_resmi>
<kurulacak_paketler>
wren
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.1.0
</surum>
<silinecek_paketler>
wren
</silinecek_paketler>
</uygulama>
