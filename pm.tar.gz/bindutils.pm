<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
bindutils
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bindutils.png
</ekran_resmi>
<kurulacak_paketler>
bindutils
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
9.11.0
</surum>
<silinecek_paketler>
bindutils
</silinecek_paketler>
</uygulama>
