<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
bindutils
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bindutils.png
</ekran_resmi>
<kurulacak_paketler>
bindutils
</kurulacak_paketler>
<silinecek_paketler>
bindutils
</silinecek_paketler>
</uygulama>
