<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gvim
</isim>
<tanim>
Vim düzenleyicisinin GTK sürümü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gvim.png
</ekran_resmi>
<kurulacak_paketler>
gvim
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
8.0.0329
</surum>
<silinecek_paketler>
gvim
</silinecek_paketler>
</uygulama>
