<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gvim
</isim>
<tanim>
Vim düzenleyicisinin GTK sürümü
</tanim>
<ekran_resmi>
file:///tmp/gvim.png
</ekran_resmi>
<kurulacak_paketler>
gvim
</kurulacak_paketler>
<silinecek_paketler>
gvim
</silinecek_paketler>
</uygulama>
