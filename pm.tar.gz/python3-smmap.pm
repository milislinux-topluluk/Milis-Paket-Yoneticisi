<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-smmap
</isim>
<tanim>
python için bellek harita yöneticisinin saf git uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-smmap.png
</ekran_resmi>
<kurulacak_paketler>
python3-smmap
</kurulacak_paketler>
<silinecek_paketler>
python3-smmap
</silinecek_paketler>
</uygulama>
