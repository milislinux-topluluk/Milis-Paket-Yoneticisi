<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sysv-rc-conf
</isim>
<tanim>
sysvinit yonetimi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sysv-rc-conf.png
</ekran_resmi>
<kurulacak_paketler>
sysv-rc-conf
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.98
</surum>
<silinecek_paketler>
sysv-rc-conf
</silinecek_paketler>
</uygulama>
