<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sysv-rc-conf
</isim>
<tanim>
sysvinit yonetimi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sysv-rc-conf.png
</ekran_resmi>
<kurulacak_paketler>
sysv-rc-conf
</kurulacak_paketler>
<silinecek_paketler>
sysv-rc-conf
</silinecek_paketler>
</uygulama>
