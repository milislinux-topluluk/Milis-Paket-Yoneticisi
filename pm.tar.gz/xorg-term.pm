<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-term
</isim>
<tanim>
xterm is a terminal emulator for the X Window System.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-term.png
</ekran_resmi>
<kurulacak_paketler>
xorg-term
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
322
</surum>
<silinecek_paketler>
xorg-term
</silinecek_paketler>
</uygulama>
