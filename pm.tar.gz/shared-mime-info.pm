<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
shared-mime-info
</isim>
<tanim>
Allows central updates of MIME information for all supporting applications.
</tanim>
<ekran_resmi>
file:///tmp/shared-mime-info.png
</ekran_resmi>
<kurulacak_paketler>
shared-mime-info
</kurulacak_paketler>
<silinecek_paketler>
shared-mime-info
</silinecek_paketler>
</uygulama>
