<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
shared-mime-info
</isim>
<tanim>
Allows central updates of MIME information for all supporting applications.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/shared-mime-info.png
</ekran_resmi>
<kurulacak_paketler>
shared-mime-info
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org, tnut at nutyx dot org
</paketci>
<surum>
1.5
</surum>
<silinecek_paketler>
shared-mime-info
</silinecek_paketler>
</uygulama>
