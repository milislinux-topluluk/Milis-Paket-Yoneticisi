<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telepathy-kde-call-ui
</isim>
<tanim>
Telepati için Sesli/Görüntülü Arama Arabirimi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telepathy-kde-call-ui.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-call-ui
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
telepathy-kde-call-ui
</silinecek_paketler>
</uygulama>
