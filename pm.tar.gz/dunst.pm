<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dunst
</isim>
<tanim>
Hızlı ve menulü , sistem çekmecesi için simge oluştuma uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dunst.png
</ekran_resmi>
<kurulacak_paketler>
dunst
</kurulacak_paketler>
<silinecek_paketler>
dunst
</silinecek_paketler>
</uygulama>
