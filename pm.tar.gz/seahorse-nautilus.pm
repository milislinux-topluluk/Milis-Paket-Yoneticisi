<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
seahorse-nautilus
</isim>
<tanim>
Nautilus için PGP şifreleme ve imzalama.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/seahorse-nautilus.png
</ekran_resmi>
<kurulacak_paketler>
seahorse-nautilus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
seahorse-nautilus
</silinecek_paketler>
</uygulama>
