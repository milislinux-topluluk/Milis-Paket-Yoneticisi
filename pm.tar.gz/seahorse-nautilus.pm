<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
seahorse-nautilus
</isim>
<tanim>
Nautilus için PGP şifreleme ve imzalama.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/seahorse-nautilus.png
</ekran_resmi>
<kurulacak_paketler>
seahorse-nautilus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.11.92
</surum>
<silinecek_paketler>
seahorse-nautilus
</silinecek_paketler>
</uygulama>
