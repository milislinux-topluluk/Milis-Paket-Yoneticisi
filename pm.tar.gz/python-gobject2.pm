<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-gobject2
</isim>
<tanim>
provides the links of Python 2 for the class GObject of GLib.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-gobject2.png
</ekran_resmi>
<kurulacak_paketler>
python-gobject2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.28.6
</surum>
<silinecek_paketler>
python-gobject2
</silinecek_paketler>
</uygulama>
