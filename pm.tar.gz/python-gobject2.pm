<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-gobject2
</isim>
<tanim>
provides the links of Python 2 for the class GObject of GLib.
</tanim>
<ekran_resmi>
file:///tmp/python-gobject2.png
</ekran_resmi>
<kurulacak_paketler>
python-gobject2
</kurulacak_paketler>
<silinecek_paketler>
python-gobject2
</silinecek_paketler>
</uygulama>
