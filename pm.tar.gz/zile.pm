<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
zile
</isim>
<tanim>
Zile metin düzenleyici
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/zile.png
</ekran_resmi>
<kurulacak_paketler>
zile
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4.13
</surum>
<silinecek_paketler>
zile
</silinecek_paketler>
</uygulama>
