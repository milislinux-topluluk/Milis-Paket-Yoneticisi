<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
zile
</isim>
<tanim>
Zile metin düzenleyici
</tanim>
<ekran_resmi>
file:///tmp/zile.png
</ekran_resmi>
<kurulacak_paketler>
zile
</kurulacak_paketler>
<silinecek_paketler>
zile
</silinecek_paketler>
</uygulama>
