<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
cdparanoia
</isim>
<tanim>
Compact Disc Digital Audio extraction tool
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/cdparanoia.png
</ekran_resmi>
<kurulacak_paketler>
cdparanoia
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
cdparanoia
</silinecek_paketler>
</uygulama>
