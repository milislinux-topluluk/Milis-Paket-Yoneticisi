<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
cdparanoia
</isim>
<tanim>
Compact Disc Digital Audio extraction tool
</tanim>
<ekran_resmi>
file:///tmp/cdparanoia.png
</ekran_resmi>
<kurulacak_paketler>
cdparanoia
</kurulacak_paketler>
<silinecek_paketler>
cdparanoia
</silinecek_paketler>
</uygulama>
