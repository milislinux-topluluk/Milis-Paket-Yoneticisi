<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
cdparanoia
</isim>
<tanim>
Compact Disc Digital Audio extraction tool
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cdparanoia.png
</ekran_resmi>
<kurulacak_paketler>
cdparanoia
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
10.2
</surum>
<silinecek_paketler>
cdparanoia
</silinecek_paketler>
</uygulama>
