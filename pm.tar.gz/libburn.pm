<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libburn
</isim>
<tanim>
libburn is a library for writing preformatted data onto optical media
</tanim>
<ekran_resmi>
file:///tmp/libburn.png
</ekran_resmi>
<kurulacak_paketler>
libburn
</kurulacak_paketler>
<silinecek_paketler>
libburn
</silinecek_paketler>
</uygulama>
