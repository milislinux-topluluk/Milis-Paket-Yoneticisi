<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libburn
</isim>
<tanim>
libburn is a library for writing preformatted data onto optical media
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libburn.png
</ekran_resmi>
<kurulacak_paketler>
libburn
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
1.4.2
</surum>
<silinecek_paketler>
libburn
</silinecek_paketler>
</uygulama>
