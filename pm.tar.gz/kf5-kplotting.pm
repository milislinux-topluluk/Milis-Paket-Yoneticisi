<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kplotting
</isim>
<tanim>
Hafif plotlama çerçevesi
</tanim>
<ekran_resmi>
file:///tmp/kf5-kplotting.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kplotting
</kurulacak_paketler>
<silinecek_paketler>
kf5-kplotting
</silinecek_paketler>
</uygulama>
