<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kf5-kjs
</isim>
<tanim>
Uygulamalarda JS betiğini destekleme
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kjs.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kjs
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kjs
</silinecek_paketler>
</uygulama>
