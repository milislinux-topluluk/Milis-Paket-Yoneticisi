<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
totem
</isim>
<tanim>
GStreamer tabanlı GNOME3 film oynatıcı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/totem.png
</ekran_resmi>
<kurulacak_paketler>
totem
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
totem
</silinecek_paketler>
</uygulama>
