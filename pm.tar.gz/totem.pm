<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
totem
</isim>
<tanim>
GStreamer tabanlı GNOME3 film oynatıcı.
</tanim>
<ekran_resmi>
file:///tmp/totem.png
</ekran_resmi>
<kurulacak_paketler>
totem
</kurulacak_paketler>
<silinecek_paketler>
totem
</silinecek_paketler>
</uygulama>
