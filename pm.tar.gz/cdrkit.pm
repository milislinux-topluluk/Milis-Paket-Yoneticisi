<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
cdrkit
</isim>
<tanim>
Set of programs for CD/DVD recording, ISO image creation and audio CD extraction
</tanim>
<ekran_resmi>
file:///tmp/cdrkit.png
</ekran_resmi>
<kurulacak_paketler>
cdrkit
</kurulacak_paketler>
<silinecek_paketler>
cdrkit
</silinecek_paketler>
</uygulama>
