<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
cdrkit
</isim>
<tanim>
Set of programs for CD/DVD recording, ISO image creation and audio CD extraction
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/cdrkit.png
</ekran_resmi>
<kurulacak_paketler>
cdrkit
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.1.11
</surum>
<silinecek_paketler>
cdrkit
</silinecek_paketler>
</uygulama>
