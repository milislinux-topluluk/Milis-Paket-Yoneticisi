<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-pytz
</isim>
<tanim>
Python yerel zaman kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python3-pytz.png
</ekran_resmi>
<kurulacak_paketler>
python3-pytz
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2017.2
</surum>
<silinecek_paketler>
python3-pytz
</silinecek_paketler>
</uygulama>
