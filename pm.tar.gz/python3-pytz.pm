<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-pytz
</isim>
<tanim>
Python yerel zaman kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-pytz.png
</ekran_resmi>
<kurulacak_paketler>
python3-pytz
</kurulacak_paketler>
<silinecek_paketler>
python3-pytz
</silinecek_paketler>
</uygulama>
