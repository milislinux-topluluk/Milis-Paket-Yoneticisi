<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gparted
</isim>
<tanim>
Gparted is the Gnome Partition Editor, a Gtk 2 GUI that can create, reorganise or delete disk partitions.
</tanim>
<ekran_resmi>
file:///tmp/gparted.png
</ekran_resmi>
<kurulacak_paketler>
gparted
</kurulacak_paketler>
<silinecek_paketler>
gparted
</silinecek_paketler>
</uygulama>
