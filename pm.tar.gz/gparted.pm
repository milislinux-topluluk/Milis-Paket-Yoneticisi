<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gparted
</isim>
<tanim>
Gparted is the Gnome Partition Editor, a Gtk 2 GUI that can create, reorganise or delete disk partitions.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gparted.png
</ekran_resmi>
<kurulacak_paketler>
gparted
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
gparted
</silinecek_paketler>
</uygulama>
