<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gparted
</isim>
<tanim>
Gparted is the Gnome Partition Editor, a Gtk 2 GUI that can create, reorganise or delete disk partitions.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gparted.png
</ekran_resmi>
<kurulacak_paketler>
gparted
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.27.0
</surum>
<silinecek_paketler>
gparted
</silinecek_paketler>
</uygulama>
