<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-pa
</isim>
<tanim>
Plasma applet for audio volume management using PulseAudio
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-pa.png
</ekran_resmi>
<kurulacak_paketler>
plasma-pa
</kurulacak_paketler>
<paketci>
alihan-ozturk@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-pa
</silinecek_paketler>
</uygulama>
