<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-pa
</isim>
<tanim>
PulseAudio'yu kullanarak ses hacmi yönetimi için plazma uygulaması
</tanim>
<ekran_resmi>
file:///tmp/plasma-pa.png
</ekran_resmi>
<kurulacak_paketler>
plasma-pa
</kurulacak_paketler>
<silinecek_paketler>
plasma-pa
</silinecek_paketler>
</uygulama>
