<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lua
</isim>
<tanim>
Uygulamaları genişletmek için tasarlanmış bir programlama dili
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lua.png
</ekran_resmi>
<kurulacak_paketler>
lua
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
lua
</silinecek_paketler>
</uygulama>
