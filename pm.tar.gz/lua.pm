<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lua
</isim>
<tanim>
Uygulamaları genişletmek için tasarlanmış bir programlama dili
</tanim>
<ekran_resmi>
file:///tmp/lua.png
</ekran_resmi>
<kurulacak_paketler>
lua
</kurulacak_paketler>
<silinecek_paketler>
lua
</silinecek_paketler>
</uygulama>
