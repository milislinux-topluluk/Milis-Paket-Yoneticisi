<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lua
</isim>
<tanim>
Uygulamaları genişletmek için tasarlanmış bir programlama dili
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lua.png
</ekran_resmi>
<kurulacak_paketler>
lua
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.3.4
</surum>
<silinecek_paketler>
lua
</silinecek_paketler>
</uygulama>
