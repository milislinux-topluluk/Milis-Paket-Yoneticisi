<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
slang
</isim>
<tanim>
S-Lang is a powerful interpreted language
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/slang.png
</ekran_resmi>
<kurulacak_paketler>
slang
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.2.4
</surum>
<silinecek_paketler>
slang
</silinecek_paketler>
</uygulama>
