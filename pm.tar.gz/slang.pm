<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
slang
</isim>
<tanim>
S-Lang is a powerful interpreted language
</tanim>
<ekran_resmi>
file:///tmp/slang.png
</ekran_resmi>
<kurulacak_paketler>
slang
</kurulacak_paketler>
<silinecek_paketler>
slang
</silinecek_paketler>
</uygulama>
