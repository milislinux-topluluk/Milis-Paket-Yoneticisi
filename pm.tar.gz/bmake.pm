<?xml version="1.0"?>
<uygulama>
<grup>
geliştirme
</grup>
<isim>
bmake
</isim>
<tanim>
NetBSD make inşa aracının taşınabilir bir sürümü.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bmake.png
</ekran_resmi>
<kurulacak_paketler>
bmake
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
bmake
</silinecek_paketler>
</uygulama>
