<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
autoconf-archive
</isim>
<tanim>
Serbestçe yeniden kullanılabilir Autoconf makroları topluluğu
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/autoconf-archive.png
</ekran_resmi>
<kurulacak_paketler>
autoconf-archive
</kurulacak_paketler>
<silinecek_paketler>
autoconf-archive
</silinecek_paketler>
</uygulama>
