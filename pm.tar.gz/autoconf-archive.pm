<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
autoconf-archive
</isim>
<tanim>
Serbestçe yeniden kullanılabilir Autoconf makroları topluluğu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/autoconf-archive.png
</ekran_resmi>
<kurulacak_paketler>
autoconf-archive
</kurulacak_paketler>
<paketci>
CihanAlkan
</paketci>
<surum>
2017.03.21
</surum>
<silinecek_paketler>
autoconf-archive
</silinecek_paketler>
</uygulama>
