<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
iproute2
</isim>
<tanim>
Programs for basic and advanced network routing.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/iproute2.png
</ekran_resmi>
<kurulacak_paketler>
iproute2
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
4.4.0
</surum>
<silinecek_paketler>
iproute2
</silinecek_paketler>
</uygulama>
