<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iproute2
</isim>
<tanim>
Programs for basic and advanced network routing.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/iproute2.png
</ekran_resmi>
<kurulacak_paketler>
iproute2
</kurulacak_paketler>
<silinecek_paketler>
iproute2
</silinecek_paketler>
</uygulama>
