<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-elementary-icon-theme
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-elementary-icon-theme.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-elementary-icon-theme
</kurulacak_paketler>
<silinecek_paketler>
xfce4-elementary-icon-theme
</silinecek_paketler>
</uygulama>
