<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kdeconnect
</isim>
<tanim>
Adds communication between KDE and your smartphone
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kdeconnect.png
</ekran_resmi>
<kurulacak_paketler>
kdeconnect
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.9g
</surum>
<silinecek_paketler>
kdeconnect
</silinecek_paketler>
</uygulama>
