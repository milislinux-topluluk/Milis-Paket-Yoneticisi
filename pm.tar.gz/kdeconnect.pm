<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kdeconnect
</isim>
<tanim>
KDE ve akıllı telefonunuz arasında iletişim kurar
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kdeconnect.png
</ekran_resmi>
<kurulacak_paketler>
kdeconnect
</kurulacak_paketler>
<silinecek_paketler>
kdeconnect
</silinecek_paketler>
</uygulama>
