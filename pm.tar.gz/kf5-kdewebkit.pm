<?xml version="1.0"?>
<uygulama>
<grup>
Kde
</grup>
<isim>
kf5-kdewebkit
</isim>
<tanim>
QtWebKit için KDE Entegrasyonu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-kdewebkit.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdewebkit
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kdewebkit
</silinecek_paketler>
</uygulama>
