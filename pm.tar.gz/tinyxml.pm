<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
tinyxml
</isim>
<tanim>
A simple, small, minimal, C++ XML parser
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/tinyxml.png
</ekran_resmi>
<kurulacak_paketler>
tinyxml
</kurulacak_paketler>
<paketci>
fanch at nutyx dot org
</paketci>
<surum>
2.6.2
</surum>
<silinecek_paketler>
tinyxml
</silinecek_paketler>
</uygulama>
