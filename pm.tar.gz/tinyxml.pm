<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
tinyxml
</isim>
<tanim>
A simple, small, minimal, C++ XML parser
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/tinyxml.png
</ekran_resmi>
<kurulacak_paketler>
tinyxml
</kurulacak_paketler>
<silinecek_paketler>
tinyxml
</silinecek_paketler>
</uygulama>
