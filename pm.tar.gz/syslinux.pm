<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
syslinux
</isim>
<tanim>
description="boot loaders that boot from FAT, ext2/3/4 and btrfs filesystems, from CDs and via PXE"
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/syslinux.png
</ekran_resmi>
<kurulacak_paketler>
syslinux
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
6.03
</surum>
<silinecek_paketler>
syslinux
</silinecek_paketler>
</uygulama>
