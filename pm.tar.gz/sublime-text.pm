<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sublime-text
</isim>
<tanim>
Geliştiriciler için sofistike text editörü
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/sublime-text.png
</ekran_resmi>
<kurulacak_paketler>
sublime-text
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3
</surum>
<silinecek_paketler>
sublime-text
</silinecek_paketler>
</uygulama>
