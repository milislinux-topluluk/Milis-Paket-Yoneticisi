<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sublime-text
</isim>
<tanim>
Geliştiriciler için sofistike text editörü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sublime-text.png
</ekran_resmi>
<kurulacak_paketler>
sublime-text
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2
</surum>
<silinecek_paketler>
sublime-text
</silinecek_paketler>
</uygulama>
