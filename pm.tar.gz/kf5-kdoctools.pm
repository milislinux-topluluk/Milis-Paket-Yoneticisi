<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdoctools
</isim>
<tanim>
DocBook'tan dokümantasyon yarat
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kdoctools.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdoctools
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kdoctools
</silinecek_paketler>
</uygulama>
