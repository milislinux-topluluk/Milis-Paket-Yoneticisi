<?xml version="1.0"?>
<uygulama>
<grup>
Kde
</grup>
<isim>
kf5-kdoctools
</isim>
<tanim>
DocBook'tan dokümantasyon yarat
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-kdoctools.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdoctools
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kdoctools
</silinecek_paketler>
</uygulama>
