<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kdoctools
</isim>
<tanim>
DocBook'tan dokümantasyon yarat
</tanim>
<ekran_resmi>
file:///tmp/kf5-kdoctools.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kdoctools
</kurulacak_paketler>
<silinecek_paketler>
kf5-kdoctools
</silinecek_paketler>
</uygulama>
