<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libzeitgeist
</isim>
<tanim>
C ve Vala'dan Zeitgeist olay günlüğüne erişmek ve yönetmek için kullanılan istemci kitaplığı.
</tanim>
<ekran_resmi>
file:///tmp/libzeitgeist.png
</ekran_resmi>
<kurulacak_paketler>
libzeitgeist
</kurulacak_paketler>
<silinecek_paketler>
libzeitgeist
</silinecek_paketler>
</uygulama>
