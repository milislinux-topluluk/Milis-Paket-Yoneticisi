<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libzeitgeist
</isim>
<tanim>
C ve Vala'dan Zeitgeist olay günlüğüne erişmek ve yönetmek için kullanılan istemci kitaplığı.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libzeitgeist.png
</ekran_resmi>
<kurulacak_paketler>
libzeitgeist
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.3.18
</surum>
<silinecek_paketler>
libzeitgeist
</silinecek_paketler>
</uygulama>
