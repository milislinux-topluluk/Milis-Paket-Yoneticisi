<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
nbd
</isim>
<tanim>
Blok cihazlarının NBD protokolüyle paylaşma ve kullanma
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nbd.png
</ekran_resmi>
<kurulacak_paketler>
nbd
</kurulacak_paketler>
<paketci>
</paketci>
<surum>
3.15.2
</surum>
<silinecek_paketler>
nbd
</silinecek_paketler>
</uygulama>
