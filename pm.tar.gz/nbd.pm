<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
nbd
</isim>
<tanim>
Blok cihazlarının NBD protokolüyle paylaşma ve kullanma
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/nbd.png
</ekran_resmi>
<kurulacak_paketler>
nbd
</kurulacak_paketler>
<paketci>
</paketci>
<surum>
3.15.2
</surum>
<silinecek_paketler>
nbd
</silinecek_paketler>
</uygulama>
