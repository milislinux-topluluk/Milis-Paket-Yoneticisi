<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
socat
</isim>
<tanim>
SOcket CAT - netcat benzeri ek özellikli araç
</tanim>
<ekran_resmi>
file:///tmp/socat.png
</ekran_resmi>
<kurulacak_paketler>
socat
</kurulacak_paketler>
<silinecek_paketler>
socat
</silinecek_paketler>
</uygulama>
