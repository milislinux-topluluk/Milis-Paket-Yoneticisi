<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
socat
</isim>
<tanim>
SOcket CAT - netcat benzeri ek özellikli araç
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/socat.png
</ekran_resmi>
<kurulacak_paketler>
socat
</kurulacak_paketler>
<silinecek_paketler>
socat
</silinecek_paketler>
</uygulama>
