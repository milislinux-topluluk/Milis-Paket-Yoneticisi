<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mousepad
</isim>
<tanim>
Mousepad, Xfce masaüstü ortamı için basit bir GTK+2 metin editörüdür.
</tanim>
<ekran_resmi>
file:///tmp/mousepad.png
</ekran_resmi>
<kurulacak_paketler>
mousepad
</kurulacak_paketler>
<silinecek_paketler>
mousepad
</silinecek_paketler>
</uygulama>
