<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dmidecode
</isim>
<tanim>
Sistemin SMBIOS / DMI standardına göre BIOS'unuzun donanım bilgisidir.
</tanim>
<ekran_resmi>
file:///tmp/dmidecode.png
</ekran_resmi>
<kurulacak_paketler>
dmidecode
</kurulacak_paketler>
<silinecek_paketler>
dmidecode
</silinecek_paketler>
</uygulama>
