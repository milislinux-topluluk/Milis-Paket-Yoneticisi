<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dmidecode
</isim>
<tanim>
Sistemin SMBIOS / DMI standardına göre BIOS'unuzun donanım bilgisidir.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/dmidecode.png
</ekran_resmi>
<kurulacak_paketler>
dmidecode
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.1
</surum>
<silinecek_paketler>
dmidecode
</silinecek_paketler>
</uygulama>
