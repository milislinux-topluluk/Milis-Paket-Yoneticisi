<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
0d1n
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/0d1n.png
</ekran_resmi>
<kurulacak_paketler>
0d1n
</kurulacak_paketler>
<paketci>
kadanur
</paketci>
<surum>
2.3
</surum>
<silinecek_paketler>
0d1n
</silinecek_paketler>
</uygulama>
