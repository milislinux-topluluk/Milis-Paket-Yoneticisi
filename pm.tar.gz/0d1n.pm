<?xml version="1.0"?>
<uygulama>
<grup>
Güvenlik
</grup>
<isim>
0d1n
</isim>
<tanim>
HTTP girdilerinde kod hata araştırmaları yapmak için web güvenliği aracı.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/0d1n.png
</ekran_resmi>
<kurulacak_paketler>
0d1n
</kurulacak_paketler>
<paketci>
kadanur
</paketci>
<surum>
2.3
</surum>
<silinecek_paketler>
0d1n
</silinecek_paketler>
</uygulama>
