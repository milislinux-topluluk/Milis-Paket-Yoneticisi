<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sshfs-fuse
</isim>
<tanim>
FUSE client based on the SSH File Transfer Protocol
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sshfs-fuse.png
</ekran_resmi>
<kurulacak_paketler>
sshfs-fuse
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<silinecek_paketler>
sshfs-fuse
</silinecek_paketler>
</uygulama>
