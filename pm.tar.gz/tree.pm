<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
tree
</isim>
<tanim>
Dizin ağacını göster
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/tree.png
</ekran_resmi>
<kurulacak_paketler>
tree
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
tree
</silinecek_paketler>
</uygulama>
