<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
tree
</isim>
<tanim>
Dizin ağacını göster
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/tree.png
</ekran_resmi>
<kurulacak_paketler>
tree
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.7.0
</surum>
<silinecek_paketler>
tree
</silinecek_paketler>
</uygulama>
