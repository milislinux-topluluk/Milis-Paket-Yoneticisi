<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
docbook-xsl
</isim>
<tanim>
XML stylesheets for Docbook-xml transformations
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/docbook-xsl.png
</ekran_resmi>
<kurulacak_paketler>
docbook-xsl
</kurulacak_paketler>
<silinecek_paketler>
docbook-xsl
</silinecek_paketler>
</uygulama>
