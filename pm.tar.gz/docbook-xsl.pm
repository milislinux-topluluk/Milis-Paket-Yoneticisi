<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
docbook-xsl
</isim>
<tanim>
XML stylesheets for Docbook-xml transformations
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/docbook-xsl.png
</ekran_resmi>
<kurulacak_paketler>
docbook-xsl
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.79.1
</surum>
<silinecek_paketler>
docbook-xsl
</silinecek_paketler>
</uygulama>
