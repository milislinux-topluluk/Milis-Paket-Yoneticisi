<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
virtualgl
</isim>
<tanim>
opengl kullanan bir uygulamadan opengl ekran kartına 3d komut iletir
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/virtualgl.png
</ekran_resmi>
<kurulacak_paketler>
virtualgl
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.5.2
</surum>
<silinecek_paketler>
virtualgl
</silinecek_paketler>
</uygulama>
