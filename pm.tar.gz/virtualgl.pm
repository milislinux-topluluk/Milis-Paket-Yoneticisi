<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
virtualgl
</isim>
<tanim>
opengl kullanan bir uygulamadan opengl ekran kartına 3d komut iletir
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/virtualgl.png
</ekran_resmi>
<kurulacak_paketler>
virtualgl
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
virtualgl
</silinecek_paketler>
</uygulama>
