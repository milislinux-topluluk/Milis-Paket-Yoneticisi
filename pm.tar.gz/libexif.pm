<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libexif
</isim>
<tanim>
A library to parse an EXIF file and read the data from those tags
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libexif.png
</ekran_resmi>
<kurulacak_paketler>
libexif
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
libexif
</silinecek_paketler>
</uygulama>
