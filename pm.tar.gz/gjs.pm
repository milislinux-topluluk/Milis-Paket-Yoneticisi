<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gjs
</isim>
<tanim>
GNOME için Javascript Bağları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gjs.png
</ekran_resmi>
<kurulacak_paketler>
gjs
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.44.0
</surum>
<silinecek_paketler>
gjs
</silinecek_paketler>
</uygulama>
