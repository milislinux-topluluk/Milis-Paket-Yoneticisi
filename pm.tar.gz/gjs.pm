<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gjs
</isim>
<tanim>
GNOME için Javascript Bağları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gjs.png
</ekran_resmi>
<kurulacak_paketler>
gjs
</kurulacak_paketler>
<silinecek_paketler>
gjs
</silinecek_paketler>
</uygulama>
