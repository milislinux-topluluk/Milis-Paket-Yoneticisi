<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libarchive
</isim>
<tanim>
farklı arşiv tiplerini uygulayan kütüphane
</tanim>
<ekran_resmi>
file:///tmp/libarchive.png
</ekran_resmi>
<kurulacak_paketler>
libarchive
</kurulacak_paketler>
<silinecek_paketler>
libarchive
</silinecek_paketler>
</uygulama>
