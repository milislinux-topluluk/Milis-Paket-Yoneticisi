<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libarchive
</isim>
<tanim>
farklı arşiv tiplerini uygulayan kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libarchive.png
</ekran_resmi>
<kurulacak_paketler>
libarchive
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.3.2
</surum>
<silinecek_paketler>
libarchive
</silinecek_paketler>
</uygulama>
