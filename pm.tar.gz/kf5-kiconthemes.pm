<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kiconthemes
</isim>
<tanim>
Simge temaları için destek
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kiconthemes.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kiconthemes
</kurulacak_paketler>
<silinecek_paketler>
kf5-kiconthemes
</silinecek_paketler>
</uygulama>
