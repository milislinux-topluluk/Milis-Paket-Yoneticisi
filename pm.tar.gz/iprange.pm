<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iprange
</isim>
<tanim>
ip aralıklarını yönetme aracı- firehol projesinden
</tanim>
<ekran_resmi>
file:///tmp/iprange.png
</ekran_resmi>
<kurulacak_paketler>
iprange
</kurulacak_paketler>
<silinecek_paketler>
iprange
</silinecek_paketler>
</uygulama>
