<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iprange
</isim>
<tanim>
ip aralıklarını yönetme aracı- firehol projesinden
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/iprange.png
</ekran_resmi>
<kurulacak_paketler>
iprange
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.0
</surum>
<silinecek_paketler>
iprange
</silinecek_paketler>
</uygulama>
