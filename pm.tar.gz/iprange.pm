<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
iprange
</isim>
<tanim>
ip aralıklarını yönetme aracı- firehol projesinden
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/iprange.png
</ekran_resmi>
<kurulacak_paketler>
iprange
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.0.3
</surum>
<silinecek_paketler>
iprange
</silinecek_paketler>
</uygulama>
