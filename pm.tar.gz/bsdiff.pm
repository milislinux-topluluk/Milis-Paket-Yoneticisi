<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
bsdiff
</isim>
<tanim>
bsdiff,bspatch ikili dosyalar için fark ve yama uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/bsdiff.png
</ekran_resmi>
<kurulacak_paketler>
bsdiff
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.3
</surum>
<silinecek_paketler>
bsdiff
</silinecek_paketler>
</uygulama>
