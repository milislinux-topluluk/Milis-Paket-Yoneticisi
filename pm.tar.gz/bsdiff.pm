<?xml version="1.0"?>
<uygulama>
<grup>
sistem
</grup>
<isim>
bsdiff
</isim>
<tanim>
bsdiff,bspatch ikili dosyalar için fark ve yama uygulaması
</tanim>
<ekran_resmi>
file:///tmp/bsdiff.png
</ekran_resmi>
<kurulacak_paketler>
bsdiff
</kurulacak_paketler>
<silinecek_paketler>
bsdiff
</silinecek_paketler>
</uygulama>
