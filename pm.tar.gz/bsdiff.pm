<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
bsdiff
</isim>
<tanim>
bsdiff,bspatch ikili dosyalar için fark ve yama uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bsdiff.png
</ekran_resmi>
<kurulacak_paketler>
bsdiff
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.3
</surum>
<silinecek_paketler>
bsdiff
</silinecek_paketler>
</uygulama>
