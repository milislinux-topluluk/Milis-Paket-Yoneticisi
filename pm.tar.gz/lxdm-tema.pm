<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxdm-tema
</isim>
<tanim>
milislinux lxdm teması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lxdm-tema.png
</ekran_resmi>
<kurulacak_paketler>
lxdm-tema
</kurulacak_paketler>
<paketci>
milisarge yasarciv
</paketci>
<surum>
1.0
</surum>
<silinecek_paketler>
lxdm-tema
</silinecek_paketler>
</uygulama>
