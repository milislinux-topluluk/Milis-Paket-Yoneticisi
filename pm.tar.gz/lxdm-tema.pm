<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxdm-tema
</isim>
<tanim>
milislinux lxdm teması
</tanim>
<ekran_resmi>
file:///tmp/lxdm-tema.png
</ekran_resmi>
<kurulacak_paketler>
lxdm-tema
</kurulacak_paketler>
<silinecek_paketler>
lxdm-tema
</silinecek_paketler>
</uygulama>
