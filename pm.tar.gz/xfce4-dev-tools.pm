<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-dev-tools
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-dev-tools.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-dev-tools
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.12.0
</surum>
<silinecek_paketler>
xfce4-dev-tools
</silinecek_paketler>
</uygulama>
