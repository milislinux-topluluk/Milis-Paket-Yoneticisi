<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
xreader
</isim>
<tanim>
PDF ve Postscript gibi dosyalar için belge görüntüleyici. X-Apps Projesi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xreader.png
</ekran_resmi>
<kurulacak_paketler>
xreader
</kurulacak_paketler>
<paketci>
milisarge yasarciv
</paketci>
<surum>
1.6.1
</surum>
<silinecek_paketler>
xreader
</silinecek_paketler>
</uygulama>
