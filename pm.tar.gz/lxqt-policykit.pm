<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxqt-policykit
</isim>
<tanim>
LXQt politika kimliği doğrulama aracısı
</tanim>
<ekran_resmi>
file:///tmp/lxqt-policykit.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-policykit
</kurulacak_paketler>
<silinecek_paketler>
lxqt-policykit
</silinecek_paketler>
</uygulama>
