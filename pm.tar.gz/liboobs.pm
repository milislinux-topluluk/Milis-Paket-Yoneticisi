<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
liboobs
</isim>
<tanim>
Sistem-araçları backend'lerine GObject tabanlı arayüz - paylaşılan kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/liboobs.png
</ekran_resmi>
<kurulacak_paketler>
liboobs
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.0.0
</surum>
<silinecek_paketler>
liboobs
</silinecek_paketler>
</uygulama>
