<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
liboobs
</isim>
<tanim>
Sistem-araçları backend'lerine GObject tabanlı arayüz - paylaşılan kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/liboobs.png
</ekran_resmi>
<kurulacak_paketler>
liboobs
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
liboobs
</silinecek_paketler>
</uygulama>
