<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
junit
</isim>
<tanim>
The JUnit package contains a simple, open source framework to write and run repeatable tests. It is an instance of the xUnit architecture for unit testing frameworks. JUnit features include assertions for testing expected results, test fixtures for sharing common test data, and test runners for running tests.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/junit.png
</ekran_resmi>
<kurulacak_paketler>
junit
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
4.12
</surum>
<silinecek_paketler>
junit
</silinecek_paketler>
</uygulama>
