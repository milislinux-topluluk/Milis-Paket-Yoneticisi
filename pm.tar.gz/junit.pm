<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
junit
</isim>
<tanim>
JUnit paketi, tekrarlanabilir testler yazmak ve çalıştırmak için basit, açık kaynaklı bir çerçeve içerir. Birim sınama çerçeveleri için xUnit mimarisinin bir örneğidir. JUnit özellikleri beklenen sonuçları test etmek için iddialar, ortak test verilerini paylaşmak için test fikstürleri ve testler çalıştırmak için test koşucuları içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/junit.png
</ekran_resmi>
<kurulacak_paketler>
junit
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
junit
</silinecek_paketler>
</uygulama>
