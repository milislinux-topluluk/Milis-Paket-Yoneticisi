<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kf5-kpackage
</isim>
<tanim>
Uygulamaların, ikili olmayan öğelerin kullanıcı tarafından kurulabilir paketlerini yönetmesine olanak sağlayan çerçeve
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kpackage.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kpackage
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kpackage
</silinecek_paketler>
</uygulama>
