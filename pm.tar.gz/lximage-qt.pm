<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lximage-qt
</isim>
<tanim>
Lximage-qt paketi, hafif bir resim görüntüleyici ve ekran görüntüsü programı içerir.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lximage-qt.png
</ekran_resmi>
<kurulacak_paketler>
lximage-qt
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.5.1
</surum>
<silinecek_paketler>
lximage-qt
</silinecek_paketler>
</uygulama>
