<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lximage-qt
</isim>
<tanim>
Lximage-qt paketi, hafif bir resim görüntüleyici ve ekran görüntüsü programı içerir.
</tanim>
<ekran_resmi>
file:///tmp/lximage-qt.png
</ekran_resmi>
<kurulacak_paketler>
lximage-qt
</kurulacak_paketler>
<silinecek_paketler>
lximage-qt
</silinecek_paketler>
</uygulama>
