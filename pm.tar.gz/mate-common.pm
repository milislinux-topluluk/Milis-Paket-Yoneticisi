<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-common
</isim>
<tanim>
MATE için yaygın geliştirme makroları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mate-common.png
</ekran_resmi>
<kurulacak_paketler>
mate-common
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mate-common
</silinecek_paketler>
</uygulama>
