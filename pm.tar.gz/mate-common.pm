<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-common
</isim>
<tanim>
MATE için yaygın geliştirme makroları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-common.png
</ekran_resmi>
<kurulacak_paketler>
mate-common
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
mate-common
</silinecek_paketler>
</uygulama>
