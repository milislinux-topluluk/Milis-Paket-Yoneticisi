<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-desktop
</isim>
<tanim>
Çeşitli MATE modülleri için ortak API'li kitaplık
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-desktop.png
</ekran_resmi>
<kurulacak_paketler>
mate-desktop
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
mate-desktop
</silinecek_paketler>
</uygulama>
