<?xml version="1.0"?>
<uygulama>
<grup>
sistem
</grup>
<isim>
zsh
</isim>
<tanim>
UNIX için programlanabilir zsh komut arayüzü
</tanim>
<ekran_resmi>
file:///tmp/zsh.png
</ekran_resmi>
<kurulacak_paketler>
zsh
</kurulacak_paketler>
<silinecek_paketler>
zsh
</silinecek_paketler>
</uygulama>
