<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
zsh
</isim>
<tanim>
UNIX için programlanabilir zsh komut arayüzü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/zsh.png
</ekran_resmi>
<kurulacak_paketler>
zsh
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.4.2
</surum>
<silinecek_paketler>
zsh
</silinecek_paketler>
</uygulama>
