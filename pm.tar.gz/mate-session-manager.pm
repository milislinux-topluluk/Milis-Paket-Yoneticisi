<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-session-manager
</isim>
<tanim>
MATE oturum yönetici ve yapılandırma programı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-session-manager.png
</ekran_resmi>
<kurulacak_paketler>
mate-session-manager
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
mate-session-manager
</silinecek_paketler>
</uygulama>
