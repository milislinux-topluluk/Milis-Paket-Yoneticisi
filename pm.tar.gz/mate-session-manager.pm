<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-session-manager
</isim>
<tanim>
MATE oturum yönetici ve yapılandırma programı
</tanim>
<ekran_resmi>
file:///tmp/mate-session-manager.png
</ekran_resmi>
<kurulacak_paketler>
mate-session-manager
</kurulacak_paketler>
<silinecek_paketler>
mate-session-manager
</silinecek_paketler>
</uygulama>
