<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-session-manager
</isim>
<tanim>
MATE oturum yönetici ve yapılandırma programı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mate-session-manager.png
</ekran_resmi>
<kurulacak_paketler>
mate-session-manager
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mate-session-manager
</silinecek_paketler>
</uygulama>
