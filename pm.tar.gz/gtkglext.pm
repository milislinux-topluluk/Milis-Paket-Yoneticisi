<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gtkglext
</isim>
<tanim>
Gtk2 için opengl uzantıları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gtkglext.png
</ekran_resmi>
<kurulacak_paketler>
gtkglext
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1.2.0
</surum>
<silinecek_paketler>
gtkglext
</silinecek_paketler>
</uygulama>
