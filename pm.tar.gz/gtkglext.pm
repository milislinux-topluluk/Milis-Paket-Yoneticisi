<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtkglext
</isim>
<tanim>
Gtk2 için opengl uzantıları
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gtkglext.png
</ekran_resmi>
<kurulacak_paketler>
gtkglext
</kurulacak_paketler>
<silinecek_paketler>
gtkglext
</silinecek_paketler>
</uygulama>
