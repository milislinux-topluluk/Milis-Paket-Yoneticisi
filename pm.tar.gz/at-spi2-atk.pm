<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
at-spi2-atk
</isim>
<tanim>
A GTK+ module that bridges ATK to D-Bus at-spi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/at-spi2-atk.png
</ekran_resmi>
<kurulacak_paketler>
at-spi2-atk
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
at-spi2-atk
</silinecek_paketler>
</uygulama>
