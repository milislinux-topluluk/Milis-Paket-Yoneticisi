<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libmatekbd
</isim>
<tanim>
MATE klavye kitaplığı
</tanim>
<ekran_resmi>
file:///tmp/libmatekbd.png
</ekran_resmi>
<kurulacak_paketler>
libmatekbd
</kurulacak_paketler>
<silinecek_paketler>
libmatekbd
</silinecek_paketler>
</uygulama>
