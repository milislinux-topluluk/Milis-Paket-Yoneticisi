<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libmatekbd
</isim>
<tanim>
MATE klavye kitaplığı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libmatekbd.png
</ekran_resmi>
<kurulacak_paketler>
libmatekbd
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.2
</surum>
<silinecek_paketler>
libmatekbd
</silinecek_paketler>
</uygulama>
