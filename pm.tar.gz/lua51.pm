<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lua51
</isim>
<tanim>
A programming language designed for extending applications (version 5.1)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lua51.png
</ekran_resmi>
<kurulacak_paketler>
lua51
</kurulacak_paketler>
<paketci>
# NuTyX package info file (http
</paketci>
<silinecek_paketler>
lua51
</silinecek_paketler>
</uygulama>
