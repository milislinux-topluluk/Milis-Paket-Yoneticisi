<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lua51
</isim>
<tanim>
A programming language designed for extending applications (version 5.1)
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lua51.png
</ekran_resmi>
<kurulacak_paketler>
lua51
</kurulacak_paketler>
<paketci>
# NuTyX package info file (http
</paketci>
<surum>
5.1.5
</surum>
<silinecek_paketler>
lua51
</silinecek_paketler>
</uygulama>
