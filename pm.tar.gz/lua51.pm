<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lua51
</isim>
<tanim>
A programming language designed for extending applications (version 5.1)
</tanim>
<ekran_resmi>
file:///tmp/lua51.png
</ekran_resmi>
<kurulacak_paketler>
lua51
</kurulacak_paketler>
<silinecek_paketler>
lua51
</silinecek_paketler>
</uygulama>
