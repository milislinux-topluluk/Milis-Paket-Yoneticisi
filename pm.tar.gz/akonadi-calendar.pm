<?xml version="1.0"?>
<uygulama>
<grup>
Sistem
</grup>
<isim>
akonadi-calendar
</isim>
<tanim>
Akonadi takvim eklentisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/akonadi-calendar.png
</ekran_resmi>
<kurulacak_paketler>
akonadi-calendar
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
akonadi-calendar
</silinecek_paketler>
</uygulama>
