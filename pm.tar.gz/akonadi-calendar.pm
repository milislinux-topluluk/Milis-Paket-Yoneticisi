<?xml version="1.0"?>
<uygulama>
<grup>
sistem
</grup>
<isim>
akonadi-calendar
</isim>
<tanim>
Akonadi takvim eklentisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/akonadi-calendar.png
</ekran_resmi>
<kurulacak_paketler>
akonadi-calendar
</kurulacak_paketler>
<silinecek_paketler>
akonadi-calendar
</silinecek_paketler>
</uygulama>
