<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iptables
</isim>
<tanim>
A Linux kernel packet filter control tool
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/iptables.png
</ekran_resmi>
<kurulacak_paketler>
iptables
</kurulacak_paketler>
<silinecek_paketler>
iptables
</silinecek_paketler>
</uygulama>
