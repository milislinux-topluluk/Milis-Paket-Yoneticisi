<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
filezilla
</isim>
<tanim>
Fast and reliable FTP, FTPS and SFTP client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/filezilla.png
</ekran_resmi>
<kurulacak_paketler>
filezilla
</kurulacak_paketler>
<silinecek_paketler>
filezilla
</silinecek_paketler>
</uygulama>
