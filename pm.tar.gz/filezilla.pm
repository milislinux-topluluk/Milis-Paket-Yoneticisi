<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
filezilla
</isim>
<tanim>
Hızlı ve güvenilir FTP, FTPS ve SFTP istemcisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/filezilla.png
</ekran_resmi>
<kurulacak_paketler>
filezilla
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.12.0.2
</surum>
<silinecek_paketler>
filezilla
</silinecek_paketler>
</uygulama>
