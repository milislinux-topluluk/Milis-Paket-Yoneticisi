<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
pluma
</isim>
<tanim>
MATE için güçlü bir metin editörü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pluma.png
</ekran_resmi>
<kurulacak_paketler>
pluma
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.2
</surum>
<silinecek_paketler>
pluma
</silinecek_paketler>
</uygulama>
