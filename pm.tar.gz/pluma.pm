<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
pluma
</isim>
<tanim>
MATE için güçlü bir metin editörü
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/pluma.png
</ekran_resmi>
<kurulacak_paketler>
pluma
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.2
</surum>
<silinecek_paketler>
pluma
</silinecek_paketler>
</uygulama>
