<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
gsettings-qt
</isim>
<tanim>
GSettings için Qml bağları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gsettings-qt.png
</ekran_resmi>
<kurulacak_paketler>
gsettings-qt
</kurulacak_paketler>
<paketci>
Cihan_Alkan
</paketci>
<surum>
0.1.20170824
</surum>
<silinecek_paketler>
gsettings-qt
</silinecek_paketler>
</uygulama>
