<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
jansson
</isim>
<tanim>
JSON verisini encode, decode etmek ve düzenlemek için C kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/jansson.png
</ekran_resmi>
<kurulacak_paketler>
jansson
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.7
</surum>
<silinecek_paketler>
jansson
</silinecek_paketler>
</uygulama>
