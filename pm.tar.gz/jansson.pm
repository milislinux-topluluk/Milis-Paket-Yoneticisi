<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jansson
</isim>
<tanim>
JSON verisini encode, decode etmek ve düzenlemek için C kütüphanesi
</tanim>
<ekran_resmi>
file:///tmp/jansson.png
</ekran_resmi>
<kurulacak_paketler>
jansson
</kurulacak_paketler>
<silinecek_paketler>
jansson
</silinecek_paketler>
</uygulama>
