<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libixion
</isim>
<tanim>
Genel amaçlı formül çözümleyici ve yorumlayıcı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libixion.png
</ekran_resmi>
<kurulacak_paketler>
libixion
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.12.2
</surum>
<silinecek_paketler>
libixion
</silinecek_paketler>
</uygulama>
