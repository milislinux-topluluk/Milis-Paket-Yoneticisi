<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libixion
</isim>
<tanim>
Genel amaçlı formül çözümleyici ve yorumlayıcı
</tanim>
<ekran_resmi>
file:///tmp/libixion.png
</ekran_resmi>
<kurulacak_paketler>
libixion
</kurulacak_paketler>
<silinecek_paketler>
libixion
</silinecek_paketler>
</uygulama>
