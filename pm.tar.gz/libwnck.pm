<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libwnck
</isim>
<tanim>
contains a kit of contruction of navigator of windows
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libwnck.png
</ekran_resmi>
<kurulacak_paketler>
libwnck
</kurulacak_paketler>
<silinecek_paketler>
libwnck
</silinecek_paketler>
</uygulama>
