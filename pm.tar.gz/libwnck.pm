<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libwnck
</isim>
<tanim>
contains a kit of contruction of navigator of windows
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libwnck.png
</ekran_resmi>
<kurulacak_paketler>
libwnck
</kurulacak_paketler>
<paketci>
tyrry at nutyx dot org, tnut at nutyx dot org
</paketci>
<surum>
2.31.0
</surum>
<silinecek_paketler>
libwnck
</silinecek_paketler>
</uygulama>
