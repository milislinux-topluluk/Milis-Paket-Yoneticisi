<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libwnck
</isim>
<tanim>
contains a kit of contruction of navigator of windows
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libwnck.png
</ekran_resmi>
<kurulacak_paketler>
libwnck
</kurulacak_paketler>
<paketci>
tyrry at nutyx dot org, tnut at nutyx dot org
</paketci>
<surum>
2.31.0
</surum>
<silinecek_paketler>
libwnck
</silinecek_paketler>
</uygulama>
