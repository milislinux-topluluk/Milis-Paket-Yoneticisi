<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libart_lgpl
</isim>
<tanim>
Yüksek performanslı 2D grafikler için bir kütüphane.
</tanim>
<ekran_resmi>
file:///tmp/libart_lgpl.png
</ekran_resmi>
<kurulacak_paketler>
libart_lgpl
</kurulacak_paketler>
<silinecek_paketler>
libart_lgpl
</silinecek_paketler>
</uygulama>
