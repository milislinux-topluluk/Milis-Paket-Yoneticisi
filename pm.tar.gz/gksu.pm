<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gksu
</isim>
<tanim>
Su için bir grafik ön uç
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gksu.png
</ekran_resmi>
<kurulacak_paketler>
gksu
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
2.0.2
</surum>
<silinecek_paketler>
gksu
</silinecek_paketler>
</uygulama>
