<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gksu
</isim>
<tanim>
Su için bir grafik ön uç
</tanim>
<ekran_resmi>
file:///tmp/gksu.png
</ekran_resmi>
<kurulacak_paketler>
gksu
</kurulacak_paketler>
<silinecek_paketler>
gksu
</silinecek_paketler>
</uygulama>
