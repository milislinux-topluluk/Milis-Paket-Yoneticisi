<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gksu
</isim>
<tanim>
Su için bir grafik ön uç
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gksu.png
</ekran_resmi>
<kurulacak_paketler>
gksu
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
2.0.2
</surum>
<silinecek_paketler>
gksu
</silinecek_paketler>
</uygulama>
