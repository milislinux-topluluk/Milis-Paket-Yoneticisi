<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libetonyek
</isim>
<tanim>
Apple Keynote sunumlarını okumak ve dönüştürmek için kullanılan kütüphane ve araçlar
</tanim>
<ekran_resmi>
file:///tmp/libetonyek.png
</ekran_resmi>
<kurulacak_paketler>
libetonyek
</kurulacak_paketler>
<silinecek_paketler>
libetonyek
</silinecek_paketler>
</uygulama>
