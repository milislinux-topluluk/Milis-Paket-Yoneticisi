<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libetonyek
</isim>
<tanim>
Apple Keynote sunumlarını okumak ve dönüştürmek için kullanılan kütüphane ve araçlar
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libetonyek.png
</ekran_resmi>
<kurulacak_paketler>
libetonyek
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.1.6
</surum>
<silinecek_paketler>
libetonyek
</silinecek_paketler>
</uygulama>
