<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lsb-release
</isim>
<tanim>
Dağıtımın (Linux Standards Base) bilgisi verir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lsb-release.png
</ekran_resmi>
<kurulacak_paketler>
lsb-release
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.4
</surum>
<silinecek_paketler>
lsb-release
</silinecek_paketler>
</uygulama>
