<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
fribidi
</isim>
<tanim>
A Free Implementation of the Unicode Bidirectional Algorithm
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/fribidi.png
</ekran_resmi>
<kurulacak_paketler>
fribidi
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.19.7
</surum>
<silinecek_paketler>
fribidi
</silinecek_paketler>
</uygulama>
