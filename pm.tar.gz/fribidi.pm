<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fribidi
</isim>
<tanim>
A Free Implementation of the Unicode Bidirectional Algorithm
</tanim>
<ekran_resmi>
file:///tmp/fribidi.png
</ekran_resmi>
<kurulacak_paketler>
fribidi
</kurulacak_paketler>
<silinecek_paketler>
fribidi
</silinecek_paketler>
</uygulama>
