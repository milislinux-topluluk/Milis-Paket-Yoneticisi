<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fribidi
</isim>
<tanim>
A Free Implementation of the Unicode Bidirectional Algorithm
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fribidi.png
</ekran_resmi>
<kurulacak_paketler>
fribidi
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.19.7
</surum>
<silinecek_paketler>
fribidi
</silinecek_paketler>
</uygulama>
