<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
udevil
</isim>
<tanim>
Çıkarılabilir aygıtları,ISO dosyalarını,nfs
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/udevil.png
</ekran_resmi>
<kurulacak_paketler>
udevil
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.4.4
</surum>
<silinecek_paketler>
udevil
</silinecek_paketler>
</uygulama>
