<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
udevil
</isim>
<tanim>
Çıkarılabilir aygıtları,ISO dosyalarını,nfs
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/udevil.png
</ekran_resmi>
<kurulacak_paketler>
udevil
</kurulacak_paketler>
<silinecek_paketler>
udevil
</silinecek_paketler>
</uygulama>
