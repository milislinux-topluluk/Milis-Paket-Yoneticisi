<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libmp4v2
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libmp4v2.png
</ekran_resmi>
<kurulacak_paketler>
libmp4v2
</kurulacak_paketler>
<silinecek_paketler>
libmp4v2
</silinecek_paketler>
</uygulama>
