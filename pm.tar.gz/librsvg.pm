<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
librsvg
</isim>
<tanim>
Library and tools used to manipulate, convert and view Scalable Vector Graphic images.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/librsvg.png
</ekran_resmi>
<kurulacak_paketler>
librsvg
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.40.13
</surum>
<silinecek_paketler>
librsvg
</silinecek_paketler>
</uygulama>
