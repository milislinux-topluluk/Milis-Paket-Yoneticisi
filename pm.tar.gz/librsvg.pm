<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
librsvg
</isim>
<tanim>
Library and tools used to manipulate, convert and view Scalable Vector Graphic images.
</tanim>
<ekran_resmi>
file:///tmp/librsvg.png
</ekran_resmi>
<kurulacak_paketler>
librsvg
</kurulacak_paketler>
<silinecek_paketler>
librsvg
</silinecek_paketler>
</uygulama>
