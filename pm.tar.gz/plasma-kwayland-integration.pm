<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-kwayland-integration
</isim>
<tanim>
Provides integration plugins for various KDE frameworks for the wayland windowing system
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-kwayland-integration.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kwayland-integration
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-kwayland-integration
</silinecek_paketler>
</uygulama>
