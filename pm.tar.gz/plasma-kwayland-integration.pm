<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-kwayland-integration
</isim>
<tanim>
Wayland pencere sistemine çeşitli KDE çerçeveleri için entegrasyon eklentileri sağlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-kwayland-integration.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kwayland-integration
</kurulacak_paketler>
<silinecek_paketler>
plasma-kwayland-integration
</silinecek_paketler>
</uygulama>
