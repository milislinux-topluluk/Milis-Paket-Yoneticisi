<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
jbigkit
</isim>
<tanim>
JBIG1 sıkıştırma standardı uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/jbigkit.png
</ekran_resmi>
<kurulacak_paketler>
jbigkit
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
jbigkit
</silinecek_paketler>
</uygulama>
