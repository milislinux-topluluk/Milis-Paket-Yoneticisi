<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
jbigkit
</isim>
<tanim>
JBIG1 sıkıştırma standardı uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/jbigkit.png
</ekran_resmi>
<kurulacak_paketler>
jbigkit
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.1
</surum>
<silinecek_paketler>
jbigkit
</silinecek_paketler>
</uygulama>
