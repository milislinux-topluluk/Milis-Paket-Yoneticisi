<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libndp
</isim>
<tanim>
The libndp package provides a wrapper for IPv6 Neighbor Discovery Protocol.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libndp.png
</ekran_resmi>
<kurulacak_paketler>
libndp
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
1.5
</surum>
<silinecek_paketler>
libndp
</silinecek_paketler>
</uygulama>
