<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libndp
</isim>
<tanim>
The libndp package provides a wrapper for IPv6 Neighbor Discovery Protocol.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libndp.png
</ekran_resmi>
<kurulacak_paketler>
libndp
</kurulacak_paketler>
<silinecek_paketler>
libndp
</silinecek_paketler>
</uygulama>
