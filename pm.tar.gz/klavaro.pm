<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
klavaro
</isim>
<tanim>
Hızlı klavye yazma uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/klavaro.png
</ekran_resmi>
<kurulacak_paketler>
klavaro
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
klavaro
</silinecek_paketler>
</uygulama>
