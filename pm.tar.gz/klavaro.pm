<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
klavaro
</isim>
<tanim>
Hızlı klavye yazma uygulaması
</tanim>
<ekran_resmi>
file:///tmp/klavaro.png
</ekran_resmi>
<kurulacak_paketler>
klavaro
</kurulacak_paketler>
<silinecek_paketler>
klavaro
</silinecek_paketler>
</uygulama>
