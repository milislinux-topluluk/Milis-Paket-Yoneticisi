<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
klavaro
</isim>
<tanim>
Hızlı klavye yazma uygulaması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/klavaro.png
</ekran_resmi>
<kurulacak_paketler>
klavaro
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
3.03
</surum>
<silinecek_paketler>
klavaro
</silinecek_paketler>
</uygulama>
