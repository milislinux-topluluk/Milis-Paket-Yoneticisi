<?xml version="1.0"?>
<uygulama>
<grup>
ağ
</grup>
<isim>
bitchx
</isim>
<tanim>
BitchX is an IRC (Internet Relay Chat) client.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bitchx.png
</ekran_resmi>
<kurulacak_paketler>
bitchx
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
bitchx
</silinecek_paketler>
</uygulama>
