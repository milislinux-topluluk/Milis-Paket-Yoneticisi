<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
oxygen-gtk3
</isim>
<tanim>
oxygen-gtk3, theme Oxygen for applications in gtk3
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/oxygen-gtk3.png
</ekran_resmi>
<kurulacak_paketler>
oxygen-gtk3
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.4.1
</surum>
<silinecek_paketler>
oxygen-gtk3
</silinecek_paketler>
</uygulama>
