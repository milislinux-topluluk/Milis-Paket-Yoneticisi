<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
oxygen-gtk3
</isim>
<tanim>
Oxygen-gtk3, gtk3 uygulamaları için Oksijen teması.
</tanim>
<ekran_resmi>
file:///tmp/oxygen-gtk3.png
</ekran_resmi>
<kurulacak_paketler>
oxygen-gtk3
</kurulacak_paketler>
<silinecek_paketler>
oxygen-gtk3
</silinecek_paketler>
</uygulama>
