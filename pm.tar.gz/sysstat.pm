<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sysstat
</isim>
<tanim>
Sistem performansını ve kullanım etkinliğini izlemek için kullanılan yardımcı programlar.
</tanim>
<ekran_resmi>
file:///tmp/sysstat.png
</ekran_resmi>
<kurulacak_paketler>
sysstat
</kurulacak_paketler>
<silinecek_paketler>
sysstat
</silinecek_paketler>
</uygulama>
