<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libwmf
</isim>
<tanim>
A library for reading vector images in Microsoft's native Windows Metafile Format (WMF)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libwmf.png
</ekran_resmi>
<kurulacak_paketler>
libwmf
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.2.8.4
</surum>
<silinecek_paketler>
libwmf
</silinecek_paketler>
</uygulama>
