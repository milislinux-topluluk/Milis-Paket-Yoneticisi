<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ilmbase
</isim>
<tanim>
Base libraries from ILM for OpenEXR
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/ilmbase.png
</ekran_resmi>
<kurulacak_paketler>
ilmbase
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.2.0
</surum>
<silinecek_paketler>
ilmbase
</silinecek_paketler>
</uygulama>
