<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ilmbase
</isim>
<tanim>
Base libraries from ILM for OpenEXR
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ilmbase.png
</ekran_resmi>
<kurulacak_paketler>
ilmbase
</kurulacak_paketler>
<silinecek_paketler>
ilmbase
</silinecek_paketler>
</uygulama>
