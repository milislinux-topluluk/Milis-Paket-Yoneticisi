<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-systemload-plugin
</isim>
<tanim>
Panel için monitör sistemi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-systemload-plugin.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-systemload-plugin
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
xfce4-systemload-plugin
</silinecek_paketler>
</uygulama>
