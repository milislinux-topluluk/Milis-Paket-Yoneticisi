<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3-psutil
</isim>
<tanim>
Python3 için çapraz platform işlem ve sistem yardımcı programları modülü.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-psutil.png
</ekran_resmi>
<kurulacak_paketler>
python3-psutil
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
python3-psutil
</silinecek_paketler>
</uygulama>
