<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gwenview
</isim>
<tanim>
KDE5 için hızlı ve basit bir resim görüntüleme aracı
</tanim>
<ekran_resmi>
file:///tmp/gwenview.png
</ekran_resmi>
<kurulacak_paketler>
gwenview
</kurulacak_paketler>
<silinecek_paketler>
gwenview
</silinecek_paketler>
</uygulama>
