<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gwenview
</isim>
<tanim>
fast and easy to use image viewer for KDE 5
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gwenview.png
</ekran_resmi>
<kurulacak_paketler>
gwenview
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
gwenview
</silinecek_paketler>
</uygulama>
