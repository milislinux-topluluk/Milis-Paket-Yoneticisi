<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gwenview
</isim>
<tanim>
KDE5 için hızlı ve basit bir resim görüntüleme aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gwenview.png
</ekran_resmi>
<kurulacak_paketler>
gwenview
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
gwenview
</silinecek_paketler>
</uygulama>
