<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
tumbler
</isim>
<tanim>
A D-Bus thumbnailing service based on the thumbnail management D-Bus specification.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/tumbler.png
</ekran_resmi>
<kurulacak_paketler>
tumbler
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.1.31
</surum>
<silinecek_paketler>
tumbler
</silinecek_paketler>
</uygulama>
