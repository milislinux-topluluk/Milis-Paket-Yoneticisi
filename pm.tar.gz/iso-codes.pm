<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
iso-codes
</isim>
<tanim>
The ISO Codes package contains a list of country, language and currency names
</tanim>
<ekran_resmi>
file:///tmp/iso-codes.png
</ekran_resmi>
<kurulacak_paketler>
iso-codes
</kurulacak_paketler>
<silinecek_paketler>
iso-codes
</silinecek_paketler>
</uygulama>
