<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
iso-codes
</isim>
<tanim>
The ISO Codes package contains a list of country, language and currency names
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/iso-codes.png
</ekran_resmi>
<kurulacak_paketler>
iso-codes
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
3.65
</surum>
<silinecek_paketler>
iso-codes
</silinecek_paketler>
</uygulama>
