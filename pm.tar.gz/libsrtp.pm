<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libsrtp
</isim>
<tanim>
Güvenli gerçek zamanlı taşıyıcı protokolü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libsrtp.png
</ekran_resmi>
<kurulacak_paketler>
libsrtp
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.5.4
</surum>
<silinecek_paketler>
libsrtp
</silinecek_paketler>
</uygulama>
