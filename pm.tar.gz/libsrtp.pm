<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libsrtp
</isim>
<tanim>
Güvenli gerçek zamanlı taşıyıcı protokolü
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libsrtp.png
</ekran_resmi>
<kurulacak_paketler>
libsrtp
</kurulacak_paketler>
<silinecek_paketler>
libsrtp
</silinecek_paketler>
</uygulama>
