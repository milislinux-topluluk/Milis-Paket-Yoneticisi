<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sysklogd
</isim>
<tanim>
For logging system messages, such as those given by the kernel.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sysklogd.png
</ekran_resmi>
<kurulacak_paketler>
sysklogd
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.5.1
</surum>
<silinecek_paketler>
sysklogd
</silinecek_paketler>
</uygulama>
