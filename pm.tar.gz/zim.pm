<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
zim
</isim>
<tanim>
Wiki kavramını masaüstüne getirmeyi amaçlayan bir WYSIWYG metin editörü.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/zim.png
</ekran_resmi>
<kurulacak_paketler>
zim
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.67
</surum>
<silinecek_paketler>
zim
</silinecek_paketler>
</uygulama>
