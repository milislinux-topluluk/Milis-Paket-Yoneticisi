<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
zim
</isim>
<tanim>
Wiki kavramını masaüstüne getirmeyi amaçlayan bir WYSIWYG metin editörü.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/zim.png
</ekran_resmi>
<kurulacak_paketler>
zim
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
zim
</silinecek_paketler>
</uygulama>
