<?xml version="1.0"?>
<uygulama>
<grup>
Kde sistem
</grup>
<isim>
calendarsupport
</isim>
<tanim>
KDE icin takvim destegi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/calendarsupport.png
</ekran_resmi>
<kurulacak_paketler>
calendarsupport
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
calendarsupport
</silinecek_paketler>
</uygulama>
