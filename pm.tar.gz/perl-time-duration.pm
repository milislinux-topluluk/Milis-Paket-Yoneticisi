<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
perl-time-duration
</isim>
<tanim>
Yuvarlak veya kesin İngilizce sürelerin ifadesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-time-duration.png
</ekran_resmi>
<kurulacak_paketler>
perl-time-duration
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.1
</surum>
<silinecek_paketler>
perl-time-duration
</silinecek_paketler>
</uygulama>
