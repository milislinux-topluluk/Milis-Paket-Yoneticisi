<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xmlto
</isim>
<tanim>
Convert xml to many other formats
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xmlto.png
</ekran_resmi>
<kurulacak_paketler>
xmlto
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
xmlto
</silinecek_paketler>
</uygulama>
