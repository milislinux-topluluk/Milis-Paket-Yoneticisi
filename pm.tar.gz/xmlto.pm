<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xmlto
</isim>
<tanim>
Convert xml to many other formats
</tanim>
<ekran_resmi>
file:///tmp/xmlto.png
</ekran_resmi>
<kurulacak_paketler>
xmlto
</kurulacak_paketler>
<silinecek_paketler>
xmlto
</silinecek_paketler>
</uygulama>
