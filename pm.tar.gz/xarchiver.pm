<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xarchiver
</isim>
<tanim>
Xarchiver, GTK + 2 araç seti ile inşa edilmiş hafif, masaüstü bağımsız bir arşiv yöneticisidir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xarchiver.png
</ekran_resmi>
<kurulacak_paketler>
xarchiver
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.5.4.11
</surum>
<silinecek_paketler>
xarchiver
</silinecek_paketler>
</uygulama>
