<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
figlet
</isim>
<tanim>
Sıradan metinden büyük harfler çıkartmak için kullanılan bir program
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/figlet.png
</ekran_resmi>
<kurulacak_paketler>
figlet
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
2.2.5
</surum>
<silinecek_paketler>
figlet
</silinecek_paketler>
</uygulama>
