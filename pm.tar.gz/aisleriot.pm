<?xml version="1.0"?>
<uygulama>
<grup>
Oyunlar
</grup>
<isim>
aisleriot
</isim>
<tanim>
Guile şemasında yazılmış sabır oyunları topluluğu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/aisleriot.png
</ekran_resmi>
<kurulacak_paketler>
aisleriot
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.2
</surum>
<silinecek_paketler>
aisleriot
</silinecek_paketler>
</uygulama>
