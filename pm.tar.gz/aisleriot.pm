<?xml version="1.0"?>
<uygulama>
<grup>
oyunlar
</grup>
<isim>
aisleriot
</isim>
<tanim>
Guile şemasında yazılmış sabır oyunları topluluğu
</tanim>
<ekran_resmi>
file:///tmp/aisleriot.png
</ekran_resmi>
<kurulacak_paketler>
aisleriot
</kurulacak_paketler>
<silinecek_paketler>
aisleriot
</silinecek_paketler>
</uygulama>
