<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xfce4-artwork
</isim>
<tanim>
Xfce4 masaüstü için arka plan resimleri
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xfce4-artwork.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-artwork
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.1.1
</surum>
<silinecek_paketler>
xfce4-artwork
</silinecek_paketler>
</uygulama>
