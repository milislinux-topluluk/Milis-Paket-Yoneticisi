<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-artwork
</isim>
<tanim>
Xfce4 masaüstü için arka plan resimleri
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-artwork.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-artwork
</kurulacak_paketler>
<silinecek_paketler>
xfce4-artwork
</silinecek_paketler>
</uygulama>
