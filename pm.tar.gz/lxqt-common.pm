<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxqt-common
</isim>
<tanim>
Lxqt-common paketi çeşitli LXQt bileşenleri için ortak dosyalar sağlar.
</tanim>
<ekran_resmi>
file:///tmp/lxqt-common.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-common
</kurulacak_paketler>
<silinecek_paketler>
lxqt-common
</silinecek_paketler>
</uygulama>
