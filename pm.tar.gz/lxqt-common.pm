<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxqt-common
</isim>
<tanim>
Lxqt-common paketi çeşitli LXQt bileşenleri için ortak dosyalar sağlar.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/lxqt-common.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-common
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.11.2
</surum>
<silinecek_paketler>
lxqt-common
</silinecek_paketler>
</uygulama>
