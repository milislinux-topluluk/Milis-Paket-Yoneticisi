<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gcr
</isim>
<tanim>
A library for bits of crypto UI and parsing
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gcr.png
</ekran_resmi>
<kurulacak_paketler>
gcr
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
gcr
</silinecek_paketler>
</uygulama>
