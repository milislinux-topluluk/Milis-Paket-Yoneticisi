<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kdepim-runtime
</isim>
<tanim>
Kişisel bilgi yönetimi ile ilgili her şeyi bir araya getirmeyi amaçlayan proje.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kdepim-runtime.png
</ekran_resmi>
<kurulacak_paketler>
kdepim-runtime
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
kdepim-runtime
</silinecek_paketler>
</uygulama>
