<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kdepim-runtime
</isim>
<tanim>
Project that aims to bring together anything to do with personal information management.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kdepim-runtime.png
</ekran_resmi>
<kurulacak_paketler>
kdepim-runtime
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kdepim-runtime
</silinecek_paketler>
</uygulama>
