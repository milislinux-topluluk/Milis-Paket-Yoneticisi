<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kdepim-runtime
</isim>
<tanim>
Kişisel bilgi yönetimi ile ilgili her şeyi bir araya getirmeyi amaçlayan proje.
</tanim>
<ekran_resmi>
file:///tmp/kdepim-runtime.png
</ekran_resmi>
<kurulacak_paketler>
kdepim-runtime
</kurulacak_paketler>
<silinecek_paketler>
kdepim-runtime
</silinecek_paketler>
</uygulama>
