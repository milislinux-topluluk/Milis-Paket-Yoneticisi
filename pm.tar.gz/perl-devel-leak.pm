<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-devel-leak
</isim>
<tanim>
Geri kazanılmayan perl nesneleri aramak için yardımcı program.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-devel-leak.png
</ekran_resmi>
<kurulacak_paketler>
perl-devel-leak
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.03
</surum>
<silinecek_paketler>
perl-devel-leak
</silinecek_paketler>
</uygulama>
