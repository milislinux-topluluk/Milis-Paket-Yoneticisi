<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-devel-leak
</isim>
<tanim>
Geri kazanılmayan perl nesneleri aramak için yardımcı program.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-devel-leak.png
</ekran_resmi>
<kurulacak_paketler>
perl-devel-leak
</kurulacak_paketler>
<silinecek_paketler>
perl-devel-leak
</silinecek_paketler>
</uygulama>
