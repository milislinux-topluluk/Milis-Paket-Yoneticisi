<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-magic
</isim>
<tanim>
Magic kütüphanesi için python bağlantısı.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-magic.png
</ekran_resmi>
<kurulacak_paketler>
python-magic
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
python-magic
</silinecek_paketler>
</uygulama>
