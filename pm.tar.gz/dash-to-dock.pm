<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dash-to-dock
</isim>
<tanim>
Çizgiyi genel görünümden kaldırarak kenarda gezdirerek hareket ettirin.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dash-to-dock.png
</ekran_resmi>
<kurulacak_paketler>
dash-to-dock
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
dash-to-dock
</silinecek_paketler>
</uygulama>
