<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
greybird-theme
</isim>
<tanim>
Gri ve mavi bir xfce teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/greybird-theme.png
</ekran_resmi>
<kurulacak_paketler>
greybird-theme
</kurulacak_paketler>
<silinecek_paketler>
greybird-theme
</silinecek_paketler>
</uygulama>
