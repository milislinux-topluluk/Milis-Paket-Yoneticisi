<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wpa-supplicant
</isim>
<tanim>
A utility providing key negotiation for WPA wireless networks
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/wpa-supplicant.png
</ekran_resmi>
<kurulacak_paketler>
wpa-supplicant
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.5
</surum>
<silinecek_paketler>
wpa-supplicant
</silinecek_paketler>
</uygulama>
