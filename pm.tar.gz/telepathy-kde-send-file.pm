<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
telepathy-kde-send-file
</isim>
<tanim>
Belirtilen bir kişiyle bir dosya aktarım işi başlatmak için Dosya yöneticisi eklentisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telepathy-kde-send-file.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-send-file
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
telepathy-kde-send-file
</silinecek_paketler>
</uygulama>
