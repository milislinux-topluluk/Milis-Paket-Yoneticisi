<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
telepathy-kde-send-file
</isim>
<tanim>
A File manager plugin to launch a file transfer job with a specified contact
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/telepathy-kde-send-file.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-send-file
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
telepathy-kde-send-file
</silinecek_paketler>
</uygulama>
