<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
geoclue2
</isim>
<tanim>
D-Bus mesajlaşma sisteminde inşa edilen modüler coğrafi bilgi hizmetleri.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/geoclue2.png
</ekran_resmi>
<kurulacak_paketler>
geoclue2
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
2.4.6
</surum>
<silinecek_paketler>
geoclue2
</silinecek_paketler>
</uygulama>
