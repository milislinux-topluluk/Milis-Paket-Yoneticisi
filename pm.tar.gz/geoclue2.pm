<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
geoclue2
</isim>
<tanim>
D-Bus mesajlaşma sisteminde inşa edilen modüler coğrafi bilgi hizmetleri.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/geoclue2.png
</ekran_resmi>
<kurulacak_paketler>
geoclue2
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
geoclue2
</silinecek_paketler>
</uygulama>
