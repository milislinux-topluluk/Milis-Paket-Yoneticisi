<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
obconf-qt
</isim>
<tanim>
OpenBox için bir GUI Qt tabanlı yapılandırma aracıdır.
</tanim>
<ekran_resmi>
file:///tmp/obconf-qt.png
</ekran_resmi>
<kurulacak_paketler>
obconf-qt
</kurulacak_paketler>
<silinecek_paketler>
obconf-qt
</silinecek_paketler>
</uygulama>
