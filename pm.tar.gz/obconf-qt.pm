<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
obconf-qt
</isim>
<tanim>
OpenBox için bir GUI Qt tabanlı yapılandırma aracıdır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/obconf-qt.png
</ekran_resmi>
<kurulacak_paketler>
obconf-qt
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.11.1
</surum>
<silinecek_paketler>
obconf-qt
</silinecek_paketler>
</uygulama>
