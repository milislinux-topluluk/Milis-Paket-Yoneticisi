<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
enca
</isim>
<tanim>
Karakter analizörü ve dönüştürücü.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/enca.png
</ekran_resmi>
<kurulacak_paketler>
enca
</kurulacak_paketler>
<silinecek_paketler>
enca
</silinecek_paketler>
</uygulama>
