<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
enca
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/enca.png
</ekran_resmi>
<kurulacak_paketler>
enca
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.16
</surum>
<silinecek_paketler>
enca
</silinecek_paketler>
</uygulama>
