<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxqt-admin
</isim>
<tanim>
Lxqt-admin paketi, LXQt'nin çalıştığı işletim sisteminin ayarlarını yapmak için iki GUI aracı sunar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxqt-admin.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-admin
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
lxqt-admin
</silinecek_paketler>
</uygulama>
