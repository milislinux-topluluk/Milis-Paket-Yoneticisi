<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dub
</isim>
<tanim>
D programlama dili paket-kütüphane yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dub.png
</ekran_resmi>
<kurulacak_paketler>
dub
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
dub
</silinecek_paketler>
</uygulama>
