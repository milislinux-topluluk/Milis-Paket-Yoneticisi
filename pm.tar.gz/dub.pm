<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dub
</isim>
<tanim>
D programlama dili paket-kütüphane yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/dub.png
</ekran_resmi>
<kurulacak_paketler>
dub
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.5.0
</surum>
<silinecek_paketler>
dub
</silinecek_paketler>
</uygulama>
