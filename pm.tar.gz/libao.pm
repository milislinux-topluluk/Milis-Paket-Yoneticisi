<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libao
</isim>
<tanim>
Cross-platform audio output library and plugins.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libao.png
</ekran_resmi>
<kurulacak_paketler>
libao
</kurulacak_paketler>
<silinecek_paketler>
libao
</silinecek_paketler>
</uygulama>
