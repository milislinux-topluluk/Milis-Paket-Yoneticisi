<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libao
</isim>
<tanim>
Cross-platform audio output library and plugins.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libao.png
</ekran_resmi>
<kurulacak_paketler>
libao
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.2.0
</surum>
<silinecek_paketler>
libao
</silinecek_paketler>
</uygulama>
