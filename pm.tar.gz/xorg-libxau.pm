<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxau
</isim>
<tanim>
libxi, X Authorization routines
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxau.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxau
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.0.8
</surum>
<silinecek_paketler>
xorg-libxau
</silinecek_paketler>
</uygulama>
