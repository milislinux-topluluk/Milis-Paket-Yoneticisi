<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
macos-simge-tema
</isim>
<tanim>
MacOS Simge Teması
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/macos-simge-tema.png
</ekran_resmi>
<kurulacak_paketler>
macos-simge-tema
</kurulacak_paketler>
<paketci>
Oltulu
</paketci>
<surum>
4.1.5
</surum>
<silinecek_paketler>
macos-simge-tema
</silinecek_paketler>
</uygulama>
