<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
macos-simge-tema
</isim>
<tanim>
MacOS Simge Teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/macos-simge-tema.png
</ekran_resmi>
<kurulacak_paketler>
macos-simge-tema
</kurulacak_paketler>
<paketci>
Oltulu
</paketci>
<silinecek_paketler>
macos-simge-tema
</silinecek_paketler>
</uygulama>
