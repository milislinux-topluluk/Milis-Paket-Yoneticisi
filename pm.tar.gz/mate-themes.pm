<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-themes
</isim>
<tanim>
MATE temaları
</tanim>
<ekran_resmi>
file:///tmp/mate-themes.png
</ekran_resmi>
<kurulacak_paketler>
mate-themes
</kurulacak_paketler>
<silinecek_paketler>
mate-themes
</silinecek_paketler>
</uygulama>
