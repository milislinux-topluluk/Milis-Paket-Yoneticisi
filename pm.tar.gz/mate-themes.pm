<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mate-themes
</isim>
<tanim>
MATE temaları
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mate-themes.png
</ekran_resmi>
<kurulacak_paketler>
mate-themes
</kurulacak_paketler>
<paketci>
milisarge yasarciv
</paketci>
<surum>
3.22.12
</surum>
<silinecek_paketler>
mate-themes
</silinecek_paketler>
</uygulama>
