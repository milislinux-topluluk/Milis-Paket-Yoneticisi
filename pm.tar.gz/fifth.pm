<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fifth
</isim>
<tanim>
Opera'nın en iyi özelliklerini taşıyan Linux'a özel tarayıcı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/fifth.png
</ekran_resmi>
<kurulacak_paketler>
fifth
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
fifth
</silinecek_paketler>
</uygulama>
