<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
fifth
</isim>
<tanim>
Opera'nın en iyi özelliklerini taşıyan Linux'a özel tarayıcı
</tanim>
<ekran_resmi>
file:///tmp/fifth.png
</ekran_resmi>
<kurulacak_paketler>
fifth
</kurulacak_paketler>
<silinecek_paketler>
fifth
</silinecek_paketler>
</uygulama>
