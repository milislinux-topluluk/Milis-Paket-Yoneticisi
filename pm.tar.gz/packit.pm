<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
packit
</isim>
<tanim>
Ağ sızma ve paket takip uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/packit.png
</ekran_resmi>
<kurulacak_paketler>
packit
</kurulacak_paketler>
<silinecek_paketler>
packit
</silinecek_paketler>
</uygulama>
