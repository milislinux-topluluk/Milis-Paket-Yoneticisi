<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
networkmanager
</isim>
<tanim>
Tools which simplify and make the network more directly manageable.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/networkmanager.png
</ekran_resmi>
<kurulacak_paketler>
networkmanager
</kurulacak_paketler>
<silinecek_paketler>
networkmanager
</silinecek_paketler>
</uygulama>
