<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libvorbis
</isim>
<tanim>
Audio codec, free, open and unpatented, it is roughly comparable to other formats.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libvorbis.png
</ekran_resmi>
<kurulacak_paketler>
libvorbis
</kurulacak_paketler>
<silinecek_paketler>
libvorbis
</silinecek_paketler>
</uygulama>
