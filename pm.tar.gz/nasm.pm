<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
nasm
</isim>
<tanim>
80x86 assembler designed for portability and modularity.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nasm.png
</ekran_resmi>
<kurulacak_paketler>
nasm
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
2.11.06
</surum>
<silinecek_paketler>
nasm
</silinecek_paketler>
</uygulama>
