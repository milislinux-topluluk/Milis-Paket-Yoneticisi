<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kcalutils
</isim>
<tanim>
The KDE calendar utility library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kcalutils.png
</ekran_resmi>
<kurulacak_paketler>
kcalutils
</kurulacak_paketler>
<paketci>
alihan-oztuk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kcalutils
</silinecek_paketler>
</uygulama>
