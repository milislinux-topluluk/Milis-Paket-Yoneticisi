<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
kcalutils
</isim>
<tanim>
The KDE calendar utility library
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kcalutils.png
</ekran_resmi>
<kurulacak_paketler>
kcalutils
</kurulacak_paketler>
<paketci>
alihan-oztuk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kcalutils
</silinecek_paketler>
</uygulama>
