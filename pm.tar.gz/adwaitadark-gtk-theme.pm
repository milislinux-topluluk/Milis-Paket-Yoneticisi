<?xml version="1.0"?>
<uygulama>
<grup>
Grafik_tasarım
</grup>
<isim>
adwaitadark-gtk-theme
</isim>
<tanim>
Koyu bir gtk2 teması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/adwaitadark-gtk-theme.png
</ekran_resmi>
<kurulacak_paketler>
adwaitadark-gtk-theme
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
adwaitadark-gtk-theme
</silinecek_paketler>
</uygulama>
