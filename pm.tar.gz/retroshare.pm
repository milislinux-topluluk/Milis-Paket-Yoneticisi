<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
retroshare
</isim>
<tanim>
retroshare,osya paylaşımı,mesajlaşma vb. uygulamalar içeren f2f çatısı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/retroshare.png
</ekran_resmi>
<kurulacak_paketler>
retroshare
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
retroshare
</silinecek_paketler>
</uygulama>
