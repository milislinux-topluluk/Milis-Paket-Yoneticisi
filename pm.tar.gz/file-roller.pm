<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
file-roller
</isim>
<tanim>
Arsiv dosyalari olusturmak ve duzenlemek icin bir arac
</tanim>
<ekran_resmi>
file:///tmp/file-roller.png
</ekran_resmi>
<kurulacak_paketler>
file-roller
</kurulacak_paketler>
<silinecek_paketler>
file-roller
</silinecek_paketler>
</uygulama>
