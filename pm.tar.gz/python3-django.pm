<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-django
</isim>
<tanim>
python3 django web framework
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-django.png
</ekran_resmi>
<kurulacak_paketler>
python3-django
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.11.2
</surum>
<silinecek_paketler>
python3-django
</silinecek_paketler>
</uygulama>
