<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
marco
</isim>
<tanim>
MATE için bir pencere yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/marco.png
</ekran_resmi>
<kurulacak_paketler>
marco
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.1
</surum>
<silinecek_paketler>
marco
</silinecek_paketler>
</uygulama>
