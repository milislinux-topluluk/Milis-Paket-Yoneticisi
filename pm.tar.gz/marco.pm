<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
marco
</isim>
<tanim>
MATE için bir pencere yöneticisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/marco.png
</ekran_resmi>
<kurulacak_paketler>
marco
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.1
</surum>
<silinecek_paketler>
marco
</silinecek_paketler>
</uygulama>
