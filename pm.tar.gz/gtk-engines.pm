<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gtk-engines
</isim>
<tanim>
The GTK Engines package contains eight themes/engines and two additional engines for GTK2.
</tanim>
<ekran_resmi>
file:///tmp/gtk-engines.png
</ekran_resmi>
<kurulacak_paketler>
gtk-engines
</kurulacak_paketler>
<silinecek_paketler>
gtk-engines
</silinecek_paketler>
</uygulama>
