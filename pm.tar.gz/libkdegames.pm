<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libkdegames
</isim>
<tanim>
Common code and data for many KDE games
</tanim>
<ekran_resmi>
file:///tmp/libkdegames.png
</ekran_resmi>
<kurulacak_paketler>
libkdegames
</kurulacak_paketler>
<silinecek_paketler>
libkdegames
</silinecek_paketler>
</uygulama>
