<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libkdegames
</isim>
<tanim>
Birçok KDE oyununda ortak kod ve veriler
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libkdegames.png
</ekran_resmi>
<kurulacak_paketler>
libkdegames
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
libkdegames
</silinecek_paketler>
</uygulama>
