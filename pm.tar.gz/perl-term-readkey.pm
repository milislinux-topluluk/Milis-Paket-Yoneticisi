<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-term-readkey
</isim>
<tanim>
A perl module for simple terminal control
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-term-readkey.png
</ekran_resmi>
<kurulacak_paketler>
perl-term-readkey
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
perl-term-readkey
</silinecek_paketler>
</uygulama>
