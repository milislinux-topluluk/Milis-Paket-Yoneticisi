<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
perl-term-readkey
</isim>
<tanim>
A perl module for simple terminal control
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/perl-term-readkey.png
</ekran_resmi>
<kurulacak_paketler>
perl-term-readkey
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.33
</surum>
<silinecek_paketler>
perl-term-readkey
</silinecek_paketler>
</uygulama>
