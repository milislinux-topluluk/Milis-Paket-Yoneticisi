<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nano
</isim>
<tanim>
A simple text editor which aims to replace Pico, the default editor in the Pine package.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/nano.png
</ekran_resmi>
<kurulacak_paketler>
nano
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.5.2
</surum>
<silinecek_paketler>
nano
</silinecek_paketler>
</uygulama>
