<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
nano
</isim>
<tanim>
A simple text editor which aims to replace Pico, the default editor in the Pine package.
</tanim>
<ekran_resmi>
file:///tmp/nano.png
</ekran_resmi>
<kurulacak_paketler>
nano
</kurulacak_paketler>
<silinecek_paketler>
nano
</silinecek_paketler>
</uygulama>
