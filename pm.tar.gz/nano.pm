<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
nano
</isim>
<tanim>
A simple text editor which aims to replace Pico, the default editor in the Pine package.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/nano.png
</ekran_resmi>
<kurulacak_paketler>
nano
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.5.2
</surum>
<silinecek_paketler>
nano
</silinecek_paketler>
</uygulama>
