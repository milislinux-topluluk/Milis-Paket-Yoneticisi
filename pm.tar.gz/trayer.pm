<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
trayer
</isim>
<tanim>
Hafif bir GTK2 tabanlı systray
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/trayer.png
</ekran_resmi>
<kurulacak_paketler>
trayer
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.0
</surum>
<silinecek_paketler>
trayer
</silinecek_paketler>
</uygulama>
