<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
trayer
</isim>
<tanim>
Hafif bir GTK2 tabanlı systray
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/trayer.png
</ekran_resmi>
<kurulacak_paketler>
trayer
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
trayer
</silinecek_paketler>
</uygulama>
