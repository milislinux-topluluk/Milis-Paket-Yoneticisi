<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xdg-user-dirs
</isim>
<tanim>
Manage user directories like ~/Desktop and ~/Music
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xdg-user-dirs.png
</ekran_resmi>
<kurulacak_paketler>
xdg-user-dirs
</kurulacak_paketler>
<silinecek_paketler>
xdg-user-dirs
</silinecek_paketler>
</uygulama>
