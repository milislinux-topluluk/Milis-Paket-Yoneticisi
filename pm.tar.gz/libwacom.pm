<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libwacom
</isim>
<tanim>
Library to identify Wacom tablets and their features
</tanim>
<ekran_resmi>
file:///tmp/libwacom.png
</ekran_resmi>
<kurulacak_paketler>
libwacom
</kurulacak_paketler>
<silinecek_paketler>
libwacom
</silinecek_paketler>
</uygulama>
