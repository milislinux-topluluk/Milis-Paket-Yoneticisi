<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libwacom
</isim>
<tanim>
Library to identify Wacom tablets and their features
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libwacom.png
</ekran_resmi>
<kurulacak_paketler>
libwacom
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.21
</surum>
<silinecek_paketler>
libwacom
</silinecek_paketler>
</uygulama>
