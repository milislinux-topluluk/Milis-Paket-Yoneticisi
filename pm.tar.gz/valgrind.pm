<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
valgrind
</isim>
<tanim>
Dinamik analiz araçları oluşturmak için bir alet çerçevesi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/valgrind.png
</ekran_resmi>
<kurulacak_paketler>
valgrind
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.13.0
</surum>
<silinecek_paketler>
valgrind
</silinecek_paketler>
</uygulama>
