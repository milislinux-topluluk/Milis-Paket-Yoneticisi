<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
kcontacts
</isim>
<tanim>
libkcontacts - new address book API for KDE
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kcontacts.png
</ekran_resmi>
<kurulacak_paketler>
kcontacts
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
kcontacts
</silinecek_paketler>
</uygulama>
