<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kcontacts
</isim>
<tanim>
Libkcontacts - KDE için yeni adres defteri API'sı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kcontacts.png
</ekran_resmi>
<kurulacak_paketler>
kcontacts
</kurulacak_paketler>
<paketci>
cihanAlkan
</paketci>
<surum>
17.12.0
</surum>
<silinecek_paketler>
kcontacts
</silinecek_paketler>
</uygulama>
