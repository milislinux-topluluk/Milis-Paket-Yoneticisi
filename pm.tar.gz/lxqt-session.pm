<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
lxqt-session
</isim>
<tanim>
Lxqt-session paketi, LXQt için varsayılan oturum yöneticisini içerir.
</tanim>
<ekran_resmi>
file:///tmp/lxqt-session.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-session
</kurulacak_paketler>
<silinecek_paketler>
lxqt-session
</silinecek_paketler>
</uygulama>
