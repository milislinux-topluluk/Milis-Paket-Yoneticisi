<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
llvm
</isim>
<tanim>
LLVM derleyicisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/llvm.png
</ekran_resmi>
<kurulacak_paketler>
llvm
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.0.0
</surum>
<silinecek_paketler>
llvm
</silinecek_paketler>
</uygulama>
