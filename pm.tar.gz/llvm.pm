<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
llvm
</isim>
<tanim>
LLVM derleyicisi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/llvm.png
</ekran_resmi>
<kurulacak_paketler>
llvm
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
4.0.0
</surum>
<silinecek_paketler>
llvm
</silinecek_paketler>
</uygulama>
