<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gsm
</isim>
<tanim>
Shared libraries for GSM 06.10 lossy speech compression
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gsm.png
</ekran_resmi>
<kurulacak_paketler>
gsm
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.0.14
</surum>
<silinecek_paketler>
gsm
</silinecek_paketler>
</uygulama>
