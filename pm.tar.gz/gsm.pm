<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gsm
</isim>
<tanim>
Shared libraries for GSM 06.10 lossy speech compression
</tanim>
<ekran_resmi>
file:///tmp/gsm.png
</ekran_resmi>
<kurulacak_paketler>
gsm
</kurulacak_paketler>
<silinecek_paketler>
gsm
</silinecek_paketler>
</uygulama>
