<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
subversion
</isim>
<tanim>
A version control system (CVS replacement)
</tanim>
<ekran_resmi>
file:///tmp/subversion.png
</ekran_resmi>
<kurulacak_paketler>
subversion
</kurulacak_paketler>
<silinecek_paketler>
subversion
</silinecek_paketler>
</uygulama>
