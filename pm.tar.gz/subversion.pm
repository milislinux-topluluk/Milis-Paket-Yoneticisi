<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
subversion
</isim>
<tanim>
Bir sürüm kontrol sistemi (CVS değiştirme)
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/subversion.png
</ekran_resmi>
<kurulacak_paketler>
subversion
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.9.3
</surum>
<silinecek_paketler>
subversion
</silinecek_paketler>
</uygulama>
