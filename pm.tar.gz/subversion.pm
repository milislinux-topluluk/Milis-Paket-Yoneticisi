<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
subversion
</isim>
<tanim>
A version control system (CVS replacement)
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/subversion.png
</ekran_resmi>
<kurulacak_paketler>
subversion
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1.9.3
</surum>
<silinecek_paketler>
subversion
</silinecek_paketler>
</uygulama>
