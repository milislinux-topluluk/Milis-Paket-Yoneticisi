<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-menus
</isim>
<tanim>
GNOME menü özellikleri.
</tanim>
<ekran_resmi>
file:///tmp/gnome-menus.png
</ekran_resmi>
<kurulacak_paketler>
gnome-menus
</kurulacak_paketler>
<silinecek_paketler>
gnome-menus
</silinecek_paketler>
</uygulama>
