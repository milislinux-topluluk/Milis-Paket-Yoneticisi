<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-menus
</isim>
<tanim>
GNOME menü özellikleri.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-menus.png
</ekran_resmi>
<kurulacak_paketler>
gnome-menus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.13.3
</surum>
<silinecek_paketler>
gnome-menus
</silinecek_paketler>
</uygulama>
