<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-menus
</isim>
<tanim>
GNOME menü özellikleri.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-menus.png
</ekran_resmi>
<kurulacak_paketler>
gnome-menus
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
gnome-menus
</silinecek_paketler>
</uygulama>
