<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3-gitdb
</isim>
<tanim>
python için gitdb nesne kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3-gitdb.png
</ekran_resmi>
<kurulacak_paketler>
python3-gitdb
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.6.4
</surum>
<silinecek_paketler>
python3-gitdb
</silinecek_paketler>
</uygulama>
