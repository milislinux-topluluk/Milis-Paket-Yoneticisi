<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
uget
</isim>
<tanim>
UGet, Linux için En İyi İndirme Yöneticisi.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/uget.png
</ekran_resmi>
<kurulacak_paketler>
uget
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.0.9
</surum>
<silinecek_paketler>
uget
</silinecek_paketler>
</uygulama>
