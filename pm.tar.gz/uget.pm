<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
uget
</isim>
<tanim>
UGet, Linux için En İyi İndirme Yöneticisi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/uget.png
</ekran_resmi>
<kurulacak_paketler>
uget
</kurulacak_paketler>
<silinecek_paketler>
uget
</silinecek_paketler>
</uygulama>
