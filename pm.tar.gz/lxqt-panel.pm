<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxqt-panel
</isim>
<tanim>
Lxqt-panel paketi hafif bir X11 masaüstü paneli içeriyor.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxqt-panel.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-panel
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.11.1
</surum>
<silinecek_paketler>
lxqt-panel
</silinecek_paketler>
</uygulama>
