<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
mhash
</isim>
<tanim>
Farklı hash algoritmaları kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mhash.png
</ekran_resmi>
<kurulacak_paketler>
mhash
</kurulacak_paketler>
<silinecek_paketler>
mhash
</silinecek_paketler>
</uygulama>
