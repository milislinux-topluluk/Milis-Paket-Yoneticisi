<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
icu
</isim>
<tanim>
Unicode Uluslararası Bileşenleri, olgun ve yaygın olarak kullanılan C / C ++ kitaplıkları kümesidir
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/icu.png
</ekran_resmi>
<kurulacak_paketler>
icu
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
59.1
</surum>
<silinecek_paketler>
icu
</silinecek_paketler>
</uygulama>
