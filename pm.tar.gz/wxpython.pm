<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
wxpython
</isim>
<tanim>
Python için bir wxWidgets GUI araç seti
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/wxpython.png
</ekran_resmi>
<kurulacak_paketler>
wxpython
</kurulacak_paketler>
<paketci>
Oltulu
</paketci>
<surum>
3.0.2.0
</surum>
<silinecek_paketler>
wxpython
</silinecek_paketler>
</uygulama>
