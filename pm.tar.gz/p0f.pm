<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
p0f
</isim>
<tanim>
p0f, tcp-ip trafik akışını takip ve dinleme uygulaması
</tanim>
<ekran_resmi>
file:///tmp/p0f.png
</ekran_resmi>
<kurulacak_paketler>
p0f
</kurulacak_paketler>
<silinecek_paketler>
p0f
</silinecek_paketler>
</uygulama>
