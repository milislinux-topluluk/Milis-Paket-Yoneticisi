<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
npapi-sdk
</isim>
<tanim>
NPAPI-SDK, Mozilla'nın NPAPI üstbilgilerinin bir paketidir.
</tanim>
<ekran_resmi>
file:///tmp/npapi-sdk.png
</ekran_resmi>
<kurulacak_paketler>
npapi-sdk
</kurulacak_paketler>
<silinecek_paketler>
npapi-sdk
</silinecek_paketler>
</uygulama>
