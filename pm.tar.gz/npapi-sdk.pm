<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
npapi-sdk
</isim>
<tanim>
NPAPI-SDK, Mozilla'nın NPAPI üstbilgilerinin bir paketidir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/npapi-sdk.png
</ekran_resmi>
<kurulacak_paketler>
npapi-sdk
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
npapi-sdk
</silinecek_paketler>
</uygulama>
