<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
npapi-sdk
</isim>
<tanim>
Bundle of Netscape Plugin Application Programming Interface headers by Mozilla
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/npapi-sdk.png
</ekran_resmi>
<kurulacak_paketler>
npapi-sdk
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.27.2
</surum>
<silinecek_paketler>
npapi-sdk
</silinecek_paketler>
</uygulama>
