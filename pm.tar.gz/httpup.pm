<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
httpup
</isim>
<tanim>
Http üzerinden tek yönlü senkronizasyon
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/httpup.png
</ekran_resmi>
<kurulacak_paketler>
httpup
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.4.0l
</surum>
<silinecek_paketler>
httpup
</silinecek_paketler>
</uygulama>
