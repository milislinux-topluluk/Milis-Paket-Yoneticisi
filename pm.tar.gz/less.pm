<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
less
</isim>
<tanim>
The Less package contains a text file viewer.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/less.png
</ekran_resmi>
<kurulacak_paketler>
less
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
458
</surum>
<silinecek_paketler>
less
</silinecek_paketler>
</uygulama>
