<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
less
</isim>
<tanim>
The Less package contains a text file viewer.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/less.png
</ekran_resmi>
<kurulacak_paketler>
less
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
458
</surum>
<silinecek_paketler>
less
</silinecek_paketler>
</uygulama>
