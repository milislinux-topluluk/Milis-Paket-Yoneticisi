<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxv
</isim>
<tanim>
libXv, library X Video extension client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxv.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxv
</kurulacak_paketler>
<silinecek_paketler>
xorg-libxv
</silinecek_paketler>
</uygulama>
