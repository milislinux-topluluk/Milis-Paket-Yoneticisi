<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
rfkill
</isim>
<tanim>
Userspace tool to query and toggle rfkill switches
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/rfkill.png
</ekran_resmi>
<kurulacak_paketler>
rfkill
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.5
</surum>
<silinecek_paketler>
rfkill
</silinecek_paketler>
</uygulama>
