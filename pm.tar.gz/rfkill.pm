<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
rfkill
</isim>
<tanim>
Userspace tool to query and toggle rfkill switches
</tanim>
<ekran_resmi>
file:///tmp/rfkill.png
</ekran_resmi>
<kurulacak_paketler>
rfkill
</kurulacak_paketler>
<silinecek_paketler>
rfkill
</silinecek_paketler>
</uygulama>
