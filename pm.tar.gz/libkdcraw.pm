<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libkdcraw
</isim>
<tanim>
A C++ interface used to decode RAW picture
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libkdcraw.png
</ekran_resmi>
<kurulacak_paketler>
libkdcraw
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
libkdcraw
</silinecek_paketler>
</uygulama>
