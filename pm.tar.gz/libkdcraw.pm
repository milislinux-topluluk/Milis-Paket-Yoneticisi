<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libkdcraw
</isim>
<tanim>
A C++ interface used to decode RAW picture
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libkdcraw.png
</ekran_resmi>
<kurulacak_paketler>
libkdcraw
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
libkdcraw
</silinecek_paketler>
</uygulama>
