<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
x265
</isim>
<tanim>
Open Source H265/HEVC video encoder.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/x265.png
</ekran_resmi>
<kurulacak_paketler>
x265
</kurulacak_paketler>
<paketci>
Chris Farrell, timcowchip at gmail dot com
</paketci>
<surum>
1.8
</surum>
<silinecek_paketler>
x265
</silinecek_paketler>
</uygulama>
