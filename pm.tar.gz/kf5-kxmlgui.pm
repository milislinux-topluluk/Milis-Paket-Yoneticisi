<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kxmlgui
</isim>
<tanim>
Kullanıcı tarafından konfigüre edilebilir ana pencereler
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kxmlgui.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kxmlgui
</kurulacak_paketler>
<silinecek_paketler>
kf5-kxmlgui
</silinecek_paketler>
</uygulama>
