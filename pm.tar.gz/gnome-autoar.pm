<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-autoar
</isim>
<tanim>
Otomatik arşiv oluşturucu ve çıkarıcı kitaplığı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-autoar.png
</ekran_resmi>
<kurulacak_paketler>
gnome-autoar
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.2.2
</surum>
<silinecek_paketler>
gnome-autoar
</silinecek_paketler>
</uygulama>
