<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-autoar
</isim>
<tanim>
Otomatik arşiv oluşturucu ve çıkarıcı kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-autoar.png
</ekran_resmi>
<kurulacak_paketler>
gnome-autoar
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<silinecek_paketler>
gnome-autoar
</silinecek_paketler>
</uygulama>
