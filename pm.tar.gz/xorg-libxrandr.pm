<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxrandr
</isim>
<tanim>
Library libXrandr, resize and rotate extension client library
</tanim>
<ekran_resmi>
file:///tmp/xorg-libxrandr.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxrandr
</kurulacak_paketler>
<silinecek_paketler>
xorg-libxrandr
</silinecek_paketler>
</uygulama>
