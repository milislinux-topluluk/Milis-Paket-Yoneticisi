<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xorg-libxrandr
</isim>
<tanim>
Library libXrandr, resize and rotate extension client library
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xorg-libxrandr.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxrandr
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.5.0
</surum>
<silinecek_paketler>
xorg-libxrandr
</silinecek_paketler>
</uygulama>
