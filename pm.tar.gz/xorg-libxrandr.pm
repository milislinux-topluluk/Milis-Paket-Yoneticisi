<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxrandr
</isim>
<tanim>
Library libXrandr, resize and rotate extension client library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxrandr.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxrandr
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
xorg-libxrandr
</silinecek_paketler>
</uygulama>
