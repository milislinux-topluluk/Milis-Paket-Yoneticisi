<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xcb-util-image
</isim>
<tanim>
XCB utilities library
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xcb-util-image.png
</ekran_resmi>
<kurulacak_paketler>
xcb-util-image
</kurulacak_paketler>
<silinecek_paketler>
xcb-util-image
</silinecek_paketler>
</uygulama>
