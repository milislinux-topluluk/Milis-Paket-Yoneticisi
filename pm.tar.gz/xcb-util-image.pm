<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xcb-util-image
</isim>
<tanim>
XCB utilities library
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xcb-util-image.png
</ekran_resmi>
<kurulacak_paketler>
xcb-util-image
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.4.0
</surum>
<silinecek_paketler>
xcb-util-image
</silinecek_paketler>
</uygulama>
