<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libnet
</isim>
<tanim>
Ağ paketleri inşa etmek ve enjekte etmek için kütüphane.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libnet.png
</ekran_resmi>
<kurulacak_paketler>
libnet
</kurulacak_paketler>
<silinecek_paketler>
libnet
</silinecek_paketler>
</uygulama>
