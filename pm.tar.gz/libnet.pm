<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libnet
</isim>
<tanim>
Ağ paketleri inşa etmek ve enjekte etmek için kütüphane.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libnet.png
</ekran_resmi>
<kurulacak_paketler>
libnet
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.1.6
</surum>
<silinecek_paketler>
libnet
</silinecek_paketler>
</uygulama>
