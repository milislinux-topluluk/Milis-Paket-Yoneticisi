<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
menulibre
</isim>
<tanim>
An advanced menu editor that provides modern features in a clean, easy-to-use interface. All without GNOME dependencies
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/menulibre.png
</ekran_resmi>
<kurulacak_paketler>
menulibre
</kurulacak_paketler>
<silinecek_paketler>
menulibre
</silinecek_paketler>
</uygulama>
