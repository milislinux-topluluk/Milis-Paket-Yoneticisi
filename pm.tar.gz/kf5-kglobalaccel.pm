<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
kf5-kglobalaccel
</isim>
<tanim>
Genel çalışma alanı kısayolları için destek ekleyin
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/kf5-kglobalaccel.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kglobalaccel
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.41.0
</surum>
<silinecek_paketler>
kf5-kglobalaccel
</silinecek_paketler>
</uygulama>
