<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kglobalaccel
</isim>
<tanim>
Genel çalışma alanı kısayolları için destek ekleyin
</tanim>
<ekran_resmi>
file:///tmp/kf5-kglobalaccel.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kglobalaccel
</kurulacak_paketler>
<silinecek_paketler>
kf5-kglobalaccel
</silinecek_paketler>
</uygulama>
