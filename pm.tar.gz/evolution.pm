<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
evolution
</isim>
<tanim>
E-postalarınızı, kişilerinizi ve programınızı yönetin.
</tanim>
<ekran_resmi>
file:///tmp/evolution.png
</ekran_resmi>
<kurulacak_paketler>
evolution
</kurulacak_paketler>
<silinecek_paketler>
evolution
</silinecek_paketler>
</uygulama>
