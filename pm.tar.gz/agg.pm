<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
agg
</isim>
<tanim>
Anti-Grain Geometry (AGG) 2D grafik kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/agg.png
</ekran_resmi>
<kurulacak_paketler>
agg
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
agg
</silinecek_paketler>
</uygulama>
