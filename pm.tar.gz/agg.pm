<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
agg
</isim>
<tanim>
Anti-Grain Geometry (AGG) 2D grafik kütüphanesi
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/agg.png
</ekran_resmi>
<kurulacak_paketler>
agg
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.5
</surum>
<silinecek_paketler>
agg
</silinecek_paketler>
</uygulama>
