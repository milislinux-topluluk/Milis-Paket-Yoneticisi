<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libftdi
</isim>
<tanim>
FTDI yongaları ile konuşmak için bir kütüphane, isteğe bağlı python bağları.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libftdi.png
</ekran_resmi>
<kurulacak_paketler>
libftdi
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.3
</surum>
<silinecek_paketler>
libftdi
</silinecek_paketler>
</uygulama>
