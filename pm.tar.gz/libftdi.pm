<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libftdi
</isim>
<tanim>
FTDI yongaları ile konuşmak için bir kütüphane, isteğe bağlı python bağları.
</tanim>
<ekran_resmi>
file:///tmp/libftdi.png
</ekran_resmi>
<kurulacak_paketler>
libftdi
</kurulacak_paketler>
<silinecek_paketler>
libftdi
</silinecek_paketler>
</uygulama>
