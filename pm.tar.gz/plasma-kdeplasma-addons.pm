<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-kdeplasma-addons
</isim>
<tanim>
Plazma deneyiminizi geliştirmek için her türlü eklenti
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/plasma-kdeplasma-addons.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kdeplasma-addons
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-kdeplasma-addons
</silinecek_paketler>
</uygulama>
