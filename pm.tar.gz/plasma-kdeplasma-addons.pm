<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
plasma-kdeplasma-addons
</isim>
<tanim>
All kind of addons to improve your Plasma experience
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/plasma-kdeplasma-addons.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kdeplasma-addons
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
5.8.1
</surum>
<silinecek_paketler>
plasma-kdeplasma-addons
</silinecek_paketler>
</uygulama>
