<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
lxqt-runner
</isim>
<tanim>
Lxqt-runner paketi, adlarını yazarak programları hızlı bir şekilde başlatmak için kullanılan bir araç sağlar.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/lxqt-runner.png
</ekran_resmi>
<kurulacak_paketler>
lxqt-runner
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
0.11.1
</surum>
<silinecek_paketler>
lxqt-runner
</silinecek_paketler>
</uygulama>
