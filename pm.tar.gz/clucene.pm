<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
clucene
</isim>
<tanim>
CLucene, yüksek performanslı bir metin arama motoru olan Lucene'in C ++ versiyonudur.
</tanim>
<ekran_resmi>
file:///tmp/clucene.png
</ekran_resmi>
<kurulacak_paketler>
clucene
</kurulacak_paketler>
<silinecek_paketler>
clucene
</silinecek_paketler>
</uygulama>
