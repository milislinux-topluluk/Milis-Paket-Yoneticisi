<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
clucene
</isim>
<tanim>
CLucene, yüksek performanslı bir metin arama motoru olan Lucene'in C ++ versiyonudur.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/clucene.png
</ekran_resmi>
<kurulacak_paketler>
clucene
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
2.3.3.4
</surum>
<silinecek_paketler>
clucene
</silinecek_paketler>
</uygulama>
