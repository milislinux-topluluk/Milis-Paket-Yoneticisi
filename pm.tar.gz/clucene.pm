<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
clucene
</isim>
<tanim>
CLucene is a C++ version of Lucene, a high performance text search engine.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/clucene.png
</ekran_resmi>
<kurulacak_paketler>
clucene
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
2.3.3.4
</surum>
<silinecek_paketler>
clucene
</silinecek_paketler>
</uygulama>
