<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-session
</isim>
<tanim>
GNOME oturum yöneticisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnome-session.png
</ekran_resmi>
<kurulacak_paketler>
gnome-session
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.22.2
</surum>
<silinecek_paketler>
gnome-session
</silinecek_paketler>
</uygulama>
