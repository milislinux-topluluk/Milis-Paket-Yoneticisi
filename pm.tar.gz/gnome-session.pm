<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-session
</isim>
<tanim>
GNOME oturum yöneticisi
</tanim>
<ekran_resmi>
file:///tmp/gnome-session.png
</ekran_resmi>
<kurulacak_paketler>
gnome-session
</kurulacak_paketler>
<silinecek_paketler>
gnome-session
</silinecek_paketler>
</uygulama>
