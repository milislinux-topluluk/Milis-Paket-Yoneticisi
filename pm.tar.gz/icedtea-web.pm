<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
icedtea-web
</isim>
<tanim>
java web uygulamaları için tarayıcı eklentisi
</tanim>
<ekran_resmi>
file:///tmp/icedtea-web.png
</ekran_resmi>
<kurulacak_paketler>
icedtea-web
</kurulacak_paketler>
<silinecek_paketler>
icedtea-web
</silinecek_paketler>
</uygulama>
