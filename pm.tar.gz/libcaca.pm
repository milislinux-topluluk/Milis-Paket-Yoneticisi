<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libcaca
</isim>
<tanim>
Renkli ASCII Sanat Kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libcaca.png
</ekran_resmi>
<kurulacak_paketler>
libcaca
</kurulacak_paketler>
<silinecek_paketler>
libcaca
</silinecek_paketler>
</uygulama>
