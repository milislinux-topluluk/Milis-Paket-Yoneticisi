<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libcaca
</isim>
<tanim>
Color ASCII Art Library
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libcaca.png
</ekran_resmi>
<kurulacak_paketler>
libcaca
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
0.99.beta19
</surum>
<silinecek_paketler>
libcaca
</silinecek_paketler>
</uygulama>
