<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
privoxy
</isim>
<tanim>
A web proxy with advanced filtering capabilities.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/privoxy.png
</ekran_resmi>
<kurulacak_paketler>
privoxy
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
privoxy
</silinecek_paketler>
</uygulama>
