<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
privoxy
</isim>
<tanim>
A web proxy with advanced filtering capabilities.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/privoxy.png
</ekran_resmi>
<kurulacak_paketler>
privoxy
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.0.26
</surum>
<silinecek_paketler>
privoxy
</silinecek_paketler>
</uygulama>
