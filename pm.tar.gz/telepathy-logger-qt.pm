<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telepathy-logger-qt
</isim>
<tanim>
TpLogger istemci kitaplığında Qt Wrapper.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telepathy-logger-qt.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-logger-qt
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
telepathy-logger-qt
</silinecek_paketler>
</uygulama>
