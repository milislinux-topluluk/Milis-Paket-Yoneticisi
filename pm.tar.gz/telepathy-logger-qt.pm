<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
telepathy-logger-qt
</isim>
<tanim>
Qt Wrapper around TpLogger client library.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/telepathy-logger-qt.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-logger-qt
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
15.04.0
</surum>
<silinecek_paketler>
telepathy-logger-qt
</silinecek_paketler>
</uygulama>
