<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
websocketpp
</isim>
<tanim>
C ++/Boost Asio tabanlı websocket istemcisi/sunucu kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/websocketpp.png
</ekran_resmi>
<kurulacak_paketler>
websocketpp
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.7.0
</surum>
<silinecek_paketler>
websocketpp
</silinecek_paketler>
</uygulama>
