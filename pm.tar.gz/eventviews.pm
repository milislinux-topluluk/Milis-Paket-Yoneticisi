<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
eventviews
</isim>
<tanim>
Library for creating events
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/eventviews.png
</ekran_resmi>
<kurulacak_paketler>
eventviews
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
eventviews
</silinecek_paketler>
</uygulama>
