<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
eventviews
</isim>
<tanim>
Etkinlik oluşturmak için kütüphane
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/eventviews.png
</ekran_resmi>
<kurulacak_paketler>
eventviews
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
eventviews
</silinecek_paketler>
</uygulama>
