<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
udisks2
</isim>
<tanim>
Daemon, tools and libraries to access and manipulate disks and storage devices.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/udisks2.png
</ekran_resmi>
<kurulacak_paketler>
udisks2
</kurulacak_paketler>
<silinecek_paketler>
udisks2
</silinecek_paketler>
</uygulama>
