<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
neomutt
</isim>
<tanim>
Mutt paketi bir posta kullanıcı aracısı içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/neomutt.png
</ekran_resmi>
<kurulacak_paketler>
neomutt
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
neomutt
</silinecek_paketler>
</uygulama>
