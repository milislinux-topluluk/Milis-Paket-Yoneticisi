<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
spectacle
</isim>
<tanim>
Spectacle, masaüstü ekran görüntülerini yakalamak için basit bir uygulamadır
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/spectacle.png
</ekran_resmi>
<kurulacak_paketler>
spectacle
</kurulacak_paketler>
<silinecek_paketler>
spectacle
</silinecek_paketler>
</uygulama>
