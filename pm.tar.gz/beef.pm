<?xml version="1.0"?>
<uygulama>
<grup>
Güvenlik
</grup>
<isim>
beef
</isim>
<tanim>
The Browser Exploitation Framework that focuses on the web browser
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/beef.png
</ekran_resmi>
<kurulacak_paketler>
beef
</kurulacak_paketler>
<paketci>
yakar(aydin@komutan.org)
</paketci>
<surum>
0.4.7.0
</surum>
<silinecek_paketler>
beef
</silinecek_paketler>
</uygulama>
