<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
qca-qt5
</isim>
<tanim>
Qt5 Cryptographic Architecture
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/qca-qt5.png
</ekran_resmi>
<kurulacak_paketler>
qca-qt5
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
2.1.1
</surum>
<silinecek_paketler>
qca-qt5
</silinecek_paketler>
</uygulama>
