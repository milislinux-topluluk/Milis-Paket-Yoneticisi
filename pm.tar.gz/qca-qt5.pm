<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
qca-qt5
</isim>
<tanim>
Qt5 Şifreleme Mimarisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qca-qt5.png
</ekran_resmi>
<kurulacak_paketler>
qca-qt5
</kurulacak_paketler>
<silinecek_paketler>
qca-qt5
</silinecek_paketler>
</uygulama>
