<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
sfml
</isim>
<tanim>
Sade,hızlı,çoğl platform destekli multimedya kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sfml.png
</ekran_resmi>
<kurulacak_paketler>
sfml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.4.2
</surum>
<silinecek_paketler>
sfml
</silinecek_paketler>
</uygulama>
