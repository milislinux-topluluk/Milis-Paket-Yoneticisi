<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sfml
</isim>
<tanim>
Sade,hızlı,çoğl platform destekli multimedya kütüphanesi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sfml.png
</ekran_resmi>
<kurulacak_paketler>
sfml
</kurulacak_paketler>
<silinecek_paketler>
sfml
</silinecek_paketler>
</uygulama>
