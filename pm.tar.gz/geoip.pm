<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
geoip
</isim>
<tanim>
cografi ip çözücü veritabanı uygulaması
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/geoip.png
</ekran_resmi>
<kurulacak_paketler>
geoip
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
geoip
</silinecek_paketler>
</uygulama>
