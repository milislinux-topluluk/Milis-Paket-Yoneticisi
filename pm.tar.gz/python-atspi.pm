<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python-atspi
</isim>
<tanim>
Bu pakette, GNOME Erişilebilirlik'in temel bileşenleri için Python bağları bulunmaktadır.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/python-atspi.png
</ekran_resmi>
<kurulacak_paketler>
python-atspi
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.16.0
</surum>
<silinecek_paketler>
python-atspi
</silinecek_paketler>
</uygulama>
