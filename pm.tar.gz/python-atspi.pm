<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-atspi
</isim>
<tanim>
Bu pakette, GNOME Erişilebilirlik'in temel bileşenleri için Python bağları bulunmaktadır.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-atspi.png
</ekran_resmi>
<kurulacak_paketler>
python-atspi
</kurulacak_paketler>
<silinecek_paketler>
python-atspi
</silinecek_paketler>
</uygulama>
