<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libunwind
</isim>
<tanim>
Define a portable and efficient C API to determine the call-chain of a program.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libunwind.png
</ekran_resmi>
<kurulacak_paketler>
libunwind
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.1
</surum>
<silinecek_paketler>
libunwind
</silinecek_paketler>
</uygulama>
