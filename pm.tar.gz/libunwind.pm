<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libunwind
</isim>
<tanim>
Bir programın çağrı zincirini belirlemek için taşınabilir ve verimli bir C API'yi tanımlayın.
</tanim>
<ekran_resmi>
file:///tmp/libunwind.png
</ekran_resmi>
<kurulacak_paketler>
libunwind
</kurulacak_paketler>
<silinecek_paketler>
libunwind
</silinecek_paketler>
</uygulama>
