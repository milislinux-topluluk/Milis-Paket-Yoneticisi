<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnuplot
</isim>
<tanim>
GNUPlot, bir grafik çizim yazılımı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gnuplot.png
</ekran_resmi>
<kurulacak_paketler>
gnuplot
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.0.5
</surum>
<silinecek_paketler>
gnuplot
</silinecek_paketler>
</uygulama>
