<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
qt5-webkit
</isim>
<tanim>
Bir WebKit2 tabanlı uygulama sınıfları ve yeni bir QML API'sı
</tanim>
<ekran_resmi>
file:///tmp/qt5-webkit.png
</ekran_resmi>
<kurulacak_paketler>
qt5-webkit
</kurulacak_paketler>
<silinecek_paketler>
qt5-webkit
</silinecek_paketler>
</uygulama>
