<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
qt5-webkit
</isim>
<tanim>
Bir WebKit2 tabanlı uygulama sınıfları ve yeni bir QML API'sı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/qt5-webkit.png
</ekran_resmi>
<kurulacak_paketler>
qt5-webkit
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
5.9.0
</surum>
<silinecek_paketler>
qt5-webkit
</silinecek_paketler>
</uygulama>
