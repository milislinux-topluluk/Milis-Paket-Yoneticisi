<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
js1
</isim>
<tanim>
JavaScript interpreter and libraries
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/js1.png
</ekran_resmi>
<kurulacak_paketler>
js1
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
17.0.0
</surum>
<silinecek_paketler>
js1
</silinecek_paketler>
</uygulama>
