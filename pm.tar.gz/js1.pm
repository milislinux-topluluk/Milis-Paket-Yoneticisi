<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
js1
</isim>
<tanim>
JavaScript interpreter and libraries
</tanim>
<ekran_resmi>
file:///tmp/js1.png
</ekran_resmi>
<kurulacak_paketler>
js1
</kurulacak_paketler>
<silinecek_paketler>
js1
</silinecek_paketler>
</uygulama>
