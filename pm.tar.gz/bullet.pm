<?xml version="1.0"?>
<uygulama>
<grup>
kütüphane
</grup>
<isim>
bullet
</isim>
<tanim>
Sürekli çarpışma algılama ve fizik kütüphanesi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/bullet.png
</ekran_resmi>
<kurulacak_paketler>
bullet
</kurulacak_paketler>
<silinecek_paketler>
bullet
</silinecek_paketler>
</uygulama>
