<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
bullet
</isim>
<tanim>
Sürekli çarpışma algılama ve fizik kütüphanesi.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/bullet.png
</ekran_resmi>
<kurulacak_paketler>
bullet
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
2.86
</surum>
<silinecek_paketler>
bullet
</silinecek_paketler>
</uygulama>
