<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-xml-sax
</isim>
<tanim>
XML için basit API
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-xml-sax.png
</ekran_resmi>
<kurulacak_paketler>
perl-xml-sax
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.99
</surum>
<silinecek_paketler>
perl-xml-sax
</silinecek_paketler>
</uygulama>
