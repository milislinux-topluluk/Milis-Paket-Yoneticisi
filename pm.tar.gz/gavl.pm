<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gavl
</isim>
<tanim>
Multimedya API'leri oluşturulabilen düşük seviye bir kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gavl.png
</ekran_resmi>
<kurulacak_paketler>
gavl
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
1.4.0
</surum>
<silinecek_paketler>
gavl
</silinecek_paketler>
</uygulama>
