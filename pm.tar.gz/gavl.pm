<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gavl
</isim>
<tanim>
A low level library, upon which multimedia APIs can be built
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/gavl.png
</ekran_resmi>
<kurulacak_paketler>
gavl
</kurulacak_paketler>
<silinecek_paketler>
gavl
</silinecek_paketler>
</uygulama>
