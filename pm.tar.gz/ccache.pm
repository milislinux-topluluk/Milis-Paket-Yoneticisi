<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
ccache
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ccache.png
</ekran_resmi>
<kurulacak_paketler>
ccache
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.3.4
</surum>
<silinecek_paketler>
ccache
</silinecek_paketler>
</uygulama>
