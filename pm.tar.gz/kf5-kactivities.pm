<?xml version="1.0"?>
<uygulama>
<grup>
belirsiz
</grup>
<isim>
kf5-kactivities
</isim>
<tanim>
Çalışma zamanını ve kütüphaneyi kullanıcı faaliyetlerini ayrı etkinlikler halinde organize etmek için
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/kf5-kactivities.png
</ekran_resmi>
<kurulacak_paketler>
kf5-kactivities
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
kf5-kactivities
</silinecek_paketler>
</uygulama>
