<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
deluge
</isim>
<tanim>
Python ve GTK tabanlı bittorrent istemcisi.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/deluge.png
</ekran_resmi>
<kurulacak_paketler>
deluge
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
deluge
</silinecek_paketler>
</uygulama>
