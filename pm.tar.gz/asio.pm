<?xml version="1.0"?>
<uygulama>
<grup>
Kütüphane
</grup>
<isim>
asio
</isim>
<tanim>
Cross-platform C++ library for ASynchronous network I/O
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/asio.png
</ekran_resmi>
<kurulacak_paketler>
asio
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.10.8
</surum>
<silinecek_paketler>
asio
</silinecek_paketler>
</uygulama>
