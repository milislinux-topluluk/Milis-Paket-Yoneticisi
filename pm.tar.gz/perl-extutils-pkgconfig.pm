<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-extutils-pkgconfig
</isim>
<tanim>
Perl connector for pkgconfig
</tanim>
<ekran_resmi>
file:///tmp/perl-extutils-pkgconfig.png
</ekran_resmi>
<kurulacak_paketler>
perl-extutils-pkgconfig
</kurulacak_paketler>
<silinecek_paketler>
perl-extutils-pkgconfig
</silinecek_paketler>
</uygulama>
