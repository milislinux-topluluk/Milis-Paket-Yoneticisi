<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
perl-extutils-pkgconfig
</isim>
<tanim>
Perl connector for pkgconfig
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/perl-extutils-pkgconfig.png
</ekran_resmi>
<kurulacak_paketler>
perl-extutils-pkgconfig
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.15
</surum>
<silinecek_paketler>
perl-extutils-pkgconfig
</silinecek_paketler>
</uygulama>
