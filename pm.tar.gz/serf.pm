<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
serf
</isim>
<tanim>
description="C-based HTTP client library built upon the Apache Portable Runtime (APR) library."
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/serf.png
</ekran_resmi>
<kurulacak_paketler>
serf
</kurulacak_paketler>
<paketci>
berlius at nutyx dot com
</paketci>
<surum>
1.3.8
</surum>
<silinecek_paketler>
serf
</silinecek_paketler>
</uygulama>
