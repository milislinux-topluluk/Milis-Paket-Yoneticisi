<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mate-settings-daemon
</isim>
<tanim>
MATE Ayarlar programı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mate-settings-daemon.png
</ekran_resmi>
<kurulacak_paketler>
mate-settings-daemon
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.1
</surum>
<silinecek_paketler>
mate-settings-daemon
</silinecek_paketler>
</uygulama>
