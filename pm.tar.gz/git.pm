<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
git
</isim>
<tanim>
Distributed version control system designed to handle small to very large projects.
</tanim>
<ekran_resmi>
file:///tmp/git.png
</ekran_resmi>
<kurulacak_paketler>
git
</kurulacak_paketler>
<silinecek_paketler>
git
</silinecek_paketler>
</uygulama>
