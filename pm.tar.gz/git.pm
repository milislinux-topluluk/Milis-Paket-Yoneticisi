<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
git
</isim>
<tanim>
Distributed version control system designed to handle small to very large projects.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/git.png
</ekran_resmi>
<kurulacak_paketler>
git
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org, pierre at nutyx dot org
</paketci>
<surum>
2.7.1
</surum>
<silinecek_paketler>
git
</silinecek_paketler>
</uygulama>
