<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
scrot
</isim>
<tanim>
A simple command-line screenshot utility for X
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/scrot.png
</ekran_resmi>
<kurulacak_paketler>
scrot
</kurulacak_paketler>
<paketci>
Chris Farrell, timcowchip at gmail dot com
</paketci>
<surum>
0.8.17
</surum>
<silinecek_paketler>
scrot
</silinecek_paketler>
</uygulama>
