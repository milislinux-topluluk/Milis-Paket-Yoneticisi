<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
scrot
</isim>
<tanim>
A simple command-line screenshot utility for X
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/scrot.png
</ekran_resmi>
<kurulacak_paketler>
scrot
</kurulacak_paketler>
<silinecek_paketler>
scrot
</silinecek_paketler>
</uygulama>
