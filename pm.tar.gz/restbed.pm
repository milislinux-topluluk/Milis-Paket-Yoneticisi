<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
restbed
</isim>
<tanim>
A framework for asynchronous RESTful functionality in C++11 applications
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/restbed.png
</ekran_resmi>
<kurulacak_paketler>
restbed
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
restbed
</silinecek_paketler>
</uygulama>
