<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
reflex
</isim>
<tanim>
Bu, esnek, hızlı sözcüksel tarayıcının bir varyantı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/reflex.png
</ekran_resmi>
<kurulacak_paketler>
reflex
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
20100627
</surum>
<silinecek_paketler>
reflex
</silinecek_paketler>
</uygulama>
