<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
reflex
</isim>
<tanim>
Bu, esnek, hızlı sözcüksel tarayıcının bir varyantı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/reflex.png
</ekran_resmi>
<kurulacak_paketler>
reflex
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
reflex
</silinecek_paketler>
</uygulama>
