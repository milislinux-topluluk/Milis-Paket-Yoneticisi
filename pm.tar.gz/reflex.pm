<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
reflex
</isim>
<tanim>
Bu, esnek, hızlı sözcüksel tarayıcının bir varyantı
</tanim>
<ekran_resmi>
file:///tmp/reflex.png
</ekran_resmi>
<kurulacak_paketler>
reflex
</kurulacak_paketler>
<silinecek_paketler>
reflex
</silinecek_paketler>
</uygulama>
