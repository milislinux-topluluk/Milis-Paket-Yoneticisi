<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libdbusmenu-qt
</isim>
<tanim>
DBusMenu spesifikasyonunun Qt uygulanmasını sağlayan bir kütüphane
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libdbusmenu-qt.png
</ekran_resmi>
<kurulacak_paketler>
libdbusmenu-qt
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
0.9.2
</surum>
<silinecek_paketler>
libdbusmenu-qt
</silinecek_paketler>
</uygulama>
