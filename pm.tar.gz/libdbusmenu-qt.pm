<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libdbusmenu-qt
</isim>
<tanim>
DBusMenu spesifikasyonunun Qt uygulanmasını sağlayan bir kütüphane
</tanim>
<ekran_resmi>
file:///tmp/libdbusmenu-qt.png
</ekran_resmi>
<kurulacak_paketler>
libdbusmenu-qt
</kurulacak_paketler>
<silinecek_paketler>
libdbusmenu-qt
</silinecek_paketler>
</uygulama>
