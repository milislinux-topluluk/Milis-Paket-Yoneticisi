<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxxf86dga
</isim>
<tanim>
libXxf86dga, library Xorg
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxxf86dga.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxxf86dga
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.1.4
</surum>
<silinecek_paketler>
xorg-libxxf86dga
</silinecek_paketler>
</uygulama>
