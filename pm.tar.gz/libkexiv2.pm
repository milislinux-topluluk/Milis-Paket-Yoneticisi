<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libkexiv2
</isim>
<tanim>
A library to manipulate pictures metadata
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libkexiv2.png
</ekran_resmi>
<kurulacak_paketler>
libkexiv2
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<surum>
16.08.2
</surum>
<silinecek_paketler>
libkexiv2
</silinecek_paketler>
</uygulama>
