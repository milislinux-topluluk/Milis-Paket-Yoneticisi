<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libmodplug
</isim>
<tanim>
Library for playing module music.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libmodplug.png
</ekran_resmi>
<kurulacak_paketler>
libmodplug
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.8.8.5
</surum>
<silinecek_paketler>
libmodplug
</silinecek_paketler>
</uygulama>
