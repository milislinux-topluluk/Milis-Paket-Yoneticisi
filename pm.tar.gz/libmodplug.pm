<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libmodplug
</isim>
<tanim>
Library for playing module music.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libmodplug.png
</ekran_resmi>
<kurulacak_paketler>
libmodplug
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libmodplug
</silinecek_paketler>
</uygulama>
