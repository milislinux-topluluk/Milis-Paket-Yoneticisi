<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libnl
</isim>
<tanim>
Library for applications dealing with netlink sockets
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libnl.png
</ekran_resmi>
<kurulacak_paketler>
libnl
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
3.2.27
</surum>
<silinecek_paketler>
libnl
</silinecek_paketler>
</uygulama>
