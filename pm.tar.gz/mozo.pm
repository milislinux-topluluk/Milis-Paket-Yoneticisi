<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mozo
</isim>
<tanim>
MATE menü düzenleme aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mozo.png
</ekran_resmi>
<kurulacak_paketler>
mozo
</kurulacak_paketler>
<silinecek_paketler>
mozo
</silinecek_paketler>
</uygulama>
