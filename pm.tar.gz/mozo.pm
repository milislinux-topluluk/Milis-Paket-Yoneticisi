<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mozo
</isim>
<tanim>
MATE menü düzenleme aracı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/mozo.png
</ekran_resmi>
<kurulacak_paketler>
mozo
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.18.0
</surum>
<silinecek_paketler>
mozo
</silinecek_paketler>
</uygulama>
