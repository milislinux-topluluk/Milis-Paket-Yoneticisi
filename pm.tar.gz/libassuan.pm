<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libassuan
</isim>
<tanim>
Contains an IPC library used by some of the other GnuPG related packages
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libassuan.png
</ekran_resmi>
<kurulacak_paketler>
libassuan
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
libassuan
</silinecek_paketler>
</uygulama>
