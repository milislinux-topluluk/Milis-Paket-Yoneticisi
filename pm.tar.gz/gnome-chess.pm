<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
gnome-chess
</isim>
<tanim>
Klasik iki oyunculu masaüstü oyunu
</tanim>
<ekran_resmi>
file:///tmp/gnome-chess.png
</ekran_resmi>
<kurulacak_paketler>
gnome-chess
</kurulacak_paketler>
<silinecek_paketler>
gnome-chess
</silinecek_paketler>
</uygulama>
