<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
gnome-chess
</isim>
<tanim>
Klasik iki oyunculu masaüstü oyunu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/gnome-chess.png
</ekran_resmi>
<kurulacak_paketler>
gnome-chess
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
3.24.1
</surum>
<silinecek_paketler>
gnome-chess
</silinecek_paketler>
</uygulama>
