<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sysvinit
</isim>
<tanim>
Programs for controlling the startup, running, and shutdown of the system.
</tanim>
<ekran_resmi>
file:///tmp/sysvinit.png
</ekran_resmi>
<kurulacak_paketler>
sysvinit
</kurulacak_paketler>
<silinecek_paketler>
sysvinit
</silinecek_paketler>
</uygulama>
