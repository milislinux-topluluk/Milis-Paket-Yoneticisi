<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
sysvinit
</isim>
<tanim>
Programs for controlling the startup, running, and shutdown of the system.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/sysvinit.png
</ekran_resmi>
<kurulacak_paketler>
sysvinit
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
2.88dsf
</surum>
<silinecek_paketler>
sysvinit
</silinecek_paketler>
</uygulama>
