<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python-yaml
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///tmp/python-yaml.png
</ekran_resmi>
<kurulacak_paketler>
python-yaml
</kurulacak_paketler>
<silinecek_paketler>
python-yaml
</silinecek_paketler>
</uygulama>
