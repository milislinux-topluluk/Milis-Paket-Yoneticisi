<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python-yaml
</isim>
<tanim>
Binary file (standard input) matches
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python-yaml.png
</ekran_resmi>
<kurulacak_paketler>
python-yaml
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
3.12
</surum>
<silinecek_paketler>
python-yaml
</silinecek_paketler>
</uygulama>
