<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xorg-libxscrnsaver
</isim>
<tanim>
libXScrnSaver, library X Screen Saver extension client
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xorg-libxscrnsaver.png
</ekran_resmi>
<kurulacak_paketler>
xorg-libxscrnsaver
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<silinecek_paketler>
xorg-libxscrnsaver
</silinecek_paketler>
</uygulama>
