<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
dbus-glib
</isim>
<tanim>
The D-Bus GLib package contains GLib interfaces to the D-Bus API.
</tanim>
<ekran_resmi>
file:///tmp/dbus-glib.png
</ekran_resmi>
<kurulacak_paketler>
dbus-glib
</kurulacak_paketler>
<silinecek_paketler>
dbus-glib
</silinecek_paketler>
</uygulama>
