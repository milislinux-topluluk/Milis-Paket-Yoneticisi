<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
dbus-glib
</isim>
<tanim>
The D-Bus GLib package contains GLib interfaces to the D-Bus API.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/dbus-glib.png
</ekran_resmi>
<kurulacak_paketler>
dbus-glib
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
0.104
</surum>
<silinecek_paketler>
dbus-glib
</silinecek_paketler>
</uygulama>
