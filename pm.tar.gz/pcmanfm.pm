<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
pcmanfm
</isim>
<tanim>
Son derece hızlı, hafif, sekmeli tarama özellikli zengin dosya yöneticisi içerir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/pcmanfm.png
</ekran_resmi>
<kurulacak_paketler>
pcmanfm
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
pcmanfm
</silinecek_paketler>
</uygulama>
