<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
pcmanfm
</isim>
<tanim>
Son derece hızlı, hafif, sekmeli tarama özellikli zengin dosya yöneticisi içerir.
</tanim>
<ekran_resmi>
file:///tmp/pcmanfm.png
</ekran_resmi>
<kurulacak_paketler>
pcmanfm
</kurulacak_paketler>
<silinecek_paketler>
pcmanfm
</silinecek_paketler>
</uygulama>
