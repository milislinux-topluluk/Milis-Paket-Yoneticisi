<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telepathy-kde-common-internals
</isim>
<tanim>
KDE-Telepati için ortak bileşenler
</tanim>
<ekran_resmi>
file:///tmp/telepathy-kde-common-internals.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-common-internals
</kurulacak_paketler>
<silinecek_paketler>
telepathy-kde-common-internals
</silinecek_paketler>
</uygulama>
