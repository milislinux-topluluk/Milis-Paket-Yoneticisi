<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
plasma-kmenuedit
</isim>
<tanim>
KDE menü düzenleyici
</tanim>
<ekran_resmi>
file:///tmp/plasma-kmenuedit.png
</ekran_resmi>
<kurulacak_paketler>
plasma-kmenuedit
</kurulacak_paketler>
<silinecek_paketler>
plasma-kmenuedit
</silinecek_paketler>
</uygulama>
