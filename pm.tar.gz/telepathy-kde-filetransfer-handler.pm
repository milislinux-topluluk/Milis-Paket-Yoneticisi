<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
telepathy-kde-filetransfer-handler
</isim>
<tanim>
KDE Telepathy dosya aktarım işleyici
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/telepathy-kde-filetransfer-handler.png
</ekran_resmi>
<kurulacak_paketler>
telepathy-kde-filetransfer-handler
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
telepathy-kde-filetransfer-handler
</silinecek_paketler>
</uygulama>
