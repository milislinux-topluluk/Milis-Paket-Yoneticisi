<?xml version="1.0"?>
<uygulama>
<grup>
Belirsiz
</grup>
<isim>
syndication
</isim>
<tanim>
S/Atom ayrıştırıcı kitaplığı
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/syndication.png
</ekran_resmi>
<kurulacak_paketler>
syndication
</kurulacak_paketler>
<paketci>
cihanAlkan
</paketci>
<surum>
17.12.0
</surum>
<silinecek_paketler>
syndication
</silinecek_paketler>
</uygulama>
