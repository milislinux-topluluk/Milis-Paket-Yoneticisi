<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
syndication
</isim>
<tanim>
S/Atom ayrıştırıcı kitaplığı
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/syndication.png
</ekran_resmi>
<kurulacak_paketler>
syndication
</kurulacak_paketler>
<silinecek_paketler>
syndication
</silinecek_paketler>
</uygulama>
