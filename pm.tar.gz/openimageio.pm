<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
openimageio
</isim>
<tanim>
Sınıflar, yardımcı programlar ve uygulamalar da dahil olmak üzere resim okumak ve yazmak için
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/openimageio.png
</ekran_resmi>
<kurulacak_paketler>
openimageio
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.7.14
</surum>
<silinecek_paketler>
openimageio
</silinecek_paketler>
</uygulama>
