<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
openimageio
</isim>
<tanim>
Sınıflar, yardımcı programlar ve uygulamalar da dahil olmak üzere resim okumak ve yazmak için
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/openimageio.png
</ekran_resmi>
<kurulacak_paketler>
openimageio
</kurulacak_paketler>
<paketci>
yasarciv67@gmail.com
</paketci>
<surum>
1.7.14
</surum>
<silinecek_paketler>
openimageio
</silinecek_paketler>
</uygulama>
