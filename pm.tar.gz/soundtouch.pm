<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
soundtouch
</isim>
<tanim>
Audio processing library that allows changing the sound tempo, pitch and playback rate.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/soundtouch.png
</ekran_resmi>
<kurulacak_paketler>
soundtouch
</kurulacak_paketler>
<paketci>
tnut at nutyx dot org
</paketci>
<surum>
1.9.2
</surum>
<silinecek_paketler>
soundtouch
</silinecek_paketler>
</uygulama>
