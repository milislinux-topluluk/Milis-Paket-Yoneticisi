<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
soundtouch
</isim>
<tanim>
Ses tempo, basamak ve oynatma oranını değiştirmeye izin veren ses işleme kitaplığı.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/soundtouch.png
</ekran_resmi>
<kurulacak_paketler>
soundtouch
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
1.9.2
</surum>
<silinecek_paketler>
soundtouch
</silinecek_paketler>
</uygulama>
