<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
hplip
</isim>
<tanim>
HP DeskJet, OfficeJet, Photosmart, Business Inkjet ve bazı LaserJet serileri için sürücüler
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/hplip.png
</ekran_resmi>
<kurulacak_paketler>
hplip
</kurulacak_paketler>
<paketci>
alihan-ozturk28@hotmail.com
</paketci>
<silinecek_paketler>
hplip
</silinecek_paketler>
</uygulama>
