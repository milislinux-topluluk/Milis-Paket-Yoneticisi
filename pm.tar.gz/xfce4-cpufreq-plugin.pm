<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-cpufreq-plugin
</isim>
<tanim>
Xfce4 paneli için CPU frekansı eklentisi
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/xfce4-cpufreq-plugin.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-cpufreq-plugin
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
xfce4-cpufreq-plugin
</silinecek_paketler>
</uygulama>
