<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
yad
</isim>
<tanim>
shell skriptleri icin dialog penceresi araci
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/yad.png
</ekran_resmi>
<kurulacak_paketler>
yad
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<surum>
0.39.0
</surum>
<silinecek_paketler>
yad
</silinecek_paketler>
</uygulama>
