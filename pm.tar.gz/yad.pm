<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
yad
</isim>
<tanim>
shell skriptleri icin dialog penceresi araci
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/yad.png
</ekran_resmi>
<kurulacak_paketler>
yad
</kurulacak_paketler>
<silinecek_paketler>
yad
</silinecek_paketler>
</uygulama>
