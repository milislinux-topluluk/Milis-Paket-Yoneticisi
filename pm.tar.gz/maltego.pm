<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
maltego
</isim>
<tanim>
DNS, Alan Adı, IP adresleri, web siteleri, kişiler vb. hakkında bilgi toplamak için açık kaynaklı bir istihbarat ve adli bilişim uygulaması.
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/maltego.png
</ekran_resmi>
<kurulacak_paketler>
maltego
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
4.0.11.9358
</surum>
<silinecek_paketler>
maltego
</silinecek_paketler>
</uygulama>
