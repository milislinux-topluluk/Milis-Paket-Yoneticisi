<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
maltego
</isim>
<tanim>
DNS, Alan Adı, IP adresleri, web siteleri, kişiler vb. hakkında bilgi toplamak için açık kaynaklı bir istihbarat ve adli bilişim uygulaması.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/maltego.png
</ekran_resmi>
<kurulacak_paketler>
maltego
</kurulacak_paketler>
<paketci>
yakar (aydin@komutan.org)
</paketci>
<surum>
1
</surum>
<silinecek_paketler>
maltego
</silinecek_paketler>
</uygulama>
