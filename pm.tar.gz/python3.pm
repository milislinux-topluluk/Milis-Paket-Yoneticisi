<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
python3
</isim>
<tanim>
Next generation of the python high-level scripting language
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/python3.png
</ekran_resmi>
<kurulacak_paketler>
python3
</kurulacak_paketler>
<paketci>
alienus at nutyx dot org, tnut at nutyx dot org
</paketci>
<surum>
3.5.1
</surum>
<silinecek_paketler>
python3
</silinecek_paketler>
</uygulama>
