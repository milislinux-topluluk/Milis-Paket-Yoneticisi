<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
python3
</isim>
<tanim>
Next generation of the python high-level scripting language
</tanim>
<ekran_resmi>
file:///tmp/python3.png
</ekran_resmi>
<kurulacak_paketler>
python3
</kurulacak_paketler>
<silinecek_paketler>
python3
</silinecek_paketler>
</uygulama>
