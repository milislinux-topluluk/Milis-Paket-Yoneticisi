<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
freetuxtv
</isim>
<tanim>
WebTV vlc player to watch tv/radio playlists on the internet
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/freetuxtv.png
</ekran_resmi>
<kurulacak_paketler>
freetuxtv
</kurulacak_paketler>
<paketci>
Cihan Alkan
</paketci>
<surum>
0.6.8
</surum>
<silinecek_paketler>
freetuxtv
</silinecek_paketler>
</uygulama>
