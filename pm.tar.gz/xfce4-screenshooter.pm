<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xfce4-screenshooter
</isim>
<tanim>
allows of do of captures d'ecrans or of fenetres
</tanim>
<ekran_resmi>
file:///tmp/xfce4-screenshooter.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-screenshooter
</kurulacak_paketler>
<silinecek_paketler>
xfce4-screenshooter
</silinecek_paketler>
</uygulama>
