<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
xfce4-screenshooter
</isim>
<tanim>
allows of do of captures d'ecrans or of fenetres
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/xfce4-screenshooter.png
</ekran_resmi>
<kurulacak_paketler>
xfce4-screenshooter
</kurulacak_paketler>
<paketci>
tyrry at nutyx dot org
</paketci>
<surum>
1.8.2
</surum>
<silinecek_paketler>
xfce4-screenshooter
</silinecek_paketler>
</uygulama>
