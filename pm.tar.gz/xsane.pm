<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
xsane
</isim>
<tanim>
SANE-1.0.24 için ön uç. Görüntü kalitesini ve kullanımı kolaylaştırmak için ek özelliklere sahiptir
</tanim>
<ekran_resmi>
file:///tmp/xsane.png
</ekran_resmi>
<kurulacak_paketler>
xsane
</kurulacak_paketler>
<silinecek_paketler>
xsane
</silinecek_paketler>
</uygulama>
