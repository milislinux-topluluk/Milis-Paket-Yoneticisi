<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
mc
</isim>
<tanim>
Midnight Commander, Norton Commander'ı öykünen metin tabanlı bir dosya yöneticisi/kabuğu
</tanim>
<ekran_resmi>
file:///tmp/mc.png
</ekran_resmi>
<kurulacak_paketler>
mc
</kurulacak_paketler>
<silinecek_paketler>
mc
</silinecek_paketler>
</uygulama>
