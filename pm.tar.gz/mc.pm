<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
mc
</isim>
<tanim>
Midnight Commander, Norton Commander'ı öykünen metin tabanlı bir dosya yöneticisi/kabuğu
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/mc.png
</ekran_resmi>
<kurulacak_paketler>
mc
</kurulacak_paketler>
<paketci>
milisarge@gmail.com
</paketci>
<surum>
4.8.15
</surum>
<silinecek_paketler>
mc
</silinecek_paketler>
</uygulama>
