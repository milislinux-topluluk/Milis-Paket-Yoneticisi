<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
ssh-askpass
</isim>
<tanim>
Dialog box to grab password for packages requiring administrative privileges to be run
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/ssh-askpass.png
</ekran_resmi>
<kurulacak_paketler>
ssh-askpass
</kurulacak_paketler>
<silinecek_paketler>
ssh-askpass
</silinecek_paketler>
</uygulama>
