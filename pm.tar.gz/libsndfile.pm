<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
libsndfile
</isim>
<tanim>
A C library for reading and writing files containing sampled sound
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/libsndfile.png
</ekran_resmi>
<kurulacak_paketler>
libsndfile
</kurulacak_paketler>
<silinecek_paketler>
libsndfile
</silinecek_paketler>
</uygulama>
