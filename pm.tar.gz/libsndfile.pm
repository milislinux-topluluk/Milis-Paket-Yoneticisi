<?xml version="1.0"?>
<uygulama>
<grup>
Diğer
</grup>
<isim>
libsndfile
</isim>
<tanim>
A C library for reading and writing files containing sampled sound
</tanim>
<ekran_resmi>
https://raw.githubusercontent.com/milislinux-topluluk/Uygulama-Resimleri/master/libsndfile.png
</ekran_resmi>
<kurulacak_paketler>
libsndfile
</kurulacak_paketler>
<paketci>
pierre at nutyx dot org
</paketci>
<surum>
1.0.25
</surum>
<silinecek_paketler>
libsndfile
</silinecek_paketler>
</uygulama>
