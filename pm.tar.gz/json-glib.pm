<?xml version="1.0"?>
<uygulama>
<grup>
</grup>
<isim>
json-glib
</isim>
<tanim>
JavaScript Object Notation (JSON) için serileştirme ve serileştirmeden çıkarma desteği sağlayan bir kütüphanedir.
</tanim>
<ekran_resmi>
file:///usr/share/milpek/arayuz/json-glib.png
</ekran_resmi>
<kurulacak_paketler>
json-glib
</kurulacak_paketler>
<paketci>
milisarge
</paketci>
<silinecek_paketler>
json-glib
</silinecek_paketler>
</uygulama>
